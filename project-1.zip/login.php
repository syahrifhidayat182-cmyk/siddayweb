<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/brute_force.php';
require_guest();

bf_cleanup();

$error      = '';
$warning    = '';
$lockoutSec = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $emailRaw = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // ── Proteksi SQL Injection & Input Validation ──
    block_if_suspicious($emailRaw, $password);
    $email = sanitize_email($emailRaw);
    if ($email === false) {
        $error = 'Format email tidak valid.';
        $email = '';
    }

    $ident = bf_identifier($emailRaw);

    // 1. Cek lockout
    $lockoutSec = bf_check($ident);
    if ($lockoutSec > 0) {
        $error = '🔒 Terlalu banyak percobaan gagal. Coba lagi dalam <strong>' . bf_format_time($lockoutSec) . '</strong>.';
    }
    // 2. Verifikasi reCAPTCHA (jika aktif)
    elseif (recaptcha_enabled()) {
        $token = trim($_POST['g-recaptcha-response'] ?? '');
        if (!$token || !recaptcha_verify($token)) {
            $error = '⚠️ Verifikasi reCAPTCHA gagal. Silakan coba lagi.';
            bf_record($ident);
        }
    }

    // 3. Autentikasi
    if (!$error) {
        if (!$email || !$password) {
            $error = 'Email dan password wajib diisi.';
        } else {
            $user = $email ? db_row("SELECT * FROM users WHERE email=?", [$email]) : null;

            if (!$user || !password_verify($password, $user['password'])) {
                bf_record($ident);
                $remaining = bf_remaining($ident);
                if ($remaining <= 0) {
                    $lockoutSec = bf_lockout_seconds();
                    $error = '🔒 Terlalu banyak percobaan gagal. Akun dikunci selama <strong>' . bf_format_time($lockoutSec) . '</strong>.';
                } else {
                    $warn = $remaining <= 2
                        ? ' <span style="color:#ff9800">Sisa <strong>' . $remaining . ' percobaan</strong> sebelum dikunci.</span>'
                        : '';
                    $error = 'Email atau password salah.' . $warn;
                }
            } elseif ($user['status'] !== 'active') {
                $error = 'Akun Anda telah disuspend. Hubungi admin.';
            } else {
                bf_reset($ident);
                session_regenerate_id(true);
                $_SESSION['user_id']   = $user['id'];
                $_SESSION['user_role'] = $user['role'];
                redirect($user['role'] === 'admin' ? BASE_URL . '/admin/' : BASE_URL . '/dashboard.php');
            }
        }
    }
} else {
    $ipIdent    = bf_identifier();
    $lockoutSec = bf_check($ipIdent);
    if ($lockoutSec > 0) {
        $warning = '🔒 IP Anda sementara dikunci karena terlalu banyak percobaan gagal. Coba lagi dalam <strong>' . bf_format_time($lockoutSec) . '</strong>.';
    }
}

// Tampilkan reCAPTCHA jika enabled via DB atau hardcoded fallback tersedia
$rcSiteKey = recaptcha_enabled() ? recaptcha_site_key() : '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login — <?= e(setting('site_name',APP_NAME)) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@600;700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/auth.css">
<?php if ($rcSiteKey): ?>
<script src="https://www.google.com/recaptcha/api.js?render=<?= e($rcSiteKey) ?>"></script>
<?php endif; ?>
<style>
.bf-lockout{background:rgba(255,68,68,.08);border:1px solid rgba(255,68,68,.3);border-radius:10px;padding:14px 16px;font-size:13.5px;color:#ff6b6b;margin-bottom:16px;text-align:center}
.bf-lockout .lock-icon{font-size:24px;display:block;margin-bottom:6px}
.bf-countdown{font-family:'Space Mono',monospace;font-size:20px;font-weight:700;color:#ff4444;margin-top:6px}
.auth-error strong{color:#ff9800}
</style>
</head>
<body class="auth-body">

<div class="auth-split">
  <div class="auth-left">
    <div class="auth-left-inner">
      <div class="brand-wrap">
        <div class="brand-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="1.5" d="M5 12h14M12 5l7 7-7 7"/></svg></div>
        <div>
          <div class="brand-name"><?= e(setting('site_name',APP_NAME)) ?></div>
          <div class="brand-sub">Panel Marketplace</div>
        </div>
      </div>
      <h1 class="auth-hero">Server Game & Bot<br><span>Instan & Otomatis</span></h1>
      <p class="auth-desc">Top up saldo, pilih paket, dan server Pterodactyl Anda langsung aktif secara otomatis.</p>
      <ul class="feature-list">
        <li><span class="feat-dot"></span>Server aktif otomatis dalam hitungan detik</li>
        <li><span class="feat-dot"></span>Top up via QRIS, proses cepat &amp; aman</li>
        <li><span class="feat-dot"></span>Panel Pterodactyl full akses &amp; kontrol</li>
        <li><span class="feat-dot"></span>Support admin siap membantu</li>
      </ul>
    </div>
  </div>

  <div class="auth-right">
    <div class="auth-form-box">
      <div class="auth-form-header">
        <h2>Selamat datang 👋</h2>
        <p>Masuk ke akun Anda untuk melanjutkan</p>
      </div>

      <?php if ($warning): ?>
      <div class="bf-lockout">
        <span class="lock-icon">🔒</span>
        <?= $warning ?>
      </div>
      <?php endif; ?>

      <?php if ($error): ?>
      <div class="auth-error"><?= $error ?></div>
      <?php endif; ?>

      <?php if ($lockoutSec > 0): ?>
      <div class="bf-lockout" style="margin-top:0">
        <div>Coba lagi dalam:</div>
        <div class="bf-countdown" id="bfCountdown"></div>
      </div>
      <script>
      var bfSeconds = <?= (int)$lockoutSec ?>;
      function bfTick(){
        if(bfSeconds<=0){location.reload();return;}
        var m=Math.floor(bfSeconds/60),s=bfSeconds%60;
        document.getElementById('bfCountdown').textContent=(m>0?m+'m ':'')+s+'d';
        bfSeconds--;setTimeout(bfTick,1000);
      }
      bfTick();
      </script>
      <?php endif; ?>

      <form method="POST" action="" id="loginForm">
        <?= csrf_field() ?>
        <?php if ($rcSiteKey): ?>
        <input type="hidden" name="g-recaptcha-response" id="gRecaptchaToken">
        <?php endif; ?>

        <div class="form-group">
          <label class="form-label">Email</label>
          <div class="input-wrap">
            <svg class="input-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
            <input type="email" name="email" class="form-input" placeholder="email@kamu.com"
                   value="<?= e($_POST['email']??'') ?>" required autofocus
                   <?= $lockoutSec > 0 ? 'disabled' : '' ?>>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <div class="input-wrap">
            <svg class="input-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
            <input type="password" name="password" class="form-input" placeholder="••••••••" required
                   <?= $lockoutSec > 0 ? 'disabled' : '' ?>>
          </div>
        </div>
        <div class="remember-row">
          <label><input type="checkbox" name="remember"> Ingat saya</label>
        </div>

        <?php if ($rcSiteKey): ?>
        <div style="font-size:11px;color:var(--muted);margin-bottom:12px;text-align:center">
          🛡️ Dilindungi Google reCAPTCHA v3
        </div>
        <?php endif; ?>

        <button type="submit" class="btn-auth" id="loginBtn"
                <?= $lockoutSec > 0 ? 'disabled style="opacity:.5;cursor:not-allowed"' : '' ?>>
          MASUK →
        </button>
      </form>

      <div class="auth-switch">Belum punya akun? <a href="<?= BASE_URL ?>/register.php">Daftar sekarang</a></div>
    </div>
  </div>
</div>

<?php if ($rcSiteKey): ?>
<script>
document.getElementById('loginForm').addEventListener('submit', function(e) {
  e.preventDefault();
  var form = this, btn = document.getElementById('loginBtn');
  btn.textContent = 'Memverifikasi...';
  btn.disabled = true;
  grecaptcha.ready(function() {
    grecaptcha.execute('<?= e($rcSiteKey) ?>', {action:'login'}).then(function(token) {
      document.getElementById('gRecaptchaToken').value = token;
      form.submit();
    }).catch(function(){ form.submit(); });
  });
});
</script>
<?php endif; ?>
</body>
</html>
