<?php
// ============================================================
//  config.php — Isi sesuai data hosting Anda
// ============================================================

define('DB_HOST',    'sql111.hstn.me:3306');
define('DB_NAME',    'mseet_39106674_new');
define('DB_USER',    'mseet_39106674');
define('DB_PASS',    'albogeng');
define('DB_CHARSET', 'utf8mb4');

define('APP_NAME', 'PteroShop');
define('APP_URL',  'https://sidayy-market.is-great.net/');
define('APP_ENV',  'production');
define('TIMEZONE', 'Asia/Jakarta');

define('UPLOAD_DIR',    __DIR__ . '/uploads/');
define('UPLOAD_PROOFS', __DIR__ . '/uploads/proofs/');
define('UPLOAD_QRIS',   __DIR__ . '/uploads/qris/');
define('UPLOAD_MAX_MB', 2);

define('SESSION_NAME', 'pteroshop_sess');

date_default_timezone_set(TIMEZONE);
error_reporting(APP_ENV === 'development' ? E_ALL : 0);
ini_set('display_errors', APP_ENV === 'development' ? 1 : 0);
