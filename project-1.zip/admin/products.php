<?php
require_once __DIR__ . '/../includes/init.php';
require_admin();
$pageTitle = 'Manajemen Produk';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'toggle') {
        $p = db_row("SELECT * FROM products WHERE id=?", [(int)$_POST['id']]);
        if ($p) { db_update('products',['is_active'=>$p['is_active']?0:1],'id=?',[(int)$_POST['id']]); }
        flash('success','Status produk diubah.');
        redirect('products.php');
    }
if ($action === 'delete') {
    $id = (int)$_POST['id'];
    
    // Cek apakah produk masih digunakan di orders/services
    $inUse = db_row("SELECT id FROM orders WHERE product_id=? LIMIT 1", [$id]);
    if ($inUse) {
        flash('error', 'Produk tidak bisa dihapus karena masih digunakan dalam order.');
        redirect('products.php');
    }
    
    db_query("DELETE FROM products WHERE id=?", [$id]);
    flash('success', 'Produk dihapus.');
    redirect('products.php');
}
    if (in_array($action,['create','update'])) {
        $data = [
            'name'         => trim($_POST['name']??''),
            'description'  => trim($_POST['description']??''),
            'price'        => (int)preg_replace('/[^0-9]/','', $_POST['price']??''),
            'ram'          => (int)($_POST['ram']??0),
            'cpu'          => (int)($_POST['cpu']??0),
            'disk'         => (int)($_POST['disk']??0),
            'db_count'     => (int)($_POST['db_count']??1),
            'backup_count' => (int)($_POST['backup_count']??1),
            'node_id'      => trim($_POST['node_id']??''),
            'nest_id'      => trim($_POST['nest_id']??''),
            'egg_id'       => trim($_POST['egg_id']??''),
            'docker_image' => trim($_POST['docker_image']??''),
            'startup'      => trim($_POST['startup']??''),
            'environment'  => trim($_POST['environment']??'{}'),
            'is_active'    => isset($_POST['is_active'])?1:0,
            'sort_order'   => (int)($_POST['sort_order']??0),
        ];
        if ($action === 'create') db_insert('products', $data);
        else db_update('products', $data, 'id=?', [(int)$_POST['id']]);
        flash('success', $action === 'create' ? 'Produk ditambahkan.' : 'Produk diupdate.');
        redirect('products.php');
    }
}

$products  = db_rows("SELECT * FROM products ORDER BY sort_order,price");
$editId    = (int)($_GET['edit'] ?? 0);
$editProd  = $editId ? db_row("SELECT * FROM products WHERE id=?",[$editId]) : null;

require_once __DIR__ . '/../includes/admin_header.php';
?>

<div class="grid-2" style="align-items:start">

  <!-- Form tambah/edit -->
  <div class="card">
    <div class="card-title" style="margin-bottom:18px"><?= $editProd ? '✏️ Edit Produk' : '➕ Tambah Produk Baru' ?></div>
    <form method="POST">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="<?= $editProd ? 'update' : 'create' ?>">
      <?php if($editProd): ?><input type="hidden" name="id" value="<?= $editProd['id'] ?>"><?php endif; ?>

      <div class="form-group">
        <label class="form-label">Nama Produk</label>
        <input type="text" name="name" class="form-input no-icon" placeholder="Misal: Basic 512MB" required value="<?= e($editProd['name']??'') ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Deskripsi (opsional)</label>
        <textarea name="description" class="form-textarea" placeholder="Deskripsi singkat produk"><?= e($editProd['description']??'') ?></textarea>
      </div>
      <div class="form-group">
        <label class="form-label">Harga (Rp)</label>
        <input type="number" name="price" class="form-input no-icon" placeholder="15000" required value="<?= $editProd['price']??'' ?>">
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">RAM (MB) <span style="color:var(--muted);font-size:11px">0=Unlimited</span></label><input type="number" name="ram" class="form-input no-icon" placeholder="512 (0=∞)" required value="<?= $editProd['ram']??'' ?>"></div>
        <div class="form-group"><label class="form-label">CPU (%) <span style="color:var(--muted);font-size:11px">0=Unlimited</span></label><input type="number" name="cpu" class="form-input no-icon" placeholder="100 (0=∞)" required value="<?= $editProd['cpu']??'' ?>"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Disk (MB) <span style="color:var(--muted);font-size:11px">0=Unlimited</span></label><input type="number" name="disk" class="form-input no-icon" placeholder="2048 (0=∞)" required value="<?= $editProd['disk']??'' ?>"></div>
        <div class="form-group"><label class="form-label">Database</label><input type="number" name="db_count" class="form-input no-icon" value="<?= $editProd['db_count']??1 ?>"></div>
      </div>
      <div style="background:rgba(255,215,0,.06);border:1px solid rgba(255,215,0,.2);border-radius:8px;padding:10px 14px;margin-bottom:14px;font-size:12px;color:var(--muted)">
        💡 <strong style="color:var(--yellow)">Tips:</strong> Isi RAM / CPU / Disk = <strong>0</strong> untuk mengaktifkan mode <strong>Unlimited</strong> di Pterodactyl. Cocok untuk paket premium/VIP.
      </div>
      <!-- Auto-fetch dari Pterodactyl -->
      <div style="background:rgba(0,212,255,.06);border:1px solid rgba(0,212,255,.2);border-radius:10px;padding:14px;margin-bottom:16px">
        <div style="font-size:12px;color:var(--muted);margin-bottom:10px;font-family:'Space Mono',monospace;text-transform:uppercase;letter-spacing:1px">⚡ Auto-Fill dari Pterodactyl</div>
        <div style="display:flex;gap:8px">
          <select id="eggSelect" class="form-select" style="flex:1" onchange="fillEggData(this)">
            <option value="">— Pilih Egg dari Panel —</option>
          </select>
          <button type="button" onclick="loadEggs()" class="btn btn-outline btn-sm">🔄 Muat</button>
        </div>
        <div id="eggLoadStatus" style="font-size:12px;color:var(--muted);margin-top:6px"></div>
      </div>

      <div class="form-row">
        <div class="form-group"><label class="form-label">Node ID</label><input type="text" name="node_id" class="form-input no-icon" placeholder="1" required value="<?= e($editProd['node_id']??'') ?>"></div>
        <div class="form-group"><label class="form-label">Nest ID</label><input type="text" name="nest_id" id="nest_id" class="form-input no-icon" placeholder="1" value="<?= e($editProd['nest_id']??'') ?>"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Egg ID</label><input type="text" name="egg_id" id="egg_id" class="form-input no-icon" placeholder="15" required value="<?= e($editProd['egg_id']??'') ?>"></div>
        <div class="form-group"><label class="form-label">Backup</label><input type="number" name="backup_count" class="form-input no-icon" value="<?= $editProd['backup_count']??1 ?>"></div>
      </div>
      <div class="form-group">
        <label class="form-label">Docker Image</label>
        <input type="text" name="docker_image" class="form-input no-icon" placeholder="ghcr.io/..." required value="<?= e($editProd['docker_image']??'') ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Startup Command</label>
        <input type="text" name="startup" class="form-input no-icon" placeholder="java -Xms128M..." required value="<?= e($editProd['startup']??'') ?>">
      </div>
      <div class="form-group">
        <label class="form-label">Environment Variables (JSON)</label>
        <textarea name="environment" class="form-textarea" placeholder='{"SERVER_JARFILE":"server.jar"}'><?= e($editProd['environment']??'{}') ?></textarea>
      </div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Urutan</label><input type="number" name="sort_order" class="form-input no-icon" value="<?= $editProd['sort_order']??0 ?>"></div>
        <div class="form-group" style="display:flex;align-items:end;padding-bottom:16px">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13.5px;color:var(--txt)">
            <input type="checkbox" name="is_active" value="1" style="accent-color:var(--cyan)" <?= (!isset($editProd) || $editProd['is_active']) ? 'checked' : '' ?>>
            Aktifkan produk
          </label>
        </div>
      </div>
      <div style="display:flex;gap:10px">
        <button type="submit" class="btn btn-primary"><?= $editProd ? '💾 Simpan' : '➕ Tambah' ?></button>
        <?php if($editProd): ?><a href="products.php" class="btn btn-outline">Batal</a><?php endif; ?>
      </div>
    </form>
  </div>

  <!-- Daftar produk -->
  <div class="card">
    <div class="card-title" style="margin-bottom:16px">Daftar Produk (<?= count($products) ?>)</div>
    <?php foreach ($products as $p): ?>
    <div style="background:var(--card2);border:1px solid var(--border);border-radius:10px;padding:14px;margin-bottom:10px">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px">
        <div>
          <div style="font-weight:600;font-family:'Syne',sans-serif"><?= e($p['name']) ?></div>
          <div style="color:var(--cyan);font-weight:700;font-family:'Space Mono',monospace;font-size:13px;margin-top:2px"><?= rupiah((int)$p['price']) ?></div>
          <div style="font-size:12px;color:var(--muted);margin-top:4px">
            <?= $p['ram']==0?'<span style="color:var(--cyan)">∞ RAM</span>':($p['ram']>=1024?($p['ram']/1024).'GB':$p['ram'].'MB').' RAM' ?> /
            <?= $p['cpu']==0?'<span style="color:var(--cyan)">∞ CPU</span>':$p['cpu'].'% CPU' ?> /
            <?= $p['disk']==0?'<span style="color:var(--cyan)">∞ Disk</span>':($p['disk']>=1024?($p['disk']/1024).'GB':$p['disk'].'MB').' Disk' ?>
          </div>
        </div>
        <div style="display:flex;flex-direction:column;gap:6px;align-items:flex-end">
          <?= status_badge($p['is_active'] ? 'active' : 'banned') ?>
          <div style="display:flex;gap:5px">
            <a href="?edit=<?= $p['id'] ?>" class="btn btn-outline btn-sm">✏️</a>
            <form method="POST" style="display:inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="id" value="<?= $p['id'] ?>">
              <button class="btn btn-yellow btn-sm"><?= $p['is_active'] ? 'Nonaktif' : 'Aktifkan' ?></button>
            </form>
            <form method="POST" style="display:inline" onsubmit="return confirm('Hapus produk ini?')">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= $p['id'] ?>">
              <button class="btn btn-danger btn-sm">🗑</button>
            </form>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if(!$products): ?><div style="text-align:center;color:var(--muted);padding:30px">Belum ada produk.</div><?php endif; ?>
  </div>
</div>

<script>
var eggsData = [];

function loadEggs() {
  var status = document.getElementById('eggLoadStatus');
  var sel    = document.getElementById('eggSelect');
  status.textContent = 'Memuat data egg dari Pterodactyl...';
  sel.innerHTML = '<option value="">Memuat...</option>';

  fetch('<?= BASE_URL ?>/admin/ajax_eggs.php')
    .then(r => r.json())
    .then(data => {
      if (data.error) { status.textContent = '❌ ' + data.error; return; }
      eggsData = data.eggs;
      sel.innerHTML = '<option value="">— Pilih Egg —</option>';
      var nests = {};
      data.eggs.forEach(e => {
        if (!nests[e.nest_name]) nests[e.nest_name] = [];
        nests[e.nest_name].push(e);
      });
      Object.entries(nests).forEach(([nest, eggs]) => {
        var grp = document.createElement('optgroup');
        grp.label = nest;
        eggs.forEach(e => {
          var opt = document.createElement('option');
          opt.value = e.egg_id;
          opt.textContent = e.egg_name + ' (#' + e.egg_id + ')';
          grp.appendChild(opt);
        });
        sel.appendChild(grp);
      });
      status.textContent = '✅ ' + data.eggs.length + ' egg dimuat.';
    })
    .catch(e => { status.textContent = '❌ Gagal: ' + e.message; });
}

function fillEggData(sel) {
  if (!sel.value) return;
  var egg = eggsData.find(e => e.egg_id == sel.value);
  if (!egg) return;

  document.getElementById('nest_id').value    = egg.nest_id;
  document.getElementById('egg_id').value     = egg.egg_id;
  document.querySelector('[name=docker_image]').value = egg.docker_image;
  document.querySelector('[name=startup]').value      = egg.startup;

  // Build environment JSON dari required variables
  var env = {};
  egg.variables.forEach(v => { env[v.env_var] = v.default || ''; });
  document.querySelector('[name=environment]').value = JSON.stringify(env, null, 2);

  document.getElementById('eggLoadStatus').textContent =
    '✅ Data egg "' + egg.egg_name + '" berhasil diisi! Sesuaikan environment variables jika perlu.';
}
</script>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
