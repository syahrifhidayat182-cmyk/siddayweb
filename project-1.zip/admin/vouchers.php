<?php
require_once __DIR__ . '/../includes/init.php';
require_admin();
$pageTitle = 'Manajemen Voucher';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $code     = strtoupper(trim($_POST['code'] ?? ''));
        $type     = in_array($_POST['type'], ['percent', 'flat']) ? $_POST['type'] : 'percent';
        $value    = (float)($_POST['value'] ?? 0);
        $usesLeft = $_POST['uses_left'] !== '' ? (int)$_POST['uses_left'] : null;
        $expiredAt = !empty($_POST['expired_at']) ? date('Y-m-d 23:59:59', strtotime($_POST['expired_at'])) : null;

        if (!preg_match('/^[A-Z0-9\-_]{3,30}$/', $code)) {
            flash('error', 'Kode voucher harus huruf kapital/angka/strip, 3-30 karakter.');
            redirect('vouchers.php');
        }
        if ($value <= 0 || ($type === 'percent' && $value > 100)) {
            flash('error', 'Nilai voucher tidak valid.');
            redirect('vouchers.php');
        }

        $data = [
            'code'       => $code,
            'type'       => $type,
            'value'      => $value,
            'uses_left'  => $usesLeft,
            'expired_at' => $expiredAt,
            'is_active'  => isset($_POST['is_active']) ? 1 : 0,
            'description'=> trim($_POST['description'] ?? ''),
        ];

        if ($action === 'create') {
            // cek duplikat
            if (db_val("SELECT 1 FROM vouchers WHERE code=?", [$code])) {
                flash('error', "Kode voucher '{$code}' sudah ada.");
                redirect('vouchers.php');
            }
            $data['uses_count'] = 0;
            db_insert('vouchers', $data);
            flash('success', "Voucher {$code} berhasil dibuat.");
        } else {
            db_update('vouchers', $data, 'id=?', [(int)$_POST['id']]);
            flash('success', "Voucher {$code} berhasil diupdate.");
        }
        redirect('vouchers.php');
    }

    if ($action === 'toggle') {
        $v = db_row("SELECT * FROM vouchers WHERE id=?", [(int)$_POST['id']]);
        if ($v) db_update('vouchers', ['is_active' => $v['is_active'] ? 0 : 1], 'id=?', [(int)$_POST['id']]);
        flash('success', 'Status voucher diubah.');
        redirect('vouchers.php');
    }

    if ($action === 'delete') {
        db_query("DELETE FROM vouchers WHERE id=?", [(int)$_POST['id']]);
        flash('success', 'Voucher dihapus.');
        redirect('vouchers.php');
    }
}

$vouchers = db_rows("SELECT * FROM vouchers ORDER BY created_at DESC");
$editId   = (int)($_GET['edit'] ?? 0);
$editV    = $editId ? db_row("SELECT * FROM vouchers WHERE id=?", [$editId]) : null;

require_once __DIR__ . '/../includes/admin_header.php';
?>

<div class="grid-2" style="align-items:start">

  <!-- Form tambah/edit voucher -->
  <div class="card">
    <div class="card-title" style="margin-bottom:18px"><?= $editV ? '✏️ Edit Voucher' : '🏷️ Tambah Voucher Baru' ?></div>

    <form method="POST">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="<?= $editV ? 'update' : 'create' ?>">
      <?php if ($editV): ?><input type="hidden" name="id" value="<?= $editV['id'] ?>"><?php endif; ?>

      <div class="form-group">
        <label class="form-label">Kode Voucher</label>
        <input type="text" name="code" class="form-input no-icon" placeholder="Contoh: HEMAT20"
               required maxlength="30" style="text-transform:uppercase"
               oninput="this.value=this.value.toUpperCase()"
               value="<?= e($editV['code'] ?? '') ?>">
        <div style="font-size:11px;color:var(--muted);margin-top:4px">Huruf kapital, angka, strip. 3–30 karakter.</div>
      </div>

      <div class="form-group">
        <label class="form-label">Deskripsi (opsional)</label>
        <input type="text" name="description" class="form-input no-icon" placeholder="Keterangan voucher..."
               value="<?= e($editV['description'] ?? '') ?>">
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Tipe Diskon</label>
          <select name="type" class="form-select" onchange="toggleValueHint(this.value)">
            <option value="percent" <?= ($editV['type'] ?? '') === 'percent' || !$editV ? 'selected' : '' ?>>Persen (%)</option>
            <option value="flat"    <?= ($editV['type'] ?? '') === 'flat' ? 'selected' : '' ?>>Nominal (Rp)</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Nilai Diskon <span id="valueHint" style="color:var(--muted);font-size:11px">(1–100 untuk %)</span></label>
          <input type="number" name="value" class="form-input no-icon" placeholder="20"
                 step="any" min="0" required value="<?= $editV['value'] ?? '' ?>">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Maks Penggunaan <span style="color:var(--muted);font-size:11px">(kosong = tak terbatas)</span></label>
          <input type="number" name="uses_left" class="form-input no-icon" placeholder="100" min="0"
                 value="<?= $editV !== null && $editV['uses_left'] !== null ? $editV['uses_left'] : '' ?>">
        </div>
        <div class="form-group">
          <label class="form-label">Berlaku Hingga <span style="color:var(--muted);font-size:11px">(kosong = selamanya)</span></label>
          <input type="date" name="expired_at" class="form-input no-icon"
                 value="<?= $editV && $editV['expired_at'] ? date('Y-m-d', strtotime($editV['expired_at'])) : '' ?>">
        </div>
      </div>

      <div class="form-group" style="display:flex;align-items:center;gap:8px;padding-bottom:8px">
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13.5px;color:var(--txt)">
          <input type="checkbox" name="is_active" value="1" style="accent-color:var(--cyan)"
                 <?= (!isset($editV) || ($editV['is_active'] ?? 1)) ? 'checked' : '' ?>>
          Aktifkan voucher
        </label>
      </div>

      <div style="display:flex;gap:10px">
        <button type="submit" class="btn btn-primary"><?= $editV ? '💾 Simpan' : '➕ Buat Voucher' ?></button>
        <?php if ($editV): ?><a href="vouchers.php" class="btn btn-outline">Batal</a><?php endif; ?>
      </div>
    </form>
  </div>

  <!-- Daftar voucher -->
  <div class="card">
    <div class="card-title" style="margin-bottom:16px">Daftar Voucher (<?= count($vouchers) ?>)</div>
    <?php foreach ($vouchers as $v): ?>
    <div style="background:var(--card2);border:1px solid var(--border);border-radius:10px;padding:14px;margin-bottom:10px">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px">
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
            <code style="background:rgba(0,212,255,.1);color:var(--cyan);padding:3px 8px;border-radius:5px;font-size:13px;font-weight:700"><?= e($v['code']) ?></code>
            <?= status_badge($v['is_active'] ? 'active' : 'banned') ?>
          </div>
          <?php if ($v['description']): ?>
          <div style="font-size:12px;color:var(--muted);margin-top:4px"><?= e($v['description']) ?></div>
          <?php endif; ?>
          <div style="font-size:12px;color:var(--txt);margin-top:6px">
            <?php if ($v['type'] === 'percent'): ?>
              🏷️ Diskon <strong style="color:var(--cyan)"><?= (int)$v['value'] ?>%</strong>
            <?php else: ?>
              🏷️ Diskon <strong style="color:var(--cyan)">Rp <?= number_format($v['value'],0,',','.') ?></strong>
            <?php endif; ?>
          </div>
          <div style="font-size:11px;color:var(--muted);margin-top:4px;display:flex;gap:12px;flex-wrap:wrap">
            <span>📊 Dipakai: <strong><?= (int)$v['uses_count'] ?>x</strong></span>
            <span>🔢 Sisa: <strong><?= $v['uses_left'] === null ? '∞' : (int)$v['uses_left'] ?></strong></span>
            <?php if ($v['expired_at']): ?>
            <span>⏱ Sampai: <strong><?= date('d/m/Y', strtotime($v['expired_at'])) ?></strong></span>
            <?php else: ?>
            <span>⏱ <strong>Selamanya</strong></span>
            <?php endif; ?>
          </div>
        </div>
        <div style="display:flex;flex-direction:column;gap:6px;align-items:flex-end;flex-shrink:0">
          <div style="display:flex;gap:5px">
            <a href="?edit=<?= $v['id'] ?>" class="btn btn-outline btn-sm">✏️</a>
            <form method="POST" style="display:inline">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="id" value="<?= $v['id'] ?>">
              <button class="btn btn-yellow btn-sm"><?= $v['is_active'] ? 'Nonaktif' : 'Aktifkan' ?></button>
            </form>
            <form method="POST" style="display:inline" onsubmit="return confirm('Hapus voucher <?= e($v['code']) ?>?')">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= $v['id'] ?>">
              <button class="btn btn-danger btn-sm">🗑</button>
            </form>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (!$vouchers): ?>
    <div style="text-align:center;color:var(--muted);padding:30px">
      <div style="font-size:40px;margin-bottom:12px">🏷️</div>
      <div>Belum ada voucher. Buat voucher pertama di form sebelah.</div>
    </div>
    <?php endif; ?>
  </div>

</div>

<script>
function toggleValueHint(type) {
  document.getElementById('valueHint').textContent = type === 'percent' ? '(1–100 untuk %)' : '(nominal rupiah)';
}
</script>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
