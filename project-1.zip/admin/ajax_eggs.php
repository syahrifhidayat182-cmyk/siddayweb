<?php
// admin/ajax_eggs.php — endpoint AJAX untuk load eggs dari Pterodactyl
require_once __DIR__ . '/../includes/init.php';
require_admin();
require_once __DIR__ . '/../includes/pterodactyl.php';

header('Content-Type: application/json');

if (empty(setting('ptero_url')) || empty(setting('ptero_api_key'))) {
    echo json_encode(['error' => 'Pterodactyl URL atau API Key belum diisi di Pengaturan.']);
    exit;
}

try {
    $eggs = ptero()->getAllNestsAndEggs();
    echo json_encode(['eggs' => $eggs]);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
