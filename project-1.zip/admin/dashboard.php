<?php
require_once __DIR__ . '/../functions.php';
requireAdmin();
$db = db();
$stats = [
    'users'   => (int)$db->query('SELECT COUNT(*) FROM users WHERE role="user"')->fetchColumn(),
    'orders'  => (int)$db->query('SELECT COUNT(*) FROM orders')->fetchColumn(),
    'revenue' => (int)$db->query('SELECT COALESCE(SUM(amount),0) FROM orders WHERE status="completed"')->fetchColumn(),
    'pending' => (int)$db->query('SELECT COUNT(*) FROM topups WHERE status="pending"')->fetchColumn(),
];
$recentOrders = $db->query('SELECT o.*,u.name as uname,p.name as pname FROM orders o JOIN users u ON o.user_id=u.id JOIN products p ON o.product_id=p.id ORDER BY o.created_at DESC LIMIT 8')->fetchAll();
$recentTopups = $db->query('SELECT t.*,u.name as uname FROM topups t JOIN users u ON t.user_id=u.id WHERE t.status="pending" ORDER BY t.created_at DESC LIMIT 6')->fetchAll();
$admin = currentUser(); $initials = strtoupper(substr($admin['name'], 0, 2));

function adminSidebar(string $active = ''): void { global $admin, $initials; $pc = (int)db()->query('SELECT COUNT(*) FROM topups WHERE status="pending"')->fetchColumn(); ?>
<aside class="sidebar admin-sidebar" id="sidebar">
<div class="sidebar-logo"><div class="logo-name"><?= e(setting('site_name', APP_NAME)) ?></div><div class="logo-sub">Admin Panel</div></div>
<nav class="sidebar-nav">
<span class="nav-label">Overview</span>
<a href="dashboard.php" class="nav-item <?= $active==='dashboard'?'active':'' ?>"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5a1 1 0 011-1h4a1 1 0 011 1v5a1 1 0 01-1 1H5a1 1 0 01-1-1V5zm10 0a1 1 0 011-1h4a1 1 0 011 1v2a1 1 0 01-1 1h-4a1 1 0 01-1-1V5zM4 15a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1H5a1 1 0 01-1-1v-4zm10-3a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1h-4a1 1 0 01-1-1v-7z"/></svg>Dashboard</a>
<span class="nav-label">Manajemen</span>
<a href="users.php" class="nav-item <?= $active==='users'?'active':'' ?>"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>Users</a>
<a href="products.php" class="nav-item <?= $active==='products'?'active':'' ?>"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>Produk</a>
<a href="topups.php" class="nav-item <?= $active==='topups'?'active':'' ?>"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/></svg>Konfirmasi Topup<?php if($pc>0): ?><span class="nav-badge"><?= $pc ?></span><?php endif ?></a>
<a href="orders.php" class="nav-item <?= $active==='orders'?'active':'' ?>"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>Semua Order</a>
<span class="nav-label">Sistem</span>
<a href="settings.php" class="nav-item <?= $active==='settings'?'active':'' ?>"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>Pengaturan</a>
<a href="../dashboard.php" class="nav-item"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>Kembali ke User</a>
</nav>
<div class="sidebar-footer"><div class="user-box"><div class="user-av" style="background:var(--orange);color:#fff;"><?= $initials ?></div><div style="flex:1;min-width:0;"><div class="user-name"><?= e(mb_substr($admin['name'],0,16)) ?></div><div class="user-role" style="color:var(--orange);">Administrator</div></div>
<form method="POST" action="../logout.php"><?= csrfField() ?><button type="submit" class="btn-logout"><svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg></button></form>
</div></div></aside>
<?php }
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard — <?= e(setting('site_name', APP_NAME)) ?></title>
<link rel="stylesheet" href="../assets/css/style.css"></head>
<body class="has-sidebar"><div class="layout">
<?php adminSidebar('dashboard') ?>
<div class="main">
<div class="topbar"><span class="topbar-title">Dashboard Admin</span><div class="topbar-right"><?= date('d M Y, H:i') ?></div></div>
<div class="page">
<?php foreach (getFlash('success') as $m): ?><div class="alert alert-success"><svg fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg><?= e($m) ?></div><?php endforeach ?>
<div class="stats-grid">
<div class="stat orange"><div class="stat-lbl">Total Users</div><div class="stat-val"><?= $stats['users'] ?></div><div class="stat-sub"><a href="users.php">Kelola →</a></div></div>
<div class="stat green"><div class="stat-lbl">Total Order</div><div class="stat-val"><?= $stats['orders'] ?></div><div class="stat-sub"><a href="orders.php">Lihat →</a></div></div>
<div class="stat cyan"><div class="stat-lbl">Revenue</div><div class="stat-val" style="font-size:16px;"><?= rupiah($stats['revenue']) ?></div><div class="stat-sub">dari order selesai</div></div>
<div class="stat yellow"><div class="stat-lbl">Topup Pending</div><div class="stat-val"><?= $stats['pending'] ?></div><div class="stat-sub"><a href="topups.php">Konfirmasi →</a></div></div>
</div>
<div class="grid-2">
<div class="card mb-0"><div class="card-title">Order Terbaru <a href="orders.php" class="btn btn-outline btn-sm">Semua</a></div>
<div class="table-wrap"><table><thead><tr><th>Kode</th><th>User</th><th>Paket</th><th>Status</th></tr></thead><tbody>
<?php foreach ($recentOrders as $o): ?><tr><td style="font-family:'Space Mono',monospace;font-size:10px;color:var(--cyan);"><?= e($o['order_code']) ?></td><td><?= e($o['uname']) ?></td><td><?= e($o['pname']) ?></td><td><?= statusBadge($o['status']) ?></td></tr><?php endforeach ?>
</tbody></table></div></div>
<div class="card mb-0"><div class="card-title">Topup Pending <a href="topups.php" class="btn btn-primary btn-sm">Kelola</a></div>
<?php if ($recentTopups): ?><div class="table-wrap"><table><thead><tr><th>Kode</th><th>User</th><th>Nominal</th><th>Aksi</th></tr></thead><tbody>
<?php foreach ($recentTopups as $t): ?><tr><td style="font-family:'Space Mono',monospace;font-size:10px;"><?= e($t['topup_code']) ?></td><td><?= e($t['uname']) ?></td><td style="color:var(--cyan);font-family:'Space Mono',monospace;font-size:11px;"><?= rupiah((int)$t['amount']) ?></td>
<td><a href="topups.php?quick_confirm=<?= $t['id'] ?>&csrf=<?= csrfToken() ?>" class="btn btn-success btn-sm" onclick="return confirm('Konfirmasi topup ini?')">✓ Konfirmasi</a></td></tr>
<?php endforeach ?></tbody></table></div>
<?php else: ?><div class="empty-state" style="padding:30px;"><p>Tidak ada topup pending</p></div><?php endif ?></div>
</div></div></div></div></div>
</body></html>
