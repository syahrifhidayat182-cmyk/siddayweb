<?php
require_once __DIR__ . '/../includes/init.php';
require_admin();
$pageTitle = 'Semua Order';

$filter = $_GET['status'] ?? 'all';
$page   = max(1,(int)($_GET['page']??1));
$result = paginate(
    "SELECT o.*,u.name as user_name,u.email,p.name as product_name
     FROM orders o JOIN users u ON o.user_id=u.id JOIN products p ON o.product_id=p.id" .
    ($filter!=='all' ? " WHERE o.status='$filter'" : "") .
    " ORDER BY o.created_at DESC",
    [], $page
);

require_once __DIR__ . '/../includes/admin_header.php';
?>

<div style="display:flex;gap:8px;margin-bottom:18px">
  <?php foreach(['all'=>'Semua','completed'=>'✅ Selesai','processing'=>'⚡ Proses','failed'=>'❌ Gagal'] as $k=>$v): ?>
  <a href="?status=<?= $k ?>" class="btn <?= $filter===$k?'btn-primary':'btn-outline' ?> btn-sm"><?= $v ?></a>
  <?php endforeach; ?>
</div>

<div class="card">
  <div class="card-title" style="margin-bottom:16px">Order (<?= $result['total'] ?>)</div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Kode</th><th>User</th><th>Produk</th><th>Harga</th><th>Status</th><th>Server</th><th>Tgl Beli</th><th>Expired</th></tr></thead>
      <tbody>
      <?php foreach ($result['rows'] as $o): ?>
        <tr>
          <td><span style="font-family:'Space Mono',monospace;font-size:11px;color:var(--cyan)"><?= e($o['order_code']) ?></span></td>
          <td>
            <div><?= e($o['user_name']) ?></div>
            <div style="font-size:11px;color:var(--muted)"><?= e($o['email']) ?></div>
          </td>
          <td><?= e($o['product_name']) ?></td>
          <td style="font-weight:600"><?= rupiah((int)$o['amount']) ?></td>
          <td><?= status_badge($o['status']) ?></td>
          <td>
            <?php if($o['server_identifier']): ?>
            <span style="font-family:'Space Mono',monospace;font-size:11px;color:var(--cyan)"><?= e($o['server_identifier']) ?></span>
            <?php elseif($o['failed_reason']): ?>
            <span style="font-size:11px;color:var(--red)" title="<?= e($o['failed_reason']) ?>">⚠ Lihat</span>
            <?php else: ?><span style="color:var(--dim)">—</span><?php endif; ?>
          </td>
          <td style="color:var(--muted);font-size:12px"><?= date('d M Y',strtotime($o['created_at'])) ?></td>
          <td style="font-size:12px">
            <?php if (!empty($o['expired_at'])): ?>
              <?php $expired = strtotime($o['expired_at']) < time(); ?>
              <span style="color:<?= $expired ? '#f87171' : 'var(--cyan)' ?>;font-weight:600">
                <?= date('d M Y', strtotime($o['expired_at'])) ?>
              </span>
              <?php if ($expired): ?><br><span style="font-size:10px;color:#f87171">EXPIRED</span><?php endif; ?>
            <?php else: ?><span style="color:var(--dim)">—</span><?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php if($result['pages']>1): ?>
  <div class="pagination">
    <?php for($i=1;$i<=$result['pages'];$i++): ?>
    <a href="?status=<?= $filter ?>&page=<?= $i ?>" class="<?= $i===$result['page']?'pg-active':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
