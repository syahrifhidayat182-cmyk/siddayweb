<?php
require_once __DIR__ . '/../includes/init.php';
require_admin();
require_once __DIR__ . '/../includes/pterodactyl.php';

$pteroUrl = setting('ptero_url');
$pteroKey = setting('ptero_api_key');
$keyType  = '';
if (str_starts_with($pteroKey, 'ptla_')) $keyType = '✅ Application Key (ptla_) — BENAR untuk buat server';
elseif (str_starts_with($pteroKey, 'pltc_')) $keyType = '❌ Client Key (pltc_) — SALAH! Harus pakai Application Key';
else $keyType = '⚠️ Format tidak dikenal';

// Test: ambil list servers
function ptero_raw(string $method, string $endpoint, array $body = []): array {
    $url = rtrim(setting('ptero_url'), '/') . '/api/application' . $endpoint;
    $ch  = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . setting('ptero_api_key'),
            'Content-Type: application/json',
            'Accept: application/json',
        ],
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    if ($body) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    $res  = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    return ['code' => $code, 'body' => $res, 'error' => $err, 'data' => json_decode($res, true)];
}

$eggId   = (int)($_GET['egg_id'] ?? 0);
$nestId  = (int)($_GET['nest_id'] ?? 0);
$testNests = ptero_raw('GET', '/nests');
$testNodes = ptero_raw('GET', '/nodes');
$testEgg   = ($eggId && $nestId) ? ptero_raw('GET', "/nests/$nestId/eggs/$eggId?include=variables") : null;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Debug Pterodactyl</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:#07080d;color:#dde2f0;padding:30px;min-height:100vh}
h1{font-size:20px;margin-bottom:24px;color:#ff6b35}
h2{font-size:14px;font-family:'Space Mono',monospace;color:#6b7a99;text-transform:uppercase;letter-spacing:2px;margin:24px 0 10px}
.card{background:#0c0d15;border:1px solid #1a1d2e;border-radius:10px;padding:18px;margin-bottom:16px}
.row{display:flex;gap:10px;align-items:center;margin-bottom:8px;font-size:14px}
.label{color:#6b7a99;width:140px;flex-shrink:0;font-family:'Space Mono',monospace;font-size:11px}
.val{color:#dde2f0}
.ok{color:#00e676} .err{color:#ff4444} .warn{color:#ffd600}
.code{font-family:'Space Mono',monospace;font-size:12px;background:#07080d;border:1px solid #1a1d2e;
      border-radius:6px;padding:12px;white-space:pre-wrap;word-break:break-all;max-height:300px;overflow-y:auto;margin-top:8px}
.badge{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;font-family:'Space Mono',monospace}
.badge-ok{background:rgba(0,230,118,.1);border:1px solid rgba(0,230,118,.3);color:#00e676}
.badge-err{background:rgba(255,68,68,.1);border:1px solid rgba(255,68,68,.3);color:#ff4444}
form{display:flex;gap:10px;margin-top:12px;flex-wrap:wrap}
input{background:#07080d;border:1px solid #1a1d2e;border-radius:6px;padding:8px 12px;
      color:#dde2f0;font-size:13px;width:120px}
button{background:#ff6b35;color:#fff;border:none;border-radius:6px;padding:8px 16px;
       cursor:pointer;font-size:13px;font-weight:600}
table{width:100%;border-collapse:collapse;font-size:13px;margin-top:8px}
th{padding:8px 12px;text-align:left;font-family:'Space Mono',monospace;font-size:10px;
   color:#3d4a60;border-bottom:1px solid #1a1d2e;text-transform:uppercase}
td{padding:10px 12px;border-bottom:1px solid rgba(26,29,46,.5);color:#dde2f0}
a{color:#ff6b35;text-decoration:none}
</style>
</head>
<body>
<a href="settings.php" style="font-size:13px;color:#6b7a99">← Kembali ke Settings</a>
<h1 style="margin-top:16px">🔍 Debug Pterodactyl API</h1>

<!-- Konfigurasi -->
<h2>Konfigurasi</h2>
<div class="card">
  <div class="row"><span class="label">Panel URL</span><span class="val"><?= $pteroUrl ?: '<em style="color:#3d4a60">Belum diisi</em>' ?></span></div>
  <div class="row"><span class="label">API Key</span><span class="val"><?= $pteroKey ? (substr($pteroKey,0,10).'...'.substr($pteroKey,-4)) : '<em style="color:#3d4a60">Belum diisi</em>' ?></span></div>
  <div class="row"><span class="label">Tipe Key</span><span class="val <?= str_contains($keyType,'BENAR')?'ok':(str_contains($keyType,'SALAH')?'err':'warn') ?>"><?= $keyType ?></span></div>
</div>

<?php if (str_starts_with($pteroKey, 'pltc_')): ?>
<div class="card" style="border-color:rgba(255,68,68,.4);background:rgba(255,68,68,.06)">
  <div class="err" style="font-weight:600;margin-bottom:8px">⛔ API Key Salah!</div>
  <div style="font-size:13.5px;line-height:1.8;color:#aaa">
    Anda menggunakan <strong style="color:#ff4444">Client API Key (pltc_)</strong> — ini hanya bisa dipakai oleh user untuk kontrol server mereka sendiri.<br><br>
    Untuk buat server otomatis, Anda perlu <strong style="color:#00e676">Application API Key (ptla_)</strong>.<br><br>
    <strong>Cara buat Application API Key:</strong><br>
    1. Login ke panel Pterodactyl sebagai <strong>admin</strong><br>
    2. Klik avatar → <strong>Admin Area</strong> (bukan Profile)<br>
    3. Di sidebar kiri → <strong>Application API</strong><br>
    4. Klik <strong>Create New</strong> → beri deskripsi → Create<br>
    5. Copy key yang diawali <code style="color:#00e676">ptla_</code><br>
    6. Paste di <a href="settings.php">Settings → Pterodactyl API Key</a>
  </div>
</div>
<?php endif; ?>

<!-- Test koneksi: Nests -->
<h2>Test API — Nests (Egg Categories)</h2>
<div class="card">
  <div class="row">
    <span class="label">HTTP Status</span>
    <span class="badge <?= $testNests['code'] === 200 ? 'badge-ok' : 'badge-err' ?>"><?= $testNests['code'] ?></span>
    <?php if($testNests['code']===200): ?>
    <span class="ok" style="font-size:13px">✅ Koneksi berhasil!</span>
    <?php else: ?>
    <span class="err" style="font-size:13px">❌ Gagal terhubung</span>
    <?php endif; ?>
  </div>
  <?php if ($testNests['code'] === 200 && !empty($testNests['data']['data'])): ?>
  <table>
    <tr><th>Nest ID</th><th>Nama</th><th>Deskripsi</th><th>Aksi</th></tr>
    <?php foreach($testNests['data']['data'] as $n): $a=$n['attributes']; ?>
    <tr>
      <td><code><?= $a['id'] ?></code></td>
      <td><?= htmlspecialchars($a['name']) ?></td>
      <td style="color:#6b7a99;font-size:12px"><?= htmlspecialchars(substr($a['description']??'',0,50)) ?></td>
      <td><a href="?nest_id=<?= $a['id'] ?>&show_eggs=1">Lihat Eggs →</a></td>
    </tr>
    <?php endforeach; ?>
  </table>
  <?php else: ?>
  <div class="code"><?= htmlspecialchars($testNests['body']) ?></div>
  <?php endif; ?>
</div>

<!-- Lihat eggs dari nest -->
<?php if (isset($_GET['show_eggs']) && isset($_GET['nest_id'])): ?>
<?php $nid=(int)$_GET['nest_id']; $testEggs=ptero_raw('GET',"/nests/$nid/eggs?include=variables"); ?>
<h2>Eggs di Nest #<?= $nid ?></h2>
<div class="card">
  <?php if ($testEggs['code']===200 && !empty($testEggs['data']['data'])): ?>
  <table>
    <tr><th>Egg ID</th><th>Nama</th><th>Required Variables</th><th>Aksi</th></tr>
    <?php foreach($testEggs['data']['data'] as $egg): $a=$egg['attributes'];
      $vars=$a['relationships']['variables']['data']??[];
      $reqVars=array_filter($vars,fn($v)=>str_contains($v['attributes']['rules']??'','required'));
    ?>
    <tr>
      <td><code><?= $a['id'] ?></code></td>
      <td><?= htmlspecialchars($a['name']) ?></td>
      <td>
        <?php foreach($reqVars as $v): ?>
        <span style="display:inline-block;background:rgba(255,214,0,.1);border:1px solid rgba(255,214,0,.3);color:#ffd600;
              font-family:'Space Mono',monospace;font-size:10px;padding:1px 6px;border-radius:4px;margin:2px">
          <?= htmlspecialchars($v['attributes']['env_variable']) ?>
        </span>
        <?php endforeach; ?>
        <?php if(!$reqVars): ?><span style="color:#3d4a60">tidak ada</span><?php endif; ?>
      </td>
      <td><a href="?nest_id=<?= $nid ?>&egg_id=<?= $a['id'] ?>">Detail →</a></td>
    </tr>
    <?php endforeach; ?>
  </table>
  <?php else: ?>
  <div class="code"><?= htmlspecialchars($testEggs['body']) ?></div>
  <?php endif; ?>
</div>
<?php endif; ?>

<!-- Detail egg + variables -->
<?php if ($testEgg): ?>
<h2>Detail Egg #<?= $eggId ?> (Nest #<?= $nestId ?>)</h2>
<div class="card">
  <?php if ($testEgg['code']===200): $a=$testEgg['data']['attributes'];
    $vars=$a['relationships']['variables']['data']??[]; ?>
  <div class="row"><span class="label">Nama Egg</span><span class="val ok"><?= htmlspecialchars($a['name']) ?></span></div>
  <div class="row"><span class="label">Docker Image</span><span class="val" style="font-size:12px;font-family:'Space Mono',monospace"><?= htmlspecialchars($a['docker_image']??'') ?></span></div>
  <div class="row"><span class="label">Startup</span><span class="val" style="font-size:12px;font-family:'Space Mono',monospace"><?= htmlspecialchars($a['startup']??'') ?></span></div>

  <?php if($vars): ?>
  <div style="margin-top:14px;font-size:12px;color:#6b7a99;font-family:'Space Mono',monospace;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">Environment Variables</div>
  <table>
    <tr><th>Env Variable</th><th>Default Value</th><th>Required</th><th>Rules</th></tr>
    <?php foreach($vars as $v): $va=$v['attributes']; $req=str_contains($va['rules']??'','required'); ?>
    <tr>
      <td><code style="color:<?= $req?'#ffd600':'#dde2f0' ?>"><?= htmlspecialchars($va['env_variable']) ?></code></td>
      <td style="font-family:'Space Mono',monospace;font-size:11px;color:#6b7a99"><?= htmlspecialchars($va['default_value']??'') ?></td>
      <td><?= $req ? '<span class="badge badge-err">REQUIRED</span>' : '<span style="color:#3d4a60">optional</span>' ?></td>
      <td style="font-size:11px;color:#3d4a60"><?= htmlspecialchars($va['rules']??'') ?></td>
    </tr>
    <?php endforeach; ?>
  </table>

  <div style="margin-top:14px;font-size:13px;color:#6b7a99">
    📋 Copy JSON ini ke field <strong>Environment</strong> saat tambah produk:<br>
    <div class="code"><?php
      $env=[];
      foreach($vars as $v){ $va=$v['attributes']; $env[$va['env_variable']]=$va['default_value']??''; }
      echo htmlspecialchars(json_encode($env,JSON_PRETTY_PRINT));
    ?></div>
  </div>
  <?php endif; ?>
  <?php else: ?>
  <div class="code"><?= htmlspecialchars($testEgg['body']) ?></div>
  <?php endif; ?>
</div>
<?php endif; ?>

<!-- Test Nodes -->
<h2>Test API — Nodes</h2>
<div class="card">
  <div class="row">
    <span class="label">HTTP Status</span>
    <span class="badge <?= $testNodes['code']===200?'badge-ok':'badge-err' ?>"><?= $testNodes['code'] ?></span>
  </div>
  <?php if($testNodes['code']===200 && !empty($testNodes['data']['data'])): ?>
  <table>
    <tr><th>Node ID</th><th>Nama</th><th>Memory</th><th>Disk</th><th>Status</th></tr>
    <?php foreach($testNodes['data']['data'] as $n): $a=$n['attributes']; ?>
    <tr>
      <td><code><?= $a['id'] ?></code></td>
      <td><?= htmlspecialchars($a['name']) ?></td>
      <td><?= number_format($a['memory']) ?> MB</td>
      <td><?= number_format($a['disk']) ?> MB</td>
      <td><span class="<?= $a['maintenance_mode']?'err':'ok' ?>"><?= $a['maintenance_mode']?'Maintenance':'Online' ?></span></td>
    </tr>
    <?php endforeach; ?>
  </table>
  <?php else: ?>
  <div class="code"><?= htmlspecialchars($testNodes['body']) ?></div>
  <?php endif; ?>
</div>

</body>
</html>
