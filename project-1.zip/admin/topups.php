<?php
require_once __DIR__ . '/../includes/init.php';
require_admin();
$pageTitle = 'Konfirmasi Topup';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $id     = (int)($_POST['topup_id'] ?? 0);
    $action = $_POST['action'] ?? '';
    $topup  = db_row("SELECT * FROM topups WHERE id=?", [$id]);

    if ($topup && $topup['status'] === 'pending') {
        if ($action === 'confirm') {
            db_update('topups', [
                'status'       => 'confirmed',
                'confirmed_by' => $_SESSION['user_id'],
                'confirmed_at' => date('Y-m-d H:i:s'),
                'admin_note'   => $_POST['note'] ?? '',
            ], 'id=?', [$id]);
            balance_credit($topup['user_id'], (int)$topup['amount'], 'topup',
                           $topup['topup_code'], 'Top up dikonfirmasi admin', $_SESSION['user_id']);
            flash('success', "Topup {$topup['topup_code']} dikonfirmasi. Saldo user bertambah " . rupiah((int)$topup['amount']));
        } elseif ($action === 'reject') {
            $reason = trim($_POST['reason'] ?? 'Ditolak oleh admin.');
            db_update('topups', [
                'status'       => 'rejected',
                'confirmed_by' => $_SESSION['user_id'],
                'confirmed_at' => date('Y-m-d H:i:s'),
                'admin_note'   => $reason,
            ], 'id=?', [$id]);
            flash('success', "Topup {$topup['topup_code']} ditolak.");
        }
    }
    redirect('topups.php');
}

$filter = $_GET['status'] ?? 'pending';
$page   = max(1, (int)($_GET['page'] ?? 1));
$result = paginate(
    "SELECT t.*,u.name as user_name,u.email FROM topups t JOIN users u ON t.user_id=u.id" .
    ($filter !== 'all' ? " WHERE t.status='$filter'" : "") .
    " ORDER BY t.created_at DESC",
    [], $page
);

require_once __DIR__ . '/../includes/admin_header.php';
?>

<!-- Filter tabs -->
<div style="display:flex;gap:8px;margin-bottom:18px">
  <?php foreach(['pending'=>'⏳ Pending','confirmed'=>'✅ Confirmed','rejected'=>'❌ Rejected','all'=>'📋 Semua'] as $k=>$v): ?>
  <a href="?status=<?= $k ?>" class="btn <?= $filter===$k?'btn-primary':'btn-outline' ?> btn-sm"><?= $v ?></a>
  <?php endforeach; ?>
</div>

<div class="card">
  <div class="card-header">
    <div class="card-title">Daftar Topup (<?= $result['total'] ?>)</div>
  </div>
  <?php if ($result['rows']): ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>User</th><th>Kode</th><th>Nominal</th><th>Status</th><th>Mode</th><th>Bukti</th><th>Tgl</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($result['rows'] as $t): ?>
        <tr>
          <td>
            <div style="font-weight:500"><?= e($t['user_name']) ?></div>
            <div style="font-size:11px;color:var(--muted)"><?= e($t['email']) ?></div>
          </td>
          <td><span style="font-family:'Space Mono',monospace;font-size:11px;color:var(--cyan)"><?= e($t['topup_code']) ?></span></td>
          <td style="color:var(--green);font-weight:700"><?= rupiah((int)$t['amount']) ?></td>
          <td><?= status_badge($t['status']) ?></td>
          <td>
            <?php if (($t['pay_mode'] ?? 'manual') === 'auto'): ?>
              <span style="font-size:11px;font-weight:600;color:var(--cyan);background:rgba(0,212,255,.1);padding:2px 7px;border-radius:20px">⚡ Otomatis</span>
            <?php else: ?>
              <span style="font-size:11px;font-weight:600;color:var(--muted);background:rgba(255,255,255,.06);padding:2px 7px;border-radius:20px">📷 Manual</span>
            <?php endif; ?>
          </td>
          <td>
            <?php if (!empty($t['proof_image'])): ?>
              <a href="<?= BASE_URL ?>/<?= e($t['proof_image']) ?>" target="_blank" class="btn btn-outline btn-sm">📷 Lihat</a>
            <?php elseif (($t['pay_mode'] ?? '') === 'auto'): ?>
              <span style="font-size:11px;color:var(--cyan)">⚡ Auto</span>
            <?php else: ?>
              <span style="font-size:11px;color:var(--muted)">—</span>
            <?php endif; ?>
          </td>
          <td style="color:var(--muted);font-size:12px"><?= date('d M Y H:i', strtotime($t['created_at'])) ?></td>
          <td>
            <?php if ($t['status'] === 'pending' && ($t['pay_mode'] ?? 'manual') === 'auto'): ?>
              <!-- Topup otomatis PaKasir: tidak perlu konfirmasi manual -->
              <span style="font-size:11px;color:var(--cyan)">⚡ Menunggu webhook PaKasir</span>
            <?php elseif ($t['status'] === 'pending'): ?>
            <div style="display:flex;gap:6px">
              <form method="POST">
                <?= csrf_field() ?>
                <input type="hidden" name="topup_id" value="<?= $t['id'] ?>">
                <input type="hidden" name="action" value="confirm">
                <button class="btn btn-success btn-sm" onclick="return confirm('Konfirmasi topup <?= rupiah((int)$t['amount']) ?>?')">✓ Konfirmasi</button>
              </form>
              <form method="POST" onsubmit="return confirmReject(this)">
                <?= csrf_field() ?>
                <input type="hidden" name="topup_id" value="<?= $t['id'] ?>">
                <input type="hidden" name="action" value="reject">
                <input type="hidden" name="reason" id="reason_<?= $t['id'] ?>" value="">
                <button type="submit" class="btn btn-danger btn-sm">✗ Tolak</button>
              </form>
            </div>
            <?php else: ?>
            <span style="font-size:12px;color:var(--muted)"><?= $t['admin_note'] ? e(mb_strimwidth($t['admin_note'],0,30,'…')) : '—' ?></span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php if ($result['pages'] > 1): ?>
  <div class="pagination">
    <?php for ($i = 1; $i <= $result['pages']; $i++): ?>
      <a href="?status=<?= $filter ?>&page=<?= $i ?>" class="<?= $i===$result['page']?'pg-active':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
  <?php else: ?>
  <div style="text-align:center;padding:36px;color:var(--muted)">Tidak ada data.</div>
  <?php endif; ?>
</div>

<script>
function confirmReject(form) {
  var reason = prompt('Alasan penolakan:','Bukti tidak valid.');
  if (reason === null) return false;
  form.querySelector('[name=reason]').value = reason || 'Ditolak oleh admin.';
  return true;
}
</script>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
