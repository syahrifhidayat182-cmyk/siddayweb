<?php
require_once __DIR__ . '/../includes/init.php';
require_admin();
$pageTitle = 'Manajemen Users';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $uid    = (int)($_POST['user_id'] ?? 0);
    $action = $_POST['action'] ?? '';
    $target = db_row("SELECT * FROM users WHERE id=? AND role='user'", [$uid]);
    if (!$target) { flash('danger','User tidak ditemukan.'); redirect('users.php'); }

    if ($action === 'adjust') {
        $amount = (int)preg_replace('/[^0-9]/','',$_POST['amount']??'');
        $type   = $_POST['adj_type'] ?? 'add';
        $note   = trim($_POST['note'] ?? 'Adjustment oleh admin');
        if ($amount > 0) {
            if ($type === 'add') balance_credit($uid,$amount,'adjustment_add','',  $note,$_SESSION['user_id']);
            else                 balance_debit( $uid,$amount,'adjustment_deduct','', $note,$_SESSION['user_id']);
            flash('success',"Saldo user {$target['name']} berhasil diubah.");
        }
    } elseif (in_array($action,['active','suspended','banned'])) {
        db_update('users',['status'=>$action],'id=?',[$uid]);
        flash('success',"Status user {$target['name']} diubah ke {$action}.");
    }
    redirect('users.php');
}

$search = trim($_GET['q'] ?? '');
$page   = max(1,(int)($_GET['page']??1));
$sql    = "SELECT * FROM users WHERE role='user'" . ($search ? " AND (name LIKE ? OR email LIKE ?)" : "") . " ORDER BY created_at DESC";
$params = $search ? ["%$search%","%$search%"] : [];
$result = paginate($sql, $params, $page);

require_once __DIR__ . '/../includes/admin_header.php';
?>

<form method="GET" style="display:flex;gap:10px;margin-bottom:18px">
  <div class="input-wrap" style="flex:1;max-width:360px">
    <svg class="input-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
    <input type="text" name="q" class="form-input" placeholder="Cari nama atau email..." value="<?= e($search) ?>">
  </div>
  <button class="btn btn-primary">Cari</button>
  <?php if($search): ?><a href="users.php" class="btn btn-outline">Reset</a><?php endif; ?>
</form>

<div class="card">
  <div class="card-header">
    <div class="card-title">Users (<?= $result['total'] ?>)</div>
  </div>
  <div class="table-wrap">
    <table>
      <thead><tr><th>User</th><th>Saldo</th><th>Status</th><th>Tgl Daftar</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($result['rows'] as $u): ?>
        <tr>
          <td>
            <div style="font-weight:500"><?= e($u['name']) ?></div>
            <div style="font-size:11px;color:var(--muted)"><?= e($u['email']) ?></div>
          </td>
          <td style="color:var(--cyan);font-weight:600;font-family:'Space Mono',monospace"><?= rupiah((int)$u['balance']) ?></td>
          <td><?= status_badge($u['status']) ?></td>
          <td style="color:var(--muted);font-size:12px"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
          <td>
            <div style="display:flex;gap:6px;flex-wrap:wrap">
              <!-- Adjust saldo -->
              <button onclick="openAdjust(<?= $u['id'] ?>, '<?= e(addslashes($u['name'])) ?>', <?= $u['balance'] ?>)"
                class="btn btn-yellow btn-sm">💰 Saldo</button>
              <!-- Status -->
              <form method="POST" style="display:inline">
                <?= csrf_field() ?>
                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <?php if ($u['status'] === 'active'): ?>
                <input type="hidden" name="action" value="suspended">
                <button class="btn btn-danger btn-sm" onclick="return confirm('Suspend user ini?')">Suspend</button>
                <?php else: ?>
                <input type="hidden" name="action" value="active">
                <button class="btn btn-success btn-sm" onclick="return confirm('Aktifkan user ini?')">Aktifkan</button>
                <?php endif; ?>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php if ($result['pages'] > 1): ?>
  <div class="pagination">
    <?php for ($i = 1; $i <= $result['pages']; $i++): ?>
      <a href="?q=<?= urlencode($search) ?>&page=<?= $i ?>" class="<?= $i===$result['page']?'pg-active':'' ?>"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<!-- Modal adjust saldo -->
<div id="adjustModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:999;align-items:center;justify-content:center">
  <div style="background:var(--card);border:1px solid var(--border);border-radius:14px;padding:28px;width:100%;max-width:420px;margin:20px">
    <div style="font-family:'Syne',sans-serif;font-size:17px;font-weight:700;margin-bottom:5px">Adjust Saldo</div>
    <div id="adjustUserInfo" style="font-size:13px;color:var(--muted);margin-bottom:22px"></div>
    <form method="POST">
      <?= csrf_field() ?>
      <input type="hidden" name="user_id" id="adj_uid">
      <input type="hidden" name="action" value="adjust">
      <div class="form-group">
        <label class="form-label">Tipe</label>
        <div style="display:flex;gap:10px">
          <label style="display:flex;align-items:center;gap:7px;cursor:pointer;font-size:14px;color:var(--green)">
            <input type="radio" name="adj_type" value="add" checked style="accent-color:var(--green)"> + Tambah
          </label>
          <label style="display:flex;align-items:center;gap:7px;cursor:pointer;font-size:14px;color:var(--red)">
            <input type="radio" name="adj_type" value="deduct" style="accent-color:var(--red)"> − Kurangi
          </label>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Nominal</label>
        <input type="number" name="amount" class="form-input no-icon" placeholder="Masukkan nominal" min="1" required>
      </div>
      <div class="form-group">
        <label class="form-label">Catatan</label>
        <input type="text" name="note" class="form-input no-icon" placeholder="Alasan adjustment" value="Adjustment oleh admin">
      </div>
      <div style="display:flex;gap:10px;margin-top:6px">
        <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center">Simpan</button>
        <button type="button" onclick="closeAdjust()" class="btn btn-outline" style="flex:1;justify-content:center">Batal</button>
      </div>
    </form>
  </div>
</div>

<script>
function openAdjust(uid, name, balance) {
  document.getElementById('adj_uid').value = uid;
  document.getElementById('adjustUserInfo').textContent = name + ' — Saldo: Rp ' + balance.toLocaleString('id');
  document.getElementById('adjustModal').style.display = 'flex';
}
function closeAdjust() {
  document.getElementById('adjustModal').style.display = 'none';
}
</script>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
