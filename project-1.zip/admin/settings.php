<?php
require_once __DIR__ . '/../includes/init.php';
require_admin();
$pageTitle = 'Pengaturan';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['action'] ?? '';

    if ($action === 'general') {
        setting_set('site_name',        trim($_POST['site_name']??''));
        setting_set('site_desc',        trim($_POST['site_desc']??''));
        setting_set('announcement',     trim($_POST['announcement']??''));
        setting_set('maintenance',      isset($_POST['maintenance'])?'1':'0');
        setting_set('maintenance_msg',  trim($_POST['maintenance_msg']??''));
        setting_set('min_topup',        (string)(int)($_POST['min_topup']??10000));
        setting_set('topup_expiry_hours',(string)(int)($_POST['topup_expiry_hours']??24));
        flash('success','Pengaturan disimpan.');
    }
    if ($action === 'ptero') {
        setting_set('ptero_url',     rtrim(trim($_POST['ptero_url']??''),'/'));
        setting_set('ptero_api_key', trim($_POST['ptero_api_key']??''));
        flash('success','Konfigurasi Pterodactyl disimpan.');
    }
    if ($action === 'pakasir') {
        setting_set('pakasir_api_key', trim($_POST['pakasir_api_key']??''));
        setting_set('pakasir_project', trim($_POST['pakasir_project']??''));
        setting_set('pakasir_enabled', isset($_POST['pakasir_enabled'])?'1':'0');
        flash('success','Konfigurasi PaKasir disimpan.');
    }
    if ($action === 'security') {
        setting_set('recaptcha_site_key',    trim($_POST['recaptcha_site_key']??''));
        setting_set('recaptcha_secret_key',  trim($_POST['recaptcha_secret_key']??''));
        setting_set('recaptcha_enabled',     isset($_POST['recaptcha_enabled'])?'1':'0');
        setting_set('login_max_attempts',    (string)max(3,(int)($_POST['login_max_attempts']??5)));
        setting_set('login_lockout_minutes', (string)max(1,(int)($_POST['login_lockout_minutes']??15)));
        // Blacklist domain — bersihkan spasi & lowercase
        $rawDomains = $_POST['blocked_email_domains'] ?? '';
        $cleanDomains = implode(',', array_filter(array_map(
            function($d) { return preg_replace('/[^a-z0-9\-\.]/', '', strtolower(trim($d))); },
            explode(',', str_replace(["\n", ";", " "], ',', $rawDomains))
        )));
        setting_set('blocked_email_domains', $cleanDomains);
        flash('success','Pengaturan keamanan disimpan.');
    }
    if ($action === 'qris' && !empty($_FILES['qris_file']['name'])) {
        try {
            $filename = upload_image($_FILES['qris_file'], UPLOAD_QRIS);
            setting_set('qris_image','uploads/qris/'.$filename);
            flash('success','Gambar QRIS berhasil diupload.');
        } catch(Exception $e) { flash('danger',$e->getMessage()); }
    }
    redirect('settings.php');
}

require_once __DIR__ . '/../includes/admin_header.php';
?>

<div class="grid-2" style="align-items:start">
  <!-- Kolom kiri -->
  <div>
    <!-- General settings -->
    <div class="card" style="margin-bottom:16px">
      <div class="card-title" style="margin-bottom:18px">⚙️ Pengaturan Umum</div>
      <form method="POST">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="general">
        <div class="form-group"><label class="form-label">Nama Website</label>
          <input type="text" name="site_name" class="form-input no-icon" value="<?= e(setting('site_name')) ?>"></div>
        <div class="form-group"><label class="form-label">Deskripsi</label>
          <input type="text" name="site_desc" class="form-input no-icon" value="<?= e(setting('site_desc')) ?>"></div>
        <div class="form-group"><label class="form-label">Pengumuman (kosongkan jika tidak ada)</label>
          <textarea name="announcement" class="form-textarea"><?= e(setting('announcement')) ?></textarea></div>
        <div class="form-group"><label class="form-label">Minimal Top Up (Rp)</label>
          <input type="number" name="min_topup" class="form-input no-icon" value="<?= setting('min_topup','10000') ?>"></div>
        <div class="form-group"><label class="form-label">Batas Waktu Top Up Manual (jam)</label>
          <input type="number" name="topup_expiry_hours" class="form-input no-icon" value="<?= setting('topup_expiry_hours','24') ?>"></div>
        <div class="form-group">
          <label style="display:flex;align-items:center;gap:9px;cursor:pointer;font-size:13.5px;color:var(--txt)">
            <input type="checkbox" name="maintenance" value="1" style="accent-color:var(--cyan)" <?= setting('maintenance')==='1'?'checked':'' ?>>
            Mode Maintenance
          </label>
        </div>
        <div class="form-group"><label class="form-label">Pesan Maintenance</label>
          <input type="text" name="maintenance_msg" class="form-input no-icon" value="<?= e(setting('maintenance_msg','Website sedang dalam pemeliharaan.')) ?>"></div>
        <button type="submit" class="btn btn-primary">💾 Simpan</button>
      </form>
    </div>

    <!-- PaKasir Payment Gateway -->
    <div class="card" style="margin-bottom:16px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px">
        <div class="card-title">⚡ PaKasir Payment Gateway</div>
        <?php if(setting('pakasir_enabled')==='1'): ?>
        <span class="badge badge-green">Aktif</span>
        <?php else: ?>
        <span class="badge badge-red">Nonaktif</span>
        <?php endif; ?>
      </div>

      <div style="background:rgba(0,212,255,.06);border:1px solid rgba(0,212,255,.15);border-radius:8px;padding:14px;margin-bottom:18px;font-size:13px;line-height:1.8;color:#6b84a8">
        <strong style="color:#dde2f0">PaKasir</strong> adalah payment gateway Indonesia yang mendukung QRIS dan Virtual Account semua bank.<br>
        Dengan PaKasir, top up saldo user dikonfirmasi <strong style="color:#00e676">otomatis 24/7</strong> tanpa perlu konfirmasi manual admin.<br>
        <a href="https://pakasir.com" target="_blank" style="color:var(--cyan)">→ Daftar di pakasir.com</a> (gratis, hanya bayar per transaksi)
      </div>

      <form method="POST">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="pakasir">
        <div class="form-group">
          <label class="form-label">Project Slug</label>
          <input type="text" name="pakasir_project" class="form-input no-icon"
                 placeholder="nama-project-anda"
                 value="<?= e(setting('pakasir_project')) ?>">
          <div style="font-size:11px;color:var(--muted);margin-top:4px">Slug project di dashboard PaKasir (bukan URL, hanya slug-nya)</div>
        </div>
        <div class="form-group">
          <label class="form-label">API Key</label>
          <input type="text" name="pakasir_api_key" class="form-input no-icon"
                 placeholder="xxx123..."
                 value="<?= e(setting('pakasir_api_key')) ?>">
          <div style="font-size:11px;color:var(--muted);margin-top:4px">Dapatkan API Key di dashboard → detail project PaKasir</div>
        </div>
        <div class="form-group">
          <label style="display:flex;align-items:center;gap:9px;cursor:pointer;font-size:13.5px;color:var(--txt)">
            <input type="checkbox" name="pakasir_enabled" value="1" style="accent-color:var(--cyan)" <?= setting('pakasir_enabled')==='1'?'checked':'' ?>>
            Aktifkan pembayaran otomatis via PaKasir
          </label>
        </div>
        <button type="submit" class="btn btn-primary">💾 Simpan</button>
      </form>

      <!-- Webhook URL info -->
      <?php $webhookUrl = APP_URL . '/webhook-pakasir.php'; ?>
      <div style="margin-top:18px;padding:14px;background:rgba(0,0,0,.2);border-radius:8px">
        <div style="font-size:12px;color:var(--muted);margin-bottom:8px;font-weight:600;text-transform:uppercase;letter-spacing:1px">📡 Webhook URL</div>
        <div style="display:flex;align-items:center;gap:8px">
          <code style="flex:1;font-size:12px;color:var(--cyan);word-break:break-all;font-family:'Space Mono',monospace"><?= e($webhookUrl) ?></code>
          <button onclick="copyWebhook()" class="btn btn-outline btn-sm" id="whCopyBtn">📋</button>
        </div>
        <div style="font-size:11px;color:var(--muted);margin-top:8px;line-height:1.7">
          Paste URL di atas ke <strong>Edit Proyek → Webhook URL</strong> di dashboard PaKasir.<br>
          Webhook ini yang akan menerima notifikasi pembayaran otomatis.
        </div>
      </div>

      <!-- Setup guide -->
      <div style="margin-top:14px;font-size:13px;color:var(--muted);line-height:1.9">
        <strong style="color:var(--txt)">Cara setup:</strong><br>
        1. Daftar/login di <a href="https://pakasir.com" target="_blank" style="color:var(--cyan)">pakasir.com</a> → Buat Proyek baru<br>
        2. Copy <strong>Slug</strong> dan <strong>API Key</strong> dari detail proyek → Isi di form atas<br>
        3. Di dashboard PaKasir → Edit Proyek → Webhook URL → Paste URL webhook di atas<br>
        4. Centang "Aktifkan" → Simpan<br>
        5. Test dengan mode Sandbox sebelum production
      </div>
    </div>

    <!-- Pterodactyl config -->
    <div class="card">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px">
        <div class="card-title">🦕 Konfigurasi Pterodactyl</div>
        <a href="debug_ptero.php" class="btn btn-outline btn-sm" target="_blank">🔍 Debug & Test API</a>
      </div>

      <div style="background:rgba(0,212,255,.06);border:1px solid rgba(0,212,255,.15);border-radius:8px;padding:14px;margin-bottom:18px;font-size:13px;line-height:1.8;color:#6b84a8">
        <strong style="color:#dde2f0">Pterodactyl punya 2 jenis API Key:</strong><br>
        <span style="color:#00e676">✅ Application Key (ptla_)</span> — Dibuat di <strong>Admin Area → Application API</strong>. Digunakan sistem ini untuk buat server otomatis.<br>
        <span style="color:#6b84a8">ℹ️ Client Key (pltc_)</span> — Hanya untuk kontrol server milik sendiri.<br>
        <strong style="color:#ffd600">Pastikan menggunakan ptla_ (Application Key)!</strong>
      </div>

      <form method="POST">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="ptero">
        <div class="form-group">
          <label class="form-label">Panel URL</label>
          <input type="url" name="ptero_url" class="form-input no-icon"
                 placeholder="https://panel.domain.com"
                 value="<?= e(setting('ptero_url')) ?>">
        </div>
        <div class="form-group">
          <label class="form-label">Application API Key <span style="color:#00e676">(ptla_...)</span></label>
          <input type="text" name="ptero_api_key" class="form-input no-icon"
                 placeholder="ptla_xxxxxxxxxxxxxxxxxxxx"
                 value="<?= e(setting('ptero_api_key')) ?>">
          <div style="font-size:11px;margin-top:4px">
            <?php $k=setting('ptero_api_key');
            if((strpos($k, 'ptla_') === 0))      echo '<span style="color:#00e676">✅ Application Key — Benar!</span>';
            elseif((strpos($k, 'pltc_') === 0))  echo '<span style="color:#ff4444">❌ Ini Client Key! Harus pakai Application Key (ptla_)</span>';
            elseif($k)                           echo '<span style="color:#ffd600">⚠️ Format tidak dikenal</span>';
            else                                 echo '<span style="color:#3d5470">Belum diisi</span>'; ?>
          </div>
        </div>
        <div style="display:flex;gap:10px">
          <button type="submit" class="btn btn-primary">💾 Simpan</button>
          <a href="debug_ptero.php" target="_blank" class="btn btn-outline">🔍 Test Koneksi</a>
        </div>
      </form>
    </div>
  </div>

  <!-- Kolom kanan: QRIS Upload -->
  <div class="card">
    <div class="card-title" style="margin-bottom:18px">📱 Upload Gambar QRIS (Manual)</div>
    <div style="font-size:13px;color:var(--muted);margin-bottom:14px">
      QRIS ini digunakan untuk top up manual (jika PaKasir tidak aktif).
    </div>
    <?php $qris = setting('qris_image'); ?>
    <?php if($qris && file_exists(__DIR__.'/../'.$qris)): ?>
    <div style="text-align:center;margin-bottom:18px">
      <img src="<?= BASE_URL ?>/<?= e($qris) ?>" style="max-width:100%;max-height:300px;border-radius:10px;border:1px solid var(--border)">
      <div style="font-size:12px;color:var(--muted);margin-top:8px">QRIS aktif saat ini</div>
    </div>
    <?php else: ?>
    <div style="text-align:center;padding:30px;color:var(--muted);margin-bottom:16px">Belum ada QRIS diupload.</div>
    <?php endif; ?>
    <form method="POST" enctype="multipart/form-data">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="qris">
      <div style="border:2px dashed var(--border);border-radius:10px;padding:20px;text-align:center;margin-bottom:14px">
        <div style="font-size:24px;margin-bottom:6px">📷</div>
        <div style="font-size:13px;color:var(--muted)">Pilih gambar QRIS baru</div>
        <input type="file" name="qris_file" accept="image/*" style="margin-top:12px;color:var(--muted);font-size:13px">
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">Upload QRIS Baru</button>
    </form>

<!-- ══ Security & reCAPTCHA ══ -->
<div class="card" style="margin-top:24px">
  <div class="card-header">
    <div class="card-title">🛡️ Keamanan &amp; Anti Brute Force</div>
  </div>
  <form method="POST">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="security">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
      <div class="form-group">
        <label class="form-label">Maks. Percobaan Login Gagal</label>
        <input type="number" name="login_max_attempts" class="form-input no-icon"
               value="<?= e(setting('login_max_attempts','5')) ?>" min="3" max="20">
        <div style="font-size:11px;color:var(--muted);margin-top:4px">Default: 5 percobaan</div>
      </div>
      <div class="form-group">
        <label class="form-label">Durasi Lockout (menit)</label>
        <input type="number" name="login_lockout_minutes" class="form-input no-icon"
               value="<?= e(setting('login_lockout_minutes','15')) ?>" min="1" max="1440">
        <div style="font-size:11px;color:var(--muted);margin-top:4px">Default: 15 menit</div>
      </div>
    </div>

    <div style="border-top:1px solid var(--border);padding-top:16px;margin-bottom:16px">
      <div style="font-weight:600;margin-bottom:12px;font-size:14px">Google reCAPTCHA v3</div>
      <div style="background:rgba(0,212,255,.04);border:1px solid rgba(0,212,255,.15);border-radius:8px;padding:12px;font-size:12px;color:var(--muted);margin-bottom:14px">
        reCAPTCHA v3 bekerja secara <strong style="color:var(--txt)">invisible</strong> — tidak ada kotak centang yang mengganggu user.
        Daftar di <a href="https://www.google.com/recaptcha/admin/create" target="_blank" style="color:var(--cyan)">google.com/recaptcha</a>
        → pilih <strong>reCAPTCHA v3</strong> → masukkan domain Anda.
      </div>
      <label style="display:flex;align-items:center;gap:10px;margin-bottom:14px;cursor:pointer">
        <input type="checkbox" name="recaptcha_enabled" value="1"
               style="accent-color:var(--cyan);width:16px;height:16px"
               <?= setting('recaptcha_enabled')==='1'?'checked':'' ?>>
        <span style="font-size:13.5px;font-weight:600">Aktifkan reCAPTCHA v3 di halaman Login &amp; Register</span>
      </label>
      <div class="form-group">
        <label class="form-label">Site Key <span style="color:var(--muted);font-weight:400">(publik)</span></label>
        <input type="text" name="recaptcha_site_key" class="form-input no-icon"
               placeholder="6Lc..." value="<?= e(setting('recaptcha_site_key')) ?>">
      </div>
      <div class="form-group" style="margin-bottom:0">
        <label class="form-label">Secret Key <span style="color:var(--muted);font-weight:400">(rahasia)</span></label>
        <input type="text" name="recaptcha_secret_key" class="form-input no-icon"
               placeholder="6Lc..." value="<?= e(setting('recaptcha_secret_key')) ?>">
      </div>
    </div>

    <div class="form-group" style="margin-top:16px;border-top:1px solid var(--border);padding-top:16px">
      <label class="form-label">🚫 Blacklist Domain Email Tambahan</label>
      <textarea name="blocked_email_domains" class="form-textarea" rows="3"
                placeholder="exploit.io, tempmail.com, spambot.net (pisah dengan koma)"
                style="font-family:'Space Mono',monospace;font-size:12px"><?= e(setting('blocked_email_domains')) ?></textarea>
      <div style="font-size:11px;color:var(--muted);margin-top:4px">
        Pisahkan dengan koma. Ratusan domain spam/disposable sudah diblokir otomatis oleh sistem.
        Tambahkan domain khusus yang ingin Anda blokir di sini.
      </div>
    </div>

    <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">
      💾 Simpan Pengaturan Keamanan
    </button>
  </form>
</div>

  </div>
</div>

<script>
function copyWebhook() {
  navigator.clipboard.writeText('<?= e($webhookUrl) ?>');
  document.getElementById('whCopyBtn').textContent = '✅';
  setTimeout(() => document.getElementById('whCopyBtn').textContent = '📋', 2000);
}
</script>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>