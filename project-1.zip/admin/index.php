<?php
require_once __DIR__ . '/../includes/init.php';
require_admin();
$pageTitle = 'Dashboard';

$totalUsers    = (int)db_val("SELECT COUNT(*) FROM users WHERE role='user'");
$totalRevenue  = (int)db_val("SELECT COALESCE(SUM(amount),0) FROM topups WHERE status='confirmed'");
$pendingTopups = (int)db_val("SELECT COUNT(*) FROM topups WHERE status='pending'");
$totalOrders   = (int)db_val("SELECT COUNT(*) FROM orders");
$recentTopups  = db_rows("SELECT t.*,u.name as user_name FROM topups t JOIN users u ON t.user_id=u.id WHERE t.status='pending' ORDER BY t.created_at DESC LIMIT 8");
$recentOrders  = db_rows("SELECT o.*,u.name as user_name,p.name as product_name FROM orders o JOIN users u ON o.user_id=u.id JOIN products p ON o.product_id=p.id ORDER BY o.created_at DESC LIMIT 8");

require_once __DIR__ . '/../includes/admin_header.php';
?>

<div class="grid-4" style="margin-bottom:22px">
  <div class="stat-card c-cyan">
    <div class="stat-label">Total Users</div>
    <div class="stat-val"><?= $totalUsers ?></div>
    <div class="stat-sub"><a href="users.php" style="color:var(--cyan);text-decoration:none">Kelola →</a></div>
  </div>
  <div class="stat-card c-green">
    <div class="stat-label">Total Revenue</div>
    <div class="stat-val"><?= rupiah($totalRevenue) ?></div>
    <div class="stat-sub">dari topup confirmed</div>
  </div>
  <div class="stat-card c-yellow">
    <div class="stat-label">Topup Pending</div>
    <div class="stat-val"><?= $pendingTopups ?></div>
    <div class="stat-sub"><a href="topups.php" style="color:var(--cyan);text-decoration:none">Konfirmasi →</a></div>
  </div>
  <div class="stat-card c-red">
    <div class="stat-label">Total Order</div>
    <div class="stat-val"><?= $totalOrders ?></div>
    <div class="stat-sub"><a href="orders.php" style="color:var(--cyan);text-decoration:none">Lihat semua →</a></div>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <div class="card-header">
      <div class="card-title">⚡ Topup Menunggu Konfirmasi</div>
      <a href="topups.php" class="btn btn-outline btn-sm">Lihat Semua</a>
    </div>
    <?php if ($recentTopups): ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>User</th><th>Nominal</th><th>Kode</th><th>Aksi</th></tr></thead>
        <tbody>
        <?php foreach ($recentTopups as $t): ?>
          <tr>
            <td><?= e($t['user_name']) ?></td>
            <td style="color:var(--green);font-weight:600"><?= rupiah((int)$t['amount']) ?></td>
            <td><span style="font-family:'Space Mono',monospace;font-size:10px;color:var(--muted)"><?= e($t['topup_code']) ?></span></td>
            <td>
              <form method="POST" action="topups.php" style="display:inline">
                <?= csrf_field() ?>
                <input type="hidden" name="topup_id" value="<?= $t['id'] ?>">
                <input type="hidden" name="action" value="confirm">
                <button class="btn btn-success btn-sm" onclick="return confirm('Konfirmasi topup ini?')">✓</button>
              </form>
              <a href="topups.php" class="btn btn-outline btn-sm">Detail</a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
    <div style="text-align:center;padding:24px;color:var(--muted)">Tidak ada topup pending 🎉</div>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="card-header">
      <div class="card-title">Order Terbaru</div>
      <a href="orders.php" class="btn btn-outline btn-sm">Lihat Semua</a>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>User</th><th>Produk</th><th>Status</th><th>Tgl</th></tr></thead>
        <tbody>
        <?php foreach ($recentOrders as $o): ?>
          <tr>
            <td><?= e($o['user_name']) ?></td>
            <td style="font-size:13px"><?= e($o['product_name']) ?></td>
            <td><?= status_badge($o['status']) ?></td>
            <td style="color:var(--muted);font-size:12px"><?= date('d/m/y', strtotime($o['created_at'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/admin_footer.php'; ?>
