<?php
// webhook-pakasir.php — Webhook handler dari PaKasir
// Isi URL ini di dashboard PaKasir → Edit Proyek → Webhook URL:
// https://yourdomain.com/webhook-pakasir.php

require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/pakasir.php';

ob_end_clean();
ini_set('display_errors', 0);
header('Content-Type: application/json');

// Tangani GET (ping/verifikasi dari PaKasir atau browser test)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    http_response_code(200);
    echo json_encode(['status' => 'ok', 'message' => 'Webhook endpoint active']);
    exit;
}

// Hanya proses POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Baca body — PaKasir bisa kirim JSON atau form-encoded
$raw  = file_get_contents('php://input');
$data = null;

// Coba parse JSON dulu
if (!empty($raw)) {
    $data = json_decode($raw, true);
}

// Fallback ke $_POST jika bukan JSON
if (empty($data)) {
    $data = $_POST;
    $raw  = json_encode($_POST);
}

// Log SEMUA request masuk untuk debugging
$logFile = __DIR__ . '/logs/pakasir_webhook.log';
if (!is_dir(dirname($logFile))) mkdir(dirname($logFile), 0755, true);
file_put_contents($logFile,
    "\n[" . date('Y-m-d H:i:s') . "] IP=" . ($_SERVER['REMOTE_ADDR'] ?? '?') .
    " METHOD=" . $_SERVER['REQUEST_METHOD'] .
    " BODY=" . $raw . "\n",
    FILE_APPEND
);

// Coba berbagai kemungkinan nama field order_id dari PaKasir
$orderId = $data['order_id']  ?? $data['invoice']   ?? $data['ref'] ?? '';
$status  = $data['status']    ?? $data['pay_status'] ?? '';

if (empty($orderId)) {
    file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] ERROR: order_id kosong\n", FILE_APPEND);
    http_response_code(400);
    echo json_encode(['error' => 'order_id required']);
    exit;
}

// Normalisasi status — PaKasir bisa kirim berbagai nilai
$completedStatuses = ['completed', 'paid', 'success', 'settlement', 'capture'];
$isPaid = in_array(strtolower($status), $completedStatuses);

if (!$isPaid) {
    file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] SKIP: status={$status}\n", FILE_APPEND);
    http_response_code(200);
    echo json_encode(['message' => 'Ignored, status=' . $status]);
    exit;
}

// Cari transaksi di DB
$topup = db_row("SELECT * FROM topups WHERE topup_code=?", [$orderId]);

if (!$topup) {
    file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] ERROR: topup_code={$orderId} tidak ada di DB\n", FILE_APPEND);
    http_response_code(200);
    echo json_encode(['message' => 'Transaction not found: ' . $orderId]);
    exit;
}

// Idempotent — sudah confirmed sebelumnya
if ($topup['status'] === 'confirmed') {
    file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] SKIP: {$orderId} sudah confirmed\n", FILE_APPEND);
    http_response_code(200);
    echo json_encode(['message' => 'Already confirmed']);
    exit;
}

if ($topup['status'] !== 'pending') {
    file_put_contents($logFile, "[" . date('Y-m-d H:i:s') . "] SKIP: {$orderId} status={$topup['status']}\n", FILE_APPEND);
    http_response_code(200);
    echo json_encode(['message' => 'Status is ' . $topup['status']]);
    exit;
}

// Pakai amount dari DB — lebih aman daripada dari webhook (webhook bisa kirim total termasuk fee)
$creditAmount = (int)$topup['amount'];

try {
    db_update('topups', [
        'status'       => 'confirmed',
        'confirmed_at' => date('Y-m-d H:i:s'),
        'admin_note'   => 'Auto-confirmed via PaKasir webhook (status=' . $status . ')',
    ], 'id=?', [(int)$topup['id']]);

    balance_credit(
        (int)$topup['user_id'],
        $creditAmount,
        'topup',
        $topup['topup_code'],
        'Top up via PaKasir (' . ($data['payment_method'] ?? $data['channel'] ?? 'auto') . ')',
        0
    );

    file_put_contents($logFile,
        "[" . date('Y-m-d H:i:s') . "] SUCCESS: order={$orderId} credit={$creditAmount} user={$topup['user_id']}\n",
        FILE_APPEND
    );

    http_response_code(200);
    echo json_encode(['success' => true, 'credited' => $creditAmount]);

} catch (Throwable $e) {
    file_put_contents($logFile,
        "[" . date('Y-m-d H:i:s') . "] EXCEPTION: order={$orderId} msg=" . $e->getMessage() . "\n",
        FILE_APPEND
    );
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
