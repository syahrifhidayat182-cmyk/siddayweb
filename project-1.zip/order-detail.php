<?php
require_once __DIR__ . '/includes/init.php';
require_login();

$user  = current_user();
$id    = (int)($_GET['id'] ?? 0);
$order = db_row("SELECT * FROM orders WHERE id=? AND user_id=?", [$id, $user['id']]);

if (!$order) {
    flash('danger', 'Order tidak ditemukan.');
    redirect('order-history.php');
}

$product = db_row("SELECT * FROM products WHERE id=?", [$order['product_id']]);

$pageTitle = 'Detail Order #' . e($order['order_code']);
require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width:700px;margin:0 auto">
  <div style="margin-bottom:30px">
    <a href="order-history.php" style="color:var(--cyan);text-decoration:none">← Kembali</a>
  </div>

  <!-- Header Order -->
  <div class="card" style="margin-bottom:20px">
    <div style="display:flex;justify-content:space-between;align-items:start">
      <div>
        <div style="font-size:14px;color:var(--muted)">Order Code</div>
        <div style="font-size:20px;font-weight:600;color:#dde2f0;margin-top:4px"><?= e($order['order_code']) ?></div>
      </div>
      <div style="text-align:right">
        <div style="font-size:14px;color:var(--muted)">Status</div>
        <div style="font-size:16px;font-weight:600;margin-top:4px;padding:4px 12px;border-radius:6px;
                    <?php 
                    if ($order['status'] === 'completed') echo 'background:#00e67610;color:#00e676';
                    elseif ($order['status'] === 'failed') echo 'background:#ff444410;color:#ff4444';
                    else echo 'background:#ffd60010;color:#ffd600';
                    ?>
        ">
          <?= ucfirst(e($order['status'])) ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Detail Produk -->
  <?php if ($product): ?>
  <div class="card" style="margin-bottom:20px">
    <div style="font-size:13px;color:var(--muted);text-transform:uppercase;margin-bottom:12px">Produk</div>
    <div style="font-size:16px;font-weight:600;color:#dde2f0"><?= e($product['name']) ?></div>
    <div style="margin-top:16px;display:grid;grid-template-columns:1fr 1fr;gap:16px">
      <div>
        <div style="font-size:12px;color:var(--muted)">Harga Bayar</div>
        <div style="font-size:16px;font-weight:600;color:#00e676;margin-top:4px"><?= rupiah((int)$order['amount']) ?></div>
        <?php if (!empty($order['voucher_code']) && (int)$order['voucher_discount'] > 0): ?>
        <div style="font-size:11px;color:#4ade80;margin-top:3px">🏷️ Voucher <?= e($order['voucher_code']) ?> (-<?= rupiah((int)$order['voucher_discount']) ?>)</div>
        <?php endif; ?>
      </div>
      <div>
        <div style="font-size:12px;color:var(--muted)">Tanggal Order</div>
        <div style="font-size:14px;color:#dde2f0;margin-top:4px"><?= date('d M Y H:i', strtotime($order['created_at'])) ?></div>
      </div>
    </div>
    <?php if (!empty($order['expired_at'])): ?>
    <div style="margin-top:14px;background:<?= strtotime($order['expired_at']) < time() ? 'rgba(248,113,113,.1)' : 'rgba(0,212,255,.06)' ?>;border:1px solid <?= strtotime($order['expired_at']) < time() ? 'rgba(248,113,113,.3)' : 'rgba(0,212,255,.2)' ?>;border-radius:8px;padding:10px 14px">
      <div style="font-size:11px;color:var(--muted);margin-bottom:3px">⏱ MASA AKTIF PANEL</div>
      <div style="font-size:14px;font-weight:700;color:<?= strtotime($order['expired_at']) < time() ? '#f87171' : 'var(--cyan)' ?>">
        <?= date('d M Y H:i', strtotime($order['expired_at'])) ?>
        <?php if (strtotime($order['expired_at']) < time()): ?>
          <span style="font-size:11px;color:#f87171;margin-left:6px">⚠️ SUDAH EXPIRED</span>
        <?php else:
          $sisaHari = ceil((strtotime($order['expired_at']) - time()) / 86400);
        ?>
          <span style="font-size:11px;color:var(--muted);margin-left:6px">(<?= $sisaHari ?> hari lagi)</span>
        <?php endif; ?>
      </div>
      <div style="font-size:11px;color:var(--muted);margin-top:3px">Dibeli: <?= date('d M Y H:i', strtotime($order['created_at'])) ?></div>
    </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <!-- Credentials Panel Jika Completed -->
  <?php if ($order['status'] === 'completed'): 
      $pteroAccount = db_row(
          "SELECT * FROM pterodactyl_accounts WHERE id=?",
          [$order['ptero_account_id']]
      ) ?: [];
  ?>
  <div class="card" style="background:rgba(0,230,118,.08);border-color:rgba(0,230,118,.15);margin-bottom:20px">
    <div class="card-title" style="color:#00e676;margin-bottom:16px">✅ Server Siap Digunakan</div>
    
    <div style="background:#0c0d15;border-radius:8px;padding:16px;margin-bottom:14px">
      <div style="font-size:11px;color:#6b7a99;text-transform:uppercase;margin-bottom:8px">Panel URL</div>
      <div style="font-family:monospace;font-size:13px;word-break:break-all;color:#dde2f0">
        <a href="<?= e($order['panel_url']) ?>" target="_blank" style="color:#ff6b35;text-decoration:none">
          <?= e($order['panel_url']) ?> 🔗
        </a>
      </div>
    </div>
    
    <div style="background:#0c0d15;border-radius:8px;padding:16px;margin-bottom:14px">
      <div style="font-size:11px;color:#6b7a99;text-transform:uppercase;margin-bottom:8px">Email Panel (Username)</div>
      <div style="font-family:monospace;font-size:13px;color:#dde2f0;word-break:break-all">
        <?= e($pteroAccount['email'] ?? $order['ptero_account_email']) ?>
      </div>
      <div style="font-size:11px;color:#6b7a99;margin-top:6px">
        Email untuk login ke panel Pterodactyl
      </div>
    </div>
    
    <div style="background:#0c0d15;border-radius:8px;padding:16px;margin-bottom:14px">
      <div style="font-size:11px;color:#6b7a99;text-transform:uppercase;margin-bottom:8px">Password Panel</div>
      <div style="display:flex;gap:8px;align-items:center">
        <div style="font-family:monospace;font-size:13px;color:#dde2f0;flex:1;word-break:break-all">
          <span id="pass-field">
            <?php echo str_repeat('●', strlen($order['panel_password'])); ?>
          </span>
        </div>
        <button type="button" class="btn btn-sm" onclick="togglePassword()" style="padding:6px 12px;font-size:12px">
          👁️ Lihat
        </button>
      </div>
      <div style="font-size:11px;color:#ffd600;margin-top:6px">
        ⚠️ Simpan password ini dengan aman
      </div>
    </div>

    <div style="background:#0c0d15;border-radius:8px;padding:14px;margin-bottom:14px;
                border-left:3px solid #00e676;font-size:13px;line-height:1.6;color:#dde2f0">
      <strong style="color:#00e676">📝 Cara Login:</strong><br>
      1. Buka URL panel di atas<br>
      2. Masukkan email: <code style="color:#ff6b35;background:rgba(255,107,53,.1);padding:2px 6px"><?= e($pteroAccount['email'] ?? $order['ptero_account_email']) ?></code><br>
      3. Masukkan password: (lihat di atas)<br>
      4. Klik Login & kelola server Anda
    </div>

    <div style="background:rgba(0,212,255,.08);border:1px solid rgba(0,212,255,.15);
                border-radius:8px;padding:12px;font-size:12px;line-height:1.5;color:#dde2f0">
      <strong style="color:#00d4ff">ℹ️ Info:</strong><br>
      • Ini akun panel KHUSUS untuk order ini<br>
      • Anda bisa membuat order baru dengan email panel BERBEDA<br>
      • Setiap order memiliki akun panel terpisah
    </div>
  </div>

  <script>
  function togglePassword() {
      const field = document.getElementById('pass-field');
      const btn = event.target.closest('button');
      if (field.innerHTML.includes('●')) {
          field.innerHTML = '<?= e($order['panel_password']) ?>';
          btn.innerHTML = '👁️‍🗨️ Sembunyikan';
      } else {
          field.innerHTML = '<?php echo str_repeat('●', strlen($order['panel_password'])); ?>';
          btn.innerHTML = '👁️ Lihat';
      }
  }
  </script>

  <?php elseif ($order['status'] === 'failed'): ?>
  <div class="card" style="background:rgba(255,68,68,.08);border-color:rgba(255,68,68,.15)">
    <div class="card-title" style="color:#ff4444;margin-bottom:12px">❌ Pembuatan Server Gagal</div>
    <div style="font-size:13px;line-height:1.6;color:#dde2f0">
      <strong style="color:#ff4444">Error:</strong><br>
      <?= nl2br(e($order['failed_reason'])) ?>
    </div>
    <div style="margin-top:14px;padding:12px;background:#0c0d15;border-radius:8px;font-size:12px;color:#6b7a99">
      Saldo Anda sudah di-refund. Hubungi support jika butuh bantuan.
    </div>
  </div>

  <?php elseif ($order['status'] === 'processing'): ?>
  <div class="card" style="background:rgba(255,214,0,.08);border-color:rgba(255,214,0,.15)">
    <div style="display:flex;align-items:center;gap:12px">
      <div style="font-size:20px">⏳</div>
      <div>
        <div style="color:#ffd600;font-weight:600">Membuat Server...</div>
        <div style="font-size:12px;color:#6b7a99;margin-top:4px">Silahkan tunggu beberapa saat</div>
      </div>
    </div>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>