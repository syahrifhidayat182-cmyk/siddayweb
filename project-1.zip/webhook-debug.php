<?php
// webhook-debug.php — Cek log webhook & test manual
// HAPUS FILE INI setelah selesai debug!
require_once __DIR__ . '/includes/init.php';
require_admin();

$logFile = __DIR__ . '/logs/pakasir_webhook.log';
$log = file_exists($logFile) ? file_get_contents($logFile) : 'Log kosong.';

// Test konfirmasi manual via API
$testResult = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_code'])) {
    require_once __DIR__ . '/includes/pakasir.php';
    $code  = trim($_POST['test_code']);
    $topup = db_row("SELECT * FROM topups WHERE topup_code=?", [$code]);
    if (!$topup) {
        $testResult = "❌ Topup code '{$code}' tidak ditemukan di DB.";
    } else {
        try {
            $pakasir   = pakasir();
            $detail    = $pakasir->getDetail($code, (int)$topup['amount']);
            $testResult = "<pre style='color:#0f0'>" . json_encode($detail, JSON_PRETTY_PRINT) . "</pre>";
            $apiStatus = $detail['transaction']['status'] ?? $detail['status'] ?? $detail['payment']['status'] ?? '';
            $testResult .= "<br><strong>API Status: " . htmlspecialchars($apiStatus) . "</strong>";
            if (in_array(strtolower($apiStatus), ['completed','paid','success','settlement'])) {
                $testResult .= " ✅ Pembayaran sudah selesai di PaKasir!";
                if ($topup['status'] === 'pending') {
                    // Force confirm
                    db_update('topups', [
                        'status'       => 'confirmed',
                        'confirmed_at' => date('Y-m-d H:i:s'),
                        'admin_note'   => 'Force-confirmed via debug tool',
                    ], 'id=?', [(int)$topup['id']]);
                    balance_credit((int)$topup['user_id'], (int)$topup['amount'], 'topup', $code, 'Force confirm debug', 0);
                    $testResult .= "<br>✅ Saldo sudah ditambahkan: " . number_format((int)$topup['amount']);
                } else {
                    $testResult .= " (DB status sudah: {$topup['status']})";
                }
            } else {
                $testResult .= " ⚠️ Belum terbayar di PaKasir.";
            }
        } catch (Exception $e) {
            $testResult = "❌ Error API: " . htmlspecialchars($e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Webhook Debug</title>
<style>body{background:#0a0f1e;color:#dde2f0;font-family:monospace;padding:20px}
pre{background:#111827;padding:16px;border-radius:8px;overflow-x:auto;font-size:12px;max-height:500px;overflow-y:auto;color:#0f0}
input,button{padding:8px 12px;border-radius:6px;border:1px solid #334;background:#111;color:#fff;font-family:monospace}
button{background:#0d9488;cursor:pointer;border:none}.warn{color:#ffd600}</style>
</head><body>
<h2>🔍 Webhook Debug — PaKasir</h2>
<p class="warn">⚠️ Hapus file ini (webhook-debug.php) setelah selesai debug!</p>

<h3>Test Cek Status via API PaKasir</h3>
<form method="POST">
  <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
  <input type="text" name="test_code" placeholder="Topup code (contoh: TOP-20250227-XXXXXX)" style="width:300px">
  <button type="submit">🔍 Cek & Force Confirm jika sudah bayar</button>
</form>
<?php if ($testResult): ?>
<div style="margin-top:16px;padding:14px;background:#111;border-radius:8px"><?= $testResult ?></div>
<?php endif; ?>

<h3 style="margin-top:30px">📋 Log Webhook (<?= $logFile ?>)</h3>
<pre><?= htmlspecialchars($log) ?></pre>

<form method="POST" action="" style="margin-top:10px">
  <input type="hidden" name="csrf_token" value="<?= csrf_token() ?>">
  <input type="hidden" name="clear_log" value="1">
  <button type="submit" onclick="return confirm('Hapus log?')" style="background:#dc2626">🗑 Hapus Log</button>
</form>
<?php
if (!empty($_POST['clear_log'])) {
    file_put_contents($logFile, '');
    echo "<script>location.reload()</script>";
}
?>
</body></html>
