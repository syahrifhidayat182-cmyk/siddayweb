<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/pakasir.php';
require_login();

$user      = current_user();
$pageTitle = 'Top Up Saldo';
$errors    = [];
$minTopup       = (int)setting('min_topup', '10000');
$minTopupManual = (int)setting('min_topup_manual', '10000');

// Mode pembayaran: auto (pakasir) atau manual (qris upload)
$pakasirEnabled = setting('pakasir_api_key') && setting('pakasir_project');

// ── Handle POST ──────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    // Handle cancel topup pending
    if (isset($_POST['cancel_topup'])) {
        $cancelCode = trim($_POST['cancel_topup']);
        $existing = db_row(
            "SELECT * FROM topups WHERE topup_code=? AND user_id=? AND status='pending'",
            [$cancelCode, $user['id']]
        );
        if ($existing) {
            db_update('topups', [
                'status'     => 'canceled',
                'admin_note' => 'Dibatalkan oleh user pada ' . date('Y-m-d H:i:s'),
            ], 'id=?', [(int)$existing['id']]);
            flash('success', 'Top up ' . e($cancelCode) . ' berhasil dibatalkan. Silakan buat top up baru.');
        } else {
            flash('error', 'Transaksi tidak ditemukan atau sudah tidak bisa dibatalkan.');
        }
        redirect('topup.php');
    }

    // Cek apakah ada topup pending — hanya boleh 1 aktif
    $existingPending = db_row(
        "SELECT * FROM topups WHERE user_id=? AND status='pending' LIMIT 1",
        [$user['id']]
    );
    if ($existingPending) {
        $errors[] = 'Anda masih memiliki top up pending <strong>' . e($existingPending['topup_code']) . '</strong>. Lunasi atau batalkan terlebih dahulu sebelum membuat top up baru.';
        // Langsung skip ke render — jangan proses form
        goto render_page;
    }

    $amount = (int)preg_replace('/[^0-9]/', '', $_POST['amount'] ?? '');
    $method = $_POST['pay_method'] ?? 'qris'; // qris | bni_va | bri_va | dll

    $isAutoMode = $pakasirEnabled && ($_POST['mode'] ?? '') === 'auto';
    $minCheck   = $isAutoMode ? $minTopup : $minTopupManual;
    if ($amount < $minCheck) $errors[] = 'Minimal top up ' . rupiah($minCheck) . ($isAutoMode ? ' (otomatis)' : ' (manual)');

    if (!$errors) {
        if ($pakasirEnabled && ($_POST['mode'] ?? '') === 'auto') {
            // ── OTOMATIS via PaKasir ──
            try {
                $code   = gen_code('TOP');
                $pakasir = pakasir();
                $result  = $pakasir->createTransaction($code, $amount, $method);

                if (empty($result['payment'])) {
                    throw new Exception("Gagal membuat transaksi: " . ($result['error'] ?? 'Unknown error'));
                }

                $pay = $result['payment'];
                $expiry = $pay['expired_at'] ?? date('Y-m-d H:i:s', strtotime('+1 hour'));
                // Normalize expired_at ke format MySQL
                $expiredAt = date('Y-m-d H:i:s', strtotime($expiry));

                db_insert('topups', [
                    'user_id'        => $user['id'],
                    'topup_code'     => $code,
                    'amount'         => $amount,
                    'proof_image'    => '',             // tidak perlu upload manual
                    'status'         => 'pending',
                    'pay_method'     => $method,
                    'pay_mode'       => 'auto',
                    'payment_number' => $pay['payment_number'] ?? '',
                    'payment_url'    => $pay['payment_url'] ?? '',
                    'fee'            => (int)($pay['fee'] ?? 0),
                    'total_payment'  => (int)($pay['total_payment'] ?? $amount),
                    'expired_at'     => $expiredAt,
                ]);

                redirect('topup-pay.php?code=' . $code);
            } catch (Exception $e) {
                $errors[] = "PaKasir: " . $e->getMessage();
            }
        } else {
            // ── MANUAL via Upload Bukti ──
            if (empty($_FILES['proof']['name'])) $errors[] = "Bukti transfer wajib diupload.";
            if (!$errors) {
                try {
                    $filename = upload_image($_FILES['proof'], UPLOAD_PROOFS);
                    $code     = gen_code('TOP');
                    $expiry   = (int)setting('topup_expiry_hours', '24');
                    db_insert('topups', [
                        'user_id'     => $user['id'],
                        'topup_code'  => $code,
                        'amount'      => $amount,
                        'proof_image' => 'uploads/proofs/' . $filename,
                        'status'      => 'pending',
                        'pay_method'  => 'manual',
                        'pay_mode'    => 'manual',
                        'expired_at'  => date('Y-m-d H:i:s', strtotime("+{$expiry} hours")),
                    ]);
                    flash('success', "Top up " . rupiah($amount) . " berhasil dikirim dengan kode {$code}. Tunggu konfirmasi admin.");
                    redirect('topup-history.php');
                } catch (Exception $e) {
                    $errors[] = $e->getMessage();
                }
            }
        }
    }
}

render_page:
$qrisImage = setting('qris_image');
$pending   = db_row("SELECT * FROM topups WHERE user_id=? AND status='pending' ORDER BY created_at DESC LIMIT 1", [$user['id']]);

// Daftar metode pembayaran PaKasir yang tersedia
$payMethods = [
    'qris'          => ['label' => 'QRIS',             'icon' => '📱'],
    'bni_va'        => ['label' => 'BNI Virtual Account','icon' => '🏦'],
    'bri_va'        => ['label' => 'BRI Virtual Account','icon' => '🏦'],
    'bca_va'        => ['label' => 'BCA Virtual Account','icon' => '🏦'],
    'mandiri_va'    => ['label' => 'Mandiri Virtual Account','icon' => '🏦'],
    'permata_va'    => ['label' => 'Permata Virtual Account','icon' => '🏦'],
    'cimb_niaga_va' => ['label' => 'CIMB Niaga VA',    'icon' => '🏦'],
];

require_once __DIR__ . '/includes/header.php';
?>

<div class="grid-2" style="align-items:start">

  <!-- Form top up -->
  <div class="card">
    <div class="card-header"><div class="card-title">💰 Form Top Up Saldo</div></div>

    <?php if ($errors): ?>
    <div class="alert alert-danger"><?php foreach($errors as $e) echo '<div>'.htmlspecialchars($e).'</div>'; ?></div>
    <?php endif; ?>

    <?php if ($pending): ?>
    <div class="alert alert-yellow" style="margin-bottom:18px">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap">
        <div>
          ⏳ Anda memiliki top up pending: <strong><?= e($pending['topup_code']) ?></strong>
          (<?= rupiah((int)$pending['amount']) ?>)<br>
          <small style="color:var(--muted)">Selesaikan pembayaran ini terlebih dahulu, atau batalkan untuk membuat top up baru.</small>
          <?php if (!empty($pending['payment_url']) || !empty($pending['payment_number'])): ?>
            <br><a href="<?= BASE_URL ?>/topup-pay.php?code=<?= e($pending['topup_code']) ?>" style="color:var(--cyan);font-weight:600">→ Lanjutkan Bayar</a>
          <?php else: ?>
            <br><span style="font-size:12px;color:var(--muted)">Menunggu konfirmasi admin.</span>
          <?php endif; ?>
        </div>
        <form method="POST" onsubmit="return confirm('Yakin ingin membatalkan top up <?= e($pending['topup_code']) ?>?')">
          <?= csrf_field() ?>
          <input type="hidden" name="cancel_topup" value="<?= e($pending['topup_code']) ?>">
          <button type="submit" class="btn btn-sm" style="background:rgba(255,80,80,.15);color:#ff5050;border:1px solid rgba(255,80,80,.3);white-space:nowrap">
            ✕ Batalkan
          </button>
        </form>
      </div>
    </div>
    <?php endif; ?>

    <?php if ($pending): ?>
    <!-- Form diblokir karena ada pending -->
    <div style="text-align:center;padding:30px 20px;border:2px dashed rgba(255,214,0,.3);border-radius:12px;color:var(--muted)">
      <div style="font-size:32px;margin-bottom:10px">🔒</div>
      <div style="font-weight:600;color:var(--txt);margin-bottom:6px">Form Top Up Dikunci</div>
      <div style="font-size:13px">Selesaikan atau batalkan top up pending di atas untuk membuat top up baru.</div>
    </div>
    <?php else: ?>

    <!-- Tab Mode: Otomatis vs Manual -->
    <?php if ($pakasirEnabled): ?>
    <div style="display:flex;gap:0;border:1px solid var(--border);border-radius:10px;overflow:hidden;margin-bottom:20px">
      <button type="button" id="tabAuto" onclick="switchMode('auto')"
        style="flex:1;padding:10px;font-size:13px;font-weight:600;cursor:pointer;transition:.15s;background:var(--cyan);color:#0a0f1e;border:none">
        ⚡ Otomatis (PaKasir)
      </button>
      <button type="button" id="tabManual" onclick="switchMode('manual')"
        style="flex:1;padding:10px;font-size:13px;font-weight:600;cursor:pointer;transition:.15s;background:transparent;color:var(--muted);border:none">
        📷 Manual (Upload Bukti)
      </button>
    </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" id="topupForm">
      <?= csrf_field() ?>
      <input type="hidden" name="mode" id="modeInput" value="<?= $pakasirEnabled ? 'auto' : 'manual' ?>">

      <div class="form-group">
        <label class="form-label">Nominal Top Up</label>
        <div class="input-wrap">
          <svg class="input-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          <input type="number" name="amount" id="amountInput" class="form-input" placeholder="<?= $minTopup ?>"
                 min="1" value="<?= htmlspecialchars($_POST['amount']??'') ?>" required>
        </div>
        <div style="font-size:12px;color:var(--muted);margin-top:5px" id="minHint">
          Min. otomatis: <strong><?= rupiah($minTopup) ?></strong> &nbsp;·&nbsp; Min. manual: <strong><?= rupiah($minTopupManual) ?></strong>
        </div>
      </div>

      <!-- Nominal cepat -->
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px">
        <?php
        $quickAmounts = array_unique([(int)setting('min_topup_manual','10000'),25000,50000,100000,200000,500000]);
        sort($quickAmounts);
        foreach($quickAmounts as $n): ?>
        <button type="button" onclick="document.getElementById('amountInput').value=<?= $n ?>;updateFee()"
          class="btn btn-outline btn-sm"><?= rupiah($n) ?></button>
        <?php endforeach; ?>
      </div>

      <!-- === MODE OTOMATIS === -->
      <?php if ($pakasirEnabled): ?>
      <div id="autoSection">
        <div class="form-group">
          <label class="form-label">Metode Pembayaran</label>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px" id="methodGrid">
            <?php foreach ($payMethods as $key => $m): ?>
            <label style="display:flex;align-items:center;gap:8px;padding:10px 12px;border:1.5px solid var(--border);border-radius:8px;cursor:pointer;transition:.15s" class="method-card">
              <input type="radio" name="pay_method" value="<?= $key ?>" <?= $key==='qris'?'checked':'' ?> style="accent-color:var(--cyan)" onchange="selectMethod(this)">
              <span style="font-size:16px"><?= $m['icon'] ?></span>
              <span style="font-size:12.5px;font-weight:600"><?= $m['label'] ?></span>
            </label>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Preview biaya -->
        <div id="feeBox" style="background:rgba(0,212,255,.06);border:1px solid rgba(0,212,255,.2);border-radius:10px;padding:14px;margin-bottom:16px;font-size:13px">
          <div style="display:flex;justify-content:space-between;margin-bottom:6px">
            <span style="color:var(--muted)">Nominal Top Up</span>
            <span id="feeNominal" style="color:var(--txt)">—</span>
          </div>
          <div style="display:flex;justify-content:space-between;margin-bottom:6px">
            <span style="color:var(--muted)">Biaya Layanan</span>
            <span id="feeCost" style="color:var(--yellow)">—</span>
          </div>
          <div style="display:flex;justify-content:space-between;border-top:1px solid rgba(0,212,255,.2);padding-top:8px;margin-top:4px">
            <span style="font-weight:700;color:var(--txt)">Total Bayar</span>
            <span id="feeTotal" style="font-weight:700;color:var(--cyan)">—</span>
          </div>
          <div style="font-size:11px;color:var(--muted);margin-top:8px">⚠️ Biaya aktual dihitung saat pembayaran dibuat. Saldo yang masuk sesuai nominal top up.</div>
        </div>

        <button type="submit" id="btnAuto" class="btn btn-primary" style="width:100%;justify-content:center;padding:12px">
          ⚡ Buat Pembayaran Otomatis
        </button>
      </div>
      <?php endif; ?>

      <!-- === MODE MANUAL === -->
      <div id="manualSection" style="<?= $pakasirEnabled ? 'display:none' : '' ?>">
        <div class="form-group">
          <label class="form-label">Bukti Transfer (QRIS)</label>
          <div style="border:2px dashed var(--border);border-radius:10px;padding:20px;text-align:center;cursor:pointer;transition:border-color .15s"
               id="dropzone" onclick="document.getElementById('proofInput').click()">
            <div id="dropzone-text">
              <div style="font-size:28px;margin-bottom:6px">📷</div>
              <div style="font-size:13px;color:var(--muted)">Klik atau drag foto bukti transfer</div>
              <div style="font-size:11px;color:var(--dim);margin-top:3px">JPG, PNG maks <?= UPLOAD_MAX_MB ?>MB</div>
            </div>
            <img id="preview" src="" style="max-width:100%;max-height:200px;display:none;border-radius:8px;margin-top:10px">
          </div>
          <input type="file" name="proof" id="proofInput" accept="image/*" style="display:none" onchange="previewImg(this)">
        </div>
        <button type="submit" id="btnManual" class="btn btn-primary" style="width:100%;justify-content:center;padding:12px">
          Kirim Bukti Transfer
        </button>
      </div>

    </form>
    <?php endif; // end if $pending block ?>
  </div>

  <!-- Info Panel -->
  <div>
    <?php if ($qrisImage && file_exists(__DIR__ . '/' . $qrisImage)): ?>
    <div class="card" id="qrisCard" style="margin-bottom:16px;<?= $pakasirEnabled ? 'display:none' : '' ?>">
      <div class="card-header"><div class="card-title">📱 Scan QRIS untuk Bayar</div></div>
      <div style="text-align:center;padding-bottom:12px">
        <img src="<?= BASE_URL ?>/<?= e($qrisImage) ?>" alt="QRIS" style="max-width:100%;max-height:320px;border-radius:8px;border:1px solid var(--border)">
        <div style="font-size:12px;color:var(--muted);margin-top:8px">Scan QR ini lalu upload bukti bayar di form, bukti tf harus terlihat detail transaksi lengkap</div>
      </div>
    </div>
    <?php endif; ?>

    <?php if ($pakasirEnabled): ?>
    <div class="card" style="margin-bottom:16px">
      <div class="card-title" style="margin-bottom:10px">⚡ Pembayaran Otomatis</div>
      <div style="font-size:13px;color:var(--muted);line-height:1.8">
        Saldo otomatis masuk setelah pembayaran berhasil dikonfirmasi sistem PaKasir.
        Tidak perlu upload bukti atau menunggu konfirmasi admin.
      </div>
      <div style="margin-top:12px;display:flex;align-items:center;gap:8px;font-size:12px;color:var(--green)">
        <span>✅</span> <span>Terima QRIS, Virtual Account semua bank</span>
      </div>
      <div style="display:flex;align-items:center;gap:8px;font-size:12px;color:var(--green)">
        <span>✅</span> <span>Dikonfirmasi otomatis 24/7</span>
      </div>
      <div style="display:flex;align-items:center;gap:8px;font-size:12px;color:var(--yellow)">
        <span>⚠️</span> <span>Ada biaya layanan PaKasir per transaksi</span>
      </div>
    </div>
    <?php endif; ?>

    <div class="card">
      <div class="card-title" style="margin-bottom:12px">Panduan Top Up</div>
      <?php if ($pakasirEnabled): ?>
      <ol style="color:var(--muted);font-size:13.5px;line-height:2;padding-left:18px">
        <li>Masukkan nominal yang ingin di-top up</li>
        <li>Pilih metode pembayaran (QRIS / Virtual Account)</li>
        <li>Klik <strong>Buat Pembayaran Otomatis</strong></li>
        <li>Lakukan pembayaran sesuai instruksi</li>
        <li>Saldo otomatis masuk dalam hitungan menit</li>
      </ol>
      <?php else: ?>
      <ol style="color:var(--muted);font-size:13.5px;line-height:2;padding-left:18px">
        <li>Masukkan nominal yang ingin di-top up</li>
        <li>Scan QRIS di atas menggunakan aplikasi pembayaran</li>
        <li>Screenshot / foto bukti pembayaran</li>
        <li>Upload foto bukti di form ini</li>
        <li>Tunggu konfirmasi admin (maks <?= setting('topup_expiry_hours','24') ?> jam)</li>
        <li>Saldo otomatis masuk setelah dikonfirmasi</li>
      </ol>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
// Estimasi fee QRIS ~1%, VA ~flat 4000
var feeRates = {
  qris: { pct: 0.01, flat: 0 },
  bni_va: { pct: 0, flat: 4000 },
  bri_va: { pct: 0, flat: 4000 },
  bca_va: { pct: 0, flat: 4000 },
  mandiri_va: { pct: 0, flat: 4000 },
  permata_va: { pct: 0, flat: 4000 },
  cimb_niaga_va: { pct: 0, flat: 4000 },
  sampoerna_va: { pct: 0, flat: 4000 },
};

function rupiah(n) {
  return 'Rp ' + Math.round(n).toLocaleString('id-ID');
}

function updateFee() {
  var amount = parseInt(document.getElementById('amountInput').value) || 0;
  var method = document.querySelector('[name=pay_method]:checked')?.value || 'qris';
  var rate   = feeRates[method] || { pct: 0.01, flat: 0 };
  var fee    = Math.ceil(amount * rate.pct) + rate.flat;
  document.getElementById('feeNominal').textContent = rupiah(amount);
  document.getElementById('feeCost').textContent    = '~' + rupiah(fee);
  document.getElementById('feeTotal').textContent   = '~' + rupiah(amount + fee);
}

function selectMethod(el) {
  document.querySelectorAll('.method-card').forEach(c => {
    c.style.borderColor = c.querySelector('input').checked ? 'var(--cyan)' : 'var(--border)';
    c.style.background  = c.querySelector('input').checked ? 'rgba(0,212,255,.06)' : '';
  });
  updateFee();
}

function switchMode(mode) {
  document.getElementById('modeInput').value = mode;
  var qrisCard = document.getElementById('qrisCard');
  if (mode === 'auto') {
    document.getElementById('autoSection').style.display   = '';
    document.getElementById('manualSection').style.display = 'none';
    document.getElementById('tabAuto').style.background    = 'var(--cyan)';
    document.getElementById('tabAuto').style.color         = '#0a0f1e';
    document.getElementById('tabManual').style.background  = 'transparent';
    document.getElementById('tabManual').style.color       = 'var(--muted)';
    if (qrisCard) qrisCard.style.display = 'none';
  } else {
    document.getElementById('autoSection').style.display   = 'none';
    document.getElementById('manualSection').style.display = '';
    document.getElementById('tabManual').style.background  = 'var(--cyan)';
    document.getElementById('tabManual').style.color       = '#0a0f1e';
    document.getElementById('tabAuto').style.background    = 'transparent';
    document.getElementById('tabAuto').style.color         = 'var(--muted)';
    if (qrisCard) qrisCard.style.display = '';
  }
}

function previewImg(input) {
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = e => {
      document.getElementById('preview').src = e.target.result;
      document.getElementById('preview').style.display = 'block';
      document.getElementById('dropzone-text').style.display = 'none';
      document.getElementById('dropzone').style.borderColor = 'var(--cyan)';
    };
    reader.readAsDataURL(input.files[0]);
  }
}

// Init
document.getElementById('amountInput').addEventListener('input', updateFee);
// Highlight selected method on load
setTimeout(() => {
  selectMethod(document.querySelector('[name=pay_method]:checked'));
  updateFee();
}, 50);
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
