<?php
// ── Format rupiah ────────────────────────────────────────────
function rupiah(int $n): string {
    return 'Rp ' . number_format($n, 0, ',', '.');
}

// ── Generate kode unik ───────────────────────────────────────
function gen_code(string $prefix): string {
    return strtoupper($prefix) . '-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
}

// ── Upload gambar ────────────────────────────────────────────
function upload_image(array $file, string $dir): string {
    $allowed = ['jpg','jpeg','png','webp'];
    $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed))        throw new Exception("Format file tidak didukung.");
    if ($file['size'] > UPLOAD_MAX_MB * 1024 * 1024) throw new Exception("Ukuran file terlalu besar (maks ".UPLOAD_MAX_MB."MB).");
    if ($file['error'] !== UPLOAD_ERR_OK)  throw new Exception("Upload gagal.");
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $filename = uniqid('img_', true) . '.' . $ext;
    move_uploaded_file($file['tmp_name'], $dir . $filename);
    return $filename;
}

// ── CSRF ─────────────────────────────────────────────────────
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">';
}
function csrf_verify(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf_token'] ?? ''))
        die("CSRF token tidak valid.");
}

// ── Flash messages ───────────────────────────────────────────
function flash(string $type, string $msg): void {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}
function flash_get(): ?array {
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

// ── Redirect ─────────────────────────────────────────────────
function redirect(string $url): void {
    // Jika sudah absolute URL, langsung pakai
    if (preg_match('/^https?:\/\//i', $url)) {
        header("Location: $url");
        exit;
    }

    // Deteksi apakah file pemanggil ada di subfolder /admin/
    $caller   = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1)[0]['file'] ?? '';
    $isAdmin  = (strpos(str_replace('\\', '/', $caller), '/admin/') !== false);

    // Jika path sudah ada prefix admin/ dari luar, jangan dobel
    $hasAdmin = (strpos($url, 'admin/') === 0) || (strpos($url, '/admin/') === 0);

    if ($isAdmin && !$hasAdmin) {
        // File ada di /admin/, tapi target tidak ada prefix admin → sama-level
        $url = BASE_URL . '/admin/' . ltrim($url, '/');
    } else {
        $url = BASE_URL . '/' . ltrim($url, '/');
    }

    header("Location: $url");
    exit;
}

// Helper: buat URL absolut dari path relatif root
function url(string $path = ''): string {
    return BASE_URL . '/' . ltrim($path, '/');
}

// ── Auth guards ──────────────────────────────────────────────
function require_login(): void {
    if (empty($_SESSION['user_id'])) redirect('login.php');
}
function require_admin(): void {
    require_login();
    if (($_SESSION['user_role'] ?? '') !== 'admin') {
        http_response_code(403); die("Akses ditolak.");
    }
}
function require_guest(): void {
    if (!empty($_SESSION['user_id'])) redirect('dashboard.php');
}

// ── Current user ─────────────────────────────────────────────
function current_user(): ?array {
    static $user = null;
    if ($user === null && !empty($_SESSION['user_id']))
        $user = db_row("SELECT * FROM users WHERE id=?", [$_SESSION['user_id']]);
    return $user;
}

// ── Sanitize output ──────────────────────────────────────────
function e(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

// ── Pagination ───────────────────────────────────────────────
function paginate(string $sql, array $params, int $page, int $perPage=15): array {
    $total   = (int)db_val("SELECT COUNT(*) FROM ($sql) x", $params);
    $pages   = max(1, (int)ceil($total / $perPage));
    $page    = max(1, min($page, $pages));
    $offset  = ($page - 1) * $perPage;
    $rows    = db_rows("$sql LIMIT $perPage OFFSET $offset", $params);
    return compact('rows','total','pages','page','perPage');
}

// ── Badge helpers ────────────────────────────────────────────
function status_badge(string $status): string {
    $map = [
        'pending'    => ['label'=>'Pending',    'class'=>'badge-yellow'],
        'confirmed'  => ['label'=>'Dikonfirmasi','class'=>'badge-green'],
        'rejected'   => ['label'=>'Ditolak',    'class'=>'badge-red'],
        'completed'  => ['label'=>'Selesai',    'class'=>'badge-green'],
        'processing' => ['label'=>'Diproses',   'class'=>'badge-blue'],
        'failed'     => ['label'=>'Gagal',      'class'=>'badge-red'],
        'active'     => ['label'=>'Aktif',      'class'=>'badge-green'],
        'suspended'  => ['label'=>'Suspended',  'class'=>'badge-yellow'],
        'banned'     => ['label'=>'Banned',     'class'=>'badge-red'],
    ];
    $b = $map[$status] ?? ['label'=>ucfirst($status),'class'=>'badge-gray'];
    return '<span class="badge '.$b['class'].'">'.$b['label'].'</span>';
}
