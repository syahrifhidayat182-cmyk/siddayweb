<?php
// includes/init.php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

session_name(SESSION_NAME);
session_start();

// Auto-detect base URL dari server (tidak perlu set manual di config)
if (!defined('BASE_URL')) {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    // Deteksi subfolder: ambil path sampai folder pteroshop
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_FILENAME'] ?? '');
    $docroot= str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT'] ?? '');
    $subdir = trim(str_replace($docroot, '', dirname($script)), '/');
    // Kalau file ada di subfolder, include subfolder
    // Tapi kalau langsung di public_html, subdir kosong
    // Kita deteksi dari SCRIPT_NAME lebih aman
    $scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
    // Ambil base path (semua kecuali filename)
    $basePath = rtrim(dirname($scriptName), '/');
    // Kalau di dalam subfolder /admin, naik satu level
    if (basename(dirname($scriptName)) === 'admin') {
        $basePath = rtrim(dirname($basePath), '/');
    }
    define('BASE_URL', $scheme . '://' . $host . $basePath);
}

// Maintenance mode
if (setting('maintenance') === '1') {
    $allowed = ['login.php', 'logout.php'];
    $isAdmin = ($_SESSION['user_role'] ?? '') === 'admin';
    if (!$isAdmin && !in_array(basename($_SERVER['PHP_SELF']), $allowed)) {
        http_response_code(503);
        $msg = htmlspecialchars(setting('maintenance_msg', 'Website sedang dalam pemeliharaan.'));
        die("<!DOCTYPE html><html><head><meta charset=\'UTF-8\'><title>Maintenance</title>
        <style>body{font-family:sans-serif;background:#0a0e17;color:#eee;display:flex;height:100vh;align-items:center;justify-content:center;text-align:center}</style>
        </head><body><div><h1>🔧 Maintenance</h1><p>{$msg}</p></div></body></html>");
    }
}
