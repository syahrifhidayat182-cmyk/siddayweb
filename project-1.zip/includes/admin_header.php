<?php
// includes/admin_header.php
$flash = flash_get();
$user  = current_user();
$pendingTopups = (int)db_val("SELECT COUNT(*) FROM topups WHERE status='pending'");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin — <?= e($pageTitle??'Dashboard') ?> | <?= e(setting('site_name',APP_NAME)) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@600;700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
</head>
<body class="admin-body">
<aside class="sidebar admin-sidebar">
  <div class="sidebar-logo">
    <div class="admin-logo-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M9 3H5a2 2 0 00-2 2v4m6-6h10a2 2 0 012 2v4M9 3v18m0 0h10a2 2 0 002-2V9M9 21H5a2 2 0 01-2-2V9m0 0h18"/></svg></div>
    <div>
      <div class="logo-text"><?= e(setting('site_name',APP_NAME)) ?></div>
      <div class="admin-badge-label">ADMIN</div>
    </div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-label">Overview</div>
    <a href="<?= BASE_URL ?>/admin/" class="nav-item <?= basename($_SERVER['PHP_SELF'])=='index.php'?'active':'' ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M4 5a1 1 0 011-1h4a1 1 0 011 1v5a1 1 0 01-1 1H5a1 1 0 01-1-1V5zm10 0a1 1 0 011-1h4a1 1 0 011 1v2a1 1 0 01-1 1h-4a1 1 0 01-1-1V5zM4 15a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1H5a1 1 0 01-1-1v-4zm10-3a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1h-4a1 1 0 01-1-1v-7z"/></svg>
      Dashboard
    </a>
    <div class="nav-label">Manajemen</div>
    <a href="<?= BASE_URL ?>/admin/users.php" class="nav-item <?= basename($_SERVER['PHP_SELF'])=='users.php'?'active':'' ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
      Users
    </a>
    <a href="<?= BASE_URL ?>/admin/products.php" class="nav-item <?= basename($_SERVER['PHP_SELF'])=='products.php'?'active':'' ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
      Produk
    </a>
    <a href="<?= BASE_URL ?>/admin/topups.php" class="nav-item <?= basename($_SERVER['PHP_SELF'])=='topups.php'?'active':'' ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
      Konfirmasi Topup
      <?php if($pendingTopups>0): ?>
      <span class="nav-count"><?= $pendingTopups ?></span>
      <?php endif; ?>
    </a>
    <a href="<?= BASE_URL ?>/admin/orders.php" class="nav-item <?= basename($_SERVER['PHP_SELF'])=='orders.php'?'active':'' ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
      Semua Order
    </a>
    <a href="<?= BASE_URL ?>/admin/vouchers.php" class="nav-item <?= basename($_SERVER['PHP_SELF'])=='vouchers.php'?'active':'' ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>
      Voucher
    </a>
    <div class="nav-label">Sistem</div>
    <a href="<?= BASE_URL ?>/admin/settings.php" class="nav-item <?= basename($_SERVER['PHP_SELF'])=='settings.php'?'active':'' ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
      Pengaturan
    </a>
    <a href="<?= BASE_URL ?>/dashboard.php" class="nav-item" style="margin-top:6px">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
      Kembali ke User
    </a>
  </nav>
  <div class="sidebar-footer">
    <div class="user-box">
      <div class="user-avatar admin-avatar"><?= strtoupper(substr($user['name']??'A',0,2)) ?></div>
      <div style="flex:1;min-width:0">
        <div class="user-name"><?= e(mb_strimwidth($user['name']??'',0,16,'…')) ?></div>
        <div class="admin-role-label">Administrator</div>
      </div>
      <a href="<?= BASE_URL ?>/logout.php" class="logout-btn" title="Logout">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
      </a>
    </div>
  </div>
</aside>
<main class="main-content">
  <div class="topbar">
    <div class="breadcrumb">Admin <span class="bc-sep">›</span> <span class="bc-cur"><?= e($pageTitle??'') ?></span></div>
    <span class="topbar-date"><?= date('d M Y, H:i') ?></span>
  </div>
  <div class="page-body">
  <?php if($flash): ?>
  <div class="alert alert-<?= $flash['type']==='success'?'success':'danger' ?>"><?= e($flash['msg']) ?></div>
  <?php endif; ?>
