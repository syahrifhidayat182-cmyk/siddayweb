<?php // includes/admin_footer.php ?>
  </div>
</main>
<script src="<?= APP_URL ?>/assets/js/app.js"></script>
</body>
</html>
