<?php
function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=".DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}

function db_query(string $sql, array $p = []): PDOStatement {
    $s = db()->prepare($sql); $s->execute($p); return $s;
}
function db_row(string $sql, array $p = []): ?array {
    return db_query($sql,$p)->fetch() ?: null;
}
function db_rows(string $sql, array $p = []): array {
    return db_query($sql,$p)->fetchAll();
}
function db_val(string $sql, array $p = []) {
    $r = db_query($sql,$p)->fetch(PDO::FETCH_NUM); return $r ? $r[0] : null;
}
function db_insert(string $tbl, array $d): int {
    $cols = implode(',', array_keys($d));
    $ph   = implode(',', array_fill(0, count($d), '?'));
    db_query("INSERT INTO $tbl ($cols) VALUES ($ph)", array_values($d));
    return (int) db()->lastInsertId();
}
function db_update(string $tbl, array $d, string $where, array $wp = []): void {
    $sets = implode(', ', array_map(function($k) { return "$k=?"; }, array_keys($d)));
    db_query("UPDATE $tbl SET $sets WHERE $where", array_merge(array_values($d), $wp));
}

// Atomic credit saldo
function balance_credit(int $uid, int $amt, string $type, string $ref='', string $note='', int $by=0): void {
    db()->beginTransaction();
    try {
        db_query("SELECT balance FROM users WHERE id=? FOR UPDATE", [$uid]);
        $before = (int)db_val("SELECT balance FROM users WHERE id=?", [$uid]);
        $after  = $before + $amt;
        db_query("UPDATE users SET balance=? WHERE id=?", [$after, $uid]);
        db_insert('transactions', [
            'user_id'=>$uid,'type'=>$type,'amount'=>$amt,
            'balance_before'=>$before,'balance_after'=>$after,
            'reference'=>$ref,'note'=>$note,'performed_by'=>$by?:null
        ]);
        db()->commit();
    } catch(Throwable $e){ db()->rollBack(); throw $e; }
}

// Atomic debit saldo
function balance_debit(int $uid, int $amt, string $type, string $ref='', string $note='', int $by=0): void {
    db()->beginTransaction();
    try {
        db_query("SELECT balance FROM users WHERE id=? FOR UPDATE", [$uid]);
        $before = (int)db_val("SELECT balance FROM users WHERE id=?", [$uid]);
        if ($before < $amt) throw new Exception("Saldo tidak cukup.");
        $after = $before - $amt;
        db_query("UPDATE users SET balance=? WHERE id=?", [$after, $uid]);
        db_insert('transactions', [
            'user_id'=>$uid,'type'=>$type,'amount'=>$amt,
            'balance_before'=>$before,'balance_after'=>$after,
            'reference'=>$ref,'note'=>$note,'performed_by'=>$by?:null
        ]);
        db()->commit();
    } catch(Throwable $e){ db()->rollBack(); throw $e; }
}

function setting(string $key, string $default=''): string {
    static $c=[];
    if (!isset($c[$key]))
        $c[$key] = db_val("SELECT value FROM settings WHERE key_name=?",[$key]) ?? $default;
    return $c[$key];
}
function setting_set(string $key, string $val): void {
    db_query("INSERT INTO settings (key_name,value) VALUES (?,?) ON DUPLICATE KEY UPDATE value=?",[$key,$val,$val]);
}
