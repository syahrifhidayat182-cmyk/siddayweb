// Contoh penggunaan API tanpa async / await

// API Key
const API_KEY = 'rg_19f8bb51073384cad03593a3edc5cc';

// 1. Cek Saldo
fetch('https://ramashop.my.id/api/public/balance', {
  headers: {
    'X-API-Key': API_KEY
  }
})
.then(res => res.json())
.then(data => {
  console.log('Saldo:', data);
})
.catch(err => {
  console.error('Error cek saldo:', err);
});

// 2. Membuat Deposit QRIS
fetch('https://ramashop.my.id/api/public/deposit/create', {
  method: 'POST',
  headers: {
    'X-API-Key': API_KEY,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    amount: 10000,
    method: 'qris'
  })
})
.then(res => res.json())
.then(data => {
  console.log('Create Deposit:', data);

  // Ambil depositId untuk cek status
  const depositId = data.data.depositId;

  // 3. Cek Status Deposit setiap 10 detik
  const interval = setInterval(() => {
    fetch(
      `https://ramashop.my.id/api/public/deposit/status/${depositId}`,
      {
        headers: {
          'X-API-Key': API_KEY
        }
      }
    )
    .then(res => res.json())
    .then(status => {
      console.log('Status Deposit:', status);

      if (status.data.status === 'success') {
        console.log('✅ Deposit berhasil');
        clearInterval(interval);
      }

      if (status.data.status === 'already') {
        console.log('⚠️ Deposit sudah diproses');
        clearInterval(interval);
      }
    })
    .catch(err => {
      console.error('Error cek status:', err);
    });

  }, 10000);
})
.catch(err => {
  console.error('Error create deposit:', err);
});
