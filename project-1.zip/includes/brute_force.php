<?php
// includes/brute_force.php — Proteksi brute force login

/**
 * Cek apakah tabel login_attempts sudah ada di DB
 */
function bf_table_exists(): bool {
    static $exists = null;
    if ($exists === null) {
        try {
            db_query("SELECT 1 FROM login_attempts LIMIT 1");
            $exists = true;
        } catch (Throwable $e) {
            $exists = false;
        }
    }
    return $exists;
}

/**
 * Ambil identifier: gabungan email + IP
 */
function bf_identifier(string $email = ''): string {
    $ip = $_SERVER['HTTP_CF_CONNECTING_IP']
       ?? $_SERVER['HTTP_X_FORWARDED_FOR']
       ?? $_SERVER['REMOTE_ADDR']
       ?? '0.0.0.0';
    $ip = trim(explode(',', $ip)[0]);
    return $email ? strtolower(trim($email)) . '|' . $ip : $ip;
}

function bf_max_attempts(): int {
    return max(3, (int)setting('login_max_attempts', '3'));
}

function bf_lockout_seconds(): int {
    return max(60, (int)setting('login_lockout_minutes', '30') * 60);
}

/**
 * Cek lockout — return sisa detik, atau 0 jika tidak terkunci
 */
function bf_check(string $identifier): int {
    if (!bf_table_exists()) return 0;
    try {
        $max     = bf_max_attempts();
        $lockout = bf_lockout_seconds();
        $since   = date('Y-m-d H:i:s', time() - $lockout);

        $count = (int)db_val(
            "SELECT COUNT(*) FROM login_attempts WHERE identifier=? AND attempt_at > ?",
            [$identifier, $since]
        );

        if ($count >= $max) {
            $oldest = db_val(
                "SELECT attempt_at FROM login_attempts WHERE identifier=? AND attempt_at > ? ORDER BY attempt_at ASC LIMIT 1",
                [$identifier, $since]
            );
            if ($oldest) {
                $unlockAt = strtotime($oldest) + $lockout;
                return max(0, $unlockAt - time());
            }
            return $lockout;
        }
    } catch (Throwable $e) { /* tabel belum ada, abaikan */ }
    return 0;
}

/**
 * Catat percobaan gagal
 */
function bf_record(string $identifier): void {
    if (!bf_table_exists()) return;
    try {
        db_query(
            "INSERT INTO login_attempts (identifier, attempt_at) VALUES (?, NOW())",
            [$identifier]
        );
    } catch (Throwable $e) {}
}

/**
 * Reset setelah login sukses
 */
function bf_reset(string $identifier): void {
    if (!bf_table_exists()) return;
    try {
        db_query("DELETE FROM login_attempts WHERE identifier=?", [$identifier]);
    } catch (Throwable $e) {}
}

/**
 * Sisa percobaan sebelum lockout
 */
function bf_remaining(string $identifier): int {
    if (!bf_table_exists()) return bf_max_attempts();
    try {
        $max     = bf_max_attempts();
        $lockout = bf_lockout_seconds();
        $since   = date('Y-m-d H:i:s', time() - $lockout);
        $count   = (int)db_val(
            "SELECT COUNT(*) FROM login_attempts WHERE identifier=? AND attempt_at > ?",
            [$identifier, $since]
        );
        return max(0, $max - $count);
    } catch (Throwable $e) { return bf_max_attempts(); }
}

/**
 * Format detik → "X menit Y detik"
 */
function bf_format_time(int $seconds): string {
    if ($seconds >= 60) {
        $m = floor($seconds / 60);
        $s = $seconds % 60;
        return $m . ' menit' . ($s > 0 ? " {$s} detik" : '');
    }
    return $seconds . ' detik';
}

/**
 * Verifikasi Google reCAPTCHA v3
 */
function recaptcha_verify(string $token): bool {
    $secret = setting('recaptcha_secret_key') ?: '6LfPe3osAAAAAOk4cAQBbuq29WZD-FcZlEkI-Cct';
    if (!$secret || !$token) return false;

    try {
        $ch = curl_init('https://www.google.com/recaptcha/api/siteverify');
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => ['secret' => $secret, 'response' => $token],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 5,
        ]);
        $raw   = curl_exec($ch);
        $errno = curl_errno($ch);
        curl_close($ch);

        if ($errno || !$raw) return true; // fallback: loloskan jika network error
        $res = json_decode($raw, true);
        return !empty($res['success']) && ($res['score'] ?? 0) >= 0.4;
    } catch (Throwable $e) {
        return true; // jangan blokir user jika reCAPTCHA error
    }
}

/**
 * Cek apakah reCAPTCHA aktif
 */
function recaptcha_enabled(): bool {
    // Aktif jika setting DB enable = 1, ATAU hardcoded site key tersedia
    $dbEnabled = setting('recaptcha_enabled') === '1'
        && setting('recaptcha_site_key') !== ''
        && setting('recaptcha_secret_key') !== '';

    // Fallback hardcoded: selalu aktif karena keys sudah ada
    $hardcoded = true;

    return $dbEnabled || $hardcoded;
}

/**
 * Site key untuk frontend
 */
function recaptcha_site_key(): string {
    return setting('recaptcha_site_key') ?: '6LfPe3osAAAAAFXbIjKYV2hjO1dzqrfemOBpmU1L';
}

/**
 * Bersihkan attempt lama (1% chance per request)
 */
function bf_cleanup(): void {
    if (!bf_table_exists()) return;
    if (rand(1, 100) === 1) {
        try {
            $maxAge = date('Y-m-d H:i:s', time() - 86400);
            db_query("DELETE FROM login_attempts WHERE attempt_at < ?", [$maxAge]);
        } catch (Throwable $e) {}
    }
}

// ═══════════════════════════════════════════════════
// PROTEKSI SQL INJECTION — Input sanitization helpers
// ═══════════════════════════════════════════════════

/**
 * Validasi & bersihkan input email dari karakter berbahaya
 * Return: email bersih atau false jika tidak valid
 */
function sanitize_email(string $email) {
    $email = trim($email);
    // Hapus karakter kontrol & null byte
    $email = preg_replace('/[\x00-\x1F\x7F]/', '', $email);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return false;
    if (strlen($email) > 254) return false;
    return strtolower($email);
}

/**
 * Validasi & bersihkan input teks umum
 * Hapus null byte, karakter kontrol, dan tag HTML
 */
function sanitize_input(string $val, int $maxLen = 500): string {
    $val = trim($val);
    $val = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $val); // null byte & kontrol
    $val = strip_tags($val);
    return mb_substr($val, 0, $maxLen);
}

/**
 * Validasi kode voucher — hanya huruf, angka, dash, underscore
 */
function sanitize_voucher_code(string $code): string {
    return strtoupper(preg_replace('/[^A-Z0-9\-_]/i', '', trim($code)));
}

/**
 * Cek apakah string mengandung pola SQL injection umum
 * Return: true jika mencurigakan
 */
function detect_sql_injection(string $input): bool {
    $lower = strtolower($input);
    $keywords = ['union select','insert into','drop table','drop database',
                 'delete from','update set','exec(','execute(','xp_cmdshell',
                 'sleep(','benchmark(','waitfor delay','information_schema'];
    foreach ($keywords as $kw) {
        if ((strpos($lower, $kw) !== false)) return true;
    }
    if ((strpos($input, '--') !== false) || (strpos($input, '/*') !== false) || (strpos($input, '*/') !== false)) return true;
    if (preg_match('/0x[0-9a-fA-F]{4,}/', $input)) return true;
    return false;
}

/**
 * Blokir dan log request yang mencurigakan
 */
function block_if_suspicious(string ...$inputs): void {
    foreach ($inputs as $input) {
        if (detect_sql_injection($input)) {
            // Log IP mencurigakan
            $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['REMOTE_ADDR'] ?? '?';
            error_log("[SECURITY] Possible SQL injection from {$ip}: " . substr($input, 0, 100));
            // Catat sebagai brute force attempt juga
            try { bf_record(bf_identifier()); } catch(Throwable $e) {}
            http_response_code(400);
            die(json_encode(['error' => 'Bad request']));
        }
    }
}

// ═══════════════════════════════════════════════════
// PROTEKSI SPAM REGISTRASI
// ═══════════════════════════════════════════════════

/**
 * Daftar domain email disposable/spam yang diblokir
 */
function get_blocked_domains(): array {
    // Domain dari DB (admin bisa tambah via settings)
    $fromDb = setting('blocked_email_domains', '');
    $dbList = $fromDb ? array_map('trim', explode(',', strtolower($fromDb))) : [];

    // Hardcoded: domain exploit/malware/disposable yang umum
    $hardcoded = [
        // Exploit & malware domains
        'exploit.io', 'exploit.im', 'exploit.party', 'exploit.club',
        'malware.io', 'malware.host', 'malware.ninja',
        'hack.com', 'hacker.com', 'hacked.com', 'hackthis.co',
        'spammer.com', 'spam4.me', 'spamgourmet.com', 'spamfree24.org',
        'trashmail.com', 'trashmail.io', 'trashmail.me', 'trashmail.net',
        'tempmail.com', 'temp-mail.org', 'temp-mail.io', 'tempmail.ninja',
        'guerrillamail.com', 'guerrillamail.info', 'guerrillamail.net',
        'guerrillamail.org', 'guerrillamail.de', 'guerrillamail.biz',
        'mailinator.com', 'mailinator.net', 'mailinater.com',
        'yopmail.com', 'yopmail.fr', 'cool.fr.nf', 'jetable.fr.nf',
        'throwam.com', 'throwam.net', 'throwam.org',
        'fakeinbox.com', 'fakeinbox.net',
        'dispostable.com', 'discard.email',
        'sharklasers.com', 'guerrillamailblock.com', 'grr.la',
        'spam.la', 'spam.care', 'spam.comu.me',
        'maildrop.cc', 'mailnull.com', 'mailnull.net',
        'mohmal.com', 'discard.email',
        'throwam.com', 'discardmail.com', 'discardmail.de',
        '0-mail.com', '0815.ru', '0clickemail.com',
        'mailnesia.com', 'mailnull.com',
        'notmailinator.com', 'binkmail.com',
        'spamavert.com', 'spamevader.com',
        'getairmail.com', 'filzmail.com',
        'koszmail.pl', 'kurzepost.de',
    ];

    return array_merge($hardcoded, $dbList);
}

/**
 * Cek apakah domain email diblokir
 */
function is_blocked_email_domain(string $email): bool {
    $domain = strtolower(substr(strrchr($email, '@'), 1));
    if (!$domain) return false;

    foreach (get_blocked_domains() as $blocked) {
        $blocked = trim($blocked);
        if (!$blocked) continue;
        // Exact match atau subdomain match
        if ($domain === $blocked || (substr($domain, -strlen('.' . $blocked)) === '.' . $blocked)) {
            return true;
        }
    }
    return false;
}

/**
 * Cek apakah nama/username mengandung pola spam/malware
 */
function is_spam_username(string $name): bool {
    $lower = strtolower($name);

    $spamPatterns = [
        'malware', 'exploit', 'hack', 'hacker', 'hacked',
        'virus', 'trojan', 'rootkit', 'ransomware', 'phish',
        'spammer', 'spambot', 'spam', 'bot', 'crawler',
        'inject', 'shell', 'payload', 'c99', 'r57',
        'sqlmap', 'nmap', 'metasploit', 'sqlinjection',
        'xss', 'csrf', 'rce', 'lfi', 'rfi', 'ssrf',
        'admin', 'administrator', 'superuser', 'root',
        'test123', 'password', '12345',
    ];

    foreach ($spamPatterns as $pattern) {
        if ((strpos($lower, $pattern) !== false)) return true;
    }

    // Cek pola angka berlebihan (mis: Malware_6292)
    if (preg_match('/[_\-\.\s]\d{4,}$/', $name)) return true;

    // Nama terlalu pendek atau terlalu panjang
    if (mb_strlen(trim($name)) < 2) return true;
    if (mb_strlen(trim($name)) > 60) return true;

    return false;
}

/**
 * Cek apakah IP sudah terdaftar terlalu banyak akun baru (max 3 per hari)
 */
function is_ip_over_register_limit(): bool {
    if (!bf_table_exists()) return false;
    try {
        $ip    = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
        $ip    = trim(explode(',', $ip)[0]);
        $ident = 'reg_ip|' . $ip;
        $since = date('Y-m-d H:i:s', time() - 86400); // 24 jam
        $count = (int)db_val(
            "SELECT COUNT(*) FROM login_attempts WHERE identifier=? AND attempt_at > ?",
            [$ident, $since]
        );
        return $count >= 5; // max 5 registrasi gagal per IP per hari
    } catch (Throwable $e) { return false; }
}

/**
 * Catat registrasi gagal dari IP ini
 */
function record_register_attempt(): void {
    if (!bf_table_exists()) return;
    try {
        $ip    = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? $_SERVER['HTTP_X_FORWARDED_FOR'] ?? $_SERVER['REMOTE_ADDR'] ?? '';
        $ip    = trim(explode(',', $ip)[0]);
        $ident = 'reg_ip|' . $ip;
        db_query("INSERT INTO login_attempts (identifier, attempt_at) VALUES (?, NOW())", [$ident]);
    } catch (Throwable $e) {}
}