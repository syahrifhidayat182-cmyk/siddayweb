<?php
// ── Pterodactyl API Client ────────────────────────────────────
class PterodactylAPI {
    private string $url;
    private string $key;

    public function __construct() {
        $this->url = rtrim(setting('ptero_url'), '/');
        $this->key = setting('ptero_api_key');
    }

    private function request(string $method, string $endpoint, array $body = []): array {
        $ch = curl_init($this->url . '/api/application' . $endpoint);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Bearer ' . $this->key,
                'Content-Type: application/json',
                'Accept: application/json',
            ],
            CURLOPT_CUSTOMREQUEST  => strtoupper($method),
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        if (!empty($body)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        }
        $res  = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        if ($err) throw new Exception("cURL error: $err");
        $data = json_decode($res, true);
        if ($code >= 400) {
            $detail = '';
            if (!empty($data['errors'])) {
                $msgs   = array_map(function($e) { return ($e['detail'] ?? $e['code'] ?? ''); }, $data['errors']);
                $detail = implode('; ', array_filter($msgs));
            }
            throw new Exception("Pterodactyl API error ($code): " . ($detail ?: $res));
        }
        return $data ?? [];
    }

    public function getEggVariables(int $nestId, int $eggId): array {
        try {
            $res  = $this->request('GET', "/nests/$nestId/eggs/$eggId?include=variables");
            $vars = $res['attributes']['relationships']['variables']['data'] ?? [];
            $env  = [];
            foreach ($vars as $v) {
                $attr = $v['attributes'];
                $env[$attr['env_variable']] = $attr['default_value'] ?? '';
            }
            return $env;
        } catch (Exception $e) {
            return [];
        }
    }

    public function findNestByEgg(int $eggId): int {
        $nests = $this->request('GET', '/nests?per_page=50');
        foreach ($nests['data'] as $nest) {
            $nestId = $nest['attributes']['id'];
            try {
                $eggs = $this->request('GET', "/nests/$nestId/eggs");
                foreach ($eggs['data'] as $egg) {
                    if ((int)$egg['attributes']['id'] === $eggId) return $nestId;
                }
            } catch (Exception $e) { continue; }
        }
        throw new Exception("Egg ID $eggId tidak ditemukan.");
    }

    public function emailExists(string $email): bool {
        try {
            $res = $this->request('GET', '/users?filter[email]=' . urlencode($email));
            return !empty($res['data']);
        } catch (Exception $e) {
            return false;
        }
    }

    public function createPanelAccount(string $email, string $firstName, string $lastName = 'Customer'): array {
        if ($this->emailExists($email)) {
            throw new Exception("Email $email sudah terdaftar di Pterodactyl panel.");
        }

        $plainPassword = $this->generatePassword();

        $created = $this->request('POST', '/users', [
            'email'      => $email,
            'username'   => 'user' . time() . random_int(1000, 9999),
            'first_name' => $firstName,
            'last_name'  => $lastName,
            'password'   => $plainPassword,
        ]);

        return [
            'ptero_id'  => (int) $created['attributes']['id'],
            'email'     => $email,
            'password'  => $plainPassword,
        ];
    }

    public function getOrCreateAccount(int $userId, string $email, string $userName): array {
        $existing = db_row(
            "SELECT * FROM pterodactyl_accounts WHERE user_id=? AND email=?",
            [$userId, $email]
        );

        if ($existing) {
            return [
                'account_id' => $existing['id'],
                'ptero_id'   => $existing['ptero_id'],
                'email'      => $existing['email'],
                'password'   => null,
                'is_new'     => false,
            ];
        }

        $panelAccount = $this->createPanelAccount($email, $userName);

        $accountId = db_insert('pterodactyl_accounts', [
            'user_id'  => $userId,
            'email'    => $email,
            'password' => $panelAccount['password'],
            'ptero_id' => $panelAccount['ptero_id'],
        ]);

        return [
            'account_id' => $accountId,
            'ptero_id'   => $panelAccount['ptero_id'],
            'email'      => $email,
            'password'   => $panelAccount['password'],
            'is_new'     => true,
        ];
    }

    public function createServer(array $order, array $product, int $pteroAccountId): array {
        $account = db_row(
            "SELECT * FROM pterodactyl_accounts WHERE id=?",
            [$pteroAccountId]
        );

        if (!$account) {
            throw new Exception("Pterodactyl account tidak ditemukan.");
        }

        $allocId = $this->getFreeAllocation((int) $product['node_id']);
        $eggId   = (int) $product['egg_id'];

        $adminEnv = !empty($product['environment'])
            ? (json_decode($product['environment'], true) ?: [])
            : [];

        $nestId = !empty($product['nest_id'])
            ? (int) $product['nest_id']
            : $this->findNestByEgg($eggId);

        $eggEnv   = $this->getEggVariables($nestId, $eggId);
        $finalEnv = array_merge($eggEnv, $adminEnv);

        $dockerImage = !empty($product['docker_image']) ? $product['docker_image'] : '';
        $startupCmd  = !empty($product['startup'])      ? $product['startup']      : '';

        if (!$dockerImage || !$startupCmd) {
            try {
                $egg = $this->request('GET', "/nests/$nestId/eggs/$eggId");
                $dockerImage = $dockerImage ?: ($egg['attributes']['docker_image'] ?? '');
                $startupCmd  = $startupCmd  ?: ($egg['attributes']['startup']      ?? '');
            } catch (Exception $e) {}
        }

        $serverName = 'srv-' . $order['id'] . '-' . time();

        // Deteksi unlimited: ram/cpu/disk = 0 berarti unlimited di Pterodactyl
        $isUnlimited = ((int)$product['ram'] === 0 || (int)$product['cpu'] === 0 || (int)$product['disk'] === 0);

        $res = $this->request('POST', '/servers', [
            'name'        => $serverName,
            'user'        => (int) $account['ptero_id'],
            'egg'         => $eggId,
            'docker_image'=> $dockerImage,
            'startup'     => $startupCmd,
            'environment' => $finalEnv,
            'limits'      => [
                'memory'      => (int) $product['ram'],
                'swap'        => $isUnlimited ? -1 : 0,  // -1 = unlimited swap
                'disk'        => (int) $product['disk'],
                'io'          => 500,
                'cpu'         => (int) $product['cpu'],
                'oom_disabled'=> $isUnlimited,            // nonaktifkan OOM killer untuk unlimited
            ],
            'feature_limits' => [
                'databases'   => (int) $product['db_count'],
                'backups'     => (int) $product['backup_count'],
                'allocations' => 1,
            ],
            'allocation'          => ['default' => $allocId],
            'start_on_completion' => true,   // auto-start setelah installer selesai
            'skip_scripts'        => false,  // jalankan install scripts
        ]);

        $server = $res['attributes'];

        return [
            'server'                  => $server,
            'panel_url'               => $this->url,
            'ptero_account_id'        => $pteroAccountId,
            'ptero_account_email'     => $account['email'],
            'ptero_account_password'  => $account['password'],
        ];
    }

    public function getFreeAllocation(int $nodeId): int {
        $page = 1;
        do {
            $res = $this->request('GET', "/nodes/$nodeId/allocations?per_page=100&page=$page");
            foreach ($res['data'] as $a) {
                if (!$a['attributes']['assigned']) return (int) $a['attributes']['id'];
            }
            $lastPage = $res['meta']['pagination']['total_pages'] ?? 1;
            $page++;
        } while ($page <= $lastPage);
        throw new Exception("Node $nodeId tidak punya allocation tersedia. Tambah allocation di panel.");
    }

    private function generatePassword(int $length = 12): string {
        $chars  = 'abcdefghjkmnpqrstuvwxyz';
        $upper  = 'ABCDEFGHJKMNPQRSTUVWXYZ';
        $digits = '23456789';
        $spec   = '@#$!';

        $password  = $chars[random_int(0, strlen($chars)-1)];
        $password .= $upper[random_int(0, strlen($upper)-1)];
        $password .= $digits[random_int(0, strlen($digits)-1)];
        $password .= $spec[random_int(0, strlen($spec)-1)];

        $all = $chars . $upper . $digits . $spec;
        for ($i = 4; $i < $length; $i++) {
            $password .= $all[random_int(0, strlen($all)-1)];
        }
        return str_shuffle($password);
    }

    public function getAllNestsAndEggs(): array {
        $result = [];
        $nests  = $this->request('GET', '/nests?per_page=50');
        foreach ($nests['data'] as $nest) {
            $nestId   = $nest['attributes']['id'];
            $nestName = $nest['attributes']['name'];
            try {
                $eggs = $this->request('GET', "/nests/$nestId/eggs?include=variables");
                foreach ($eggs['data'] as $egg) {
                    $attr = $egg['attributes'];
                    $vars = $attr['relationships']['variables']['data'] ?? [];
                    $result[] = [
                        'nest_id'      => $nestId,
                        'nest_name'    => $nestName,
                        'egg_id'       => $attr['id'],
                        'egg_name'     => $attr['name'],
                        'docker_image' => $attr['docker_image'] ?? '',
                        'startup'      => $attr['startup'] ?? '',
                        'variables'    => array_map(function($v) { return [
                            'name'     => $v['attributes']['name'],
                            'env_var'  => $v['attributes']['env_variable'],
                            'default'  => $v['attributes']['default_value'] ?? '',
                            'required' => (strpos($v['attributes']['rules'] ?? '', 'required') !== false),
                        ]; }, $vars),
                    ];
                }
            } catch (Exception $e) { continue; }
        }
        return $result;
    }
}

function ptero(): PterodactylAPI { return new PterodactylAPI(); }