<?php
// includes/header.php — dipanggil di atas setiap halaman user
$flash = flash_get();
$user  = current_user();
$announcement = setting('announcement');
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($pageTitle ?? 'Dashboard') ?> — <?= e(setting('site_name', APP_NAME)) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@600;700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo">
    <div class="logo-text"><?= e(setting('site_name', APP_NAME)) ?></div>
    <div class="logo-sub">Panel Marketplace</div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-label">Menu</div>
    <a href="<?= BASE_URL ?>/dashboard.php"      class="nav-item <?= basename($_SERVER['PHP_SELF'])=='dashboard.php'?'active':'' ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
      Dashboard
    </a>
    <a href="<?= BASE_URL ?>/order.php"          class="nav-item <?= basename($_SERVER['PHP_SELF'])=='order.php'?'active':'' ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M5 12h14M12 5l7 7-7 7"/></svg>
      Beli Panel
    </a>
    <a href="<?= BASE_URL ?>/order-history.php"  class="nav-item <?= basename($_SERVER['PHP_SELF'])=='order-history.php'?'active':'' ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
      Riwayat Order
    </a>
    <a href="<?= BASE_URL ?>/renew.php" class="nav-item <?= basename($_SERVER['PHP_SELF'])=='renew.php'?'active':'' ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
      Perpanjang Panel
    </a>
    <div class="nav-label">Saldo</div>
    <a href="<?= BASE_URL ?>/topup.php"          class="nav-item <?= basename($_SERVER['PHP_SELF'])=='topup.php'?'active':'' ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M12 4v16m8-8H4"/></svg>
      Top Up Saldo
    </a>
    <a href="<?= BASE_URL ?>/topup-history.php"  class="nav-item <?= basename($_SERVER['PHP_SELF'])=='topup-history.php'?'active':'' ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/></svg>
      Riwayat Top Up
    </a>
    <div class="nav-label">Akun</div>
    <a href="<?= BASE_URL ?>/profile.php" class="nav-item <?= basename($_SERVER['PHP_SELF'])=='profile.php'?'active':'' ?>">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
      Profil & Keamanan
    </a>
    <?php if(($user['role']??'') === 'admin'): ?>
    <div class="nav-label">Admin</div>
    <a href="<?= BASE_URL ?>/admin/" class="nav-item">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
      Admin Panel
    </a>
    <?php endif; ?>
  </nav>
  <div class="sidebar-footer">
    <div class="balance-box">
      <div class="balance-label">Saldo Anda</div>
      <div class="balance-val"><?= rupiah((int)($user['balance']??0)) ?></div>
    </div>
    <div class="user-box">
      <div class="user-avatar"><?= strtoupper(substr($user['name']??'U',0,2)) ?></div>
      <div>
        <div class="user-name"><?= e(mb_strimwidth($user['name']??'',0,18,'…')) ?></div>
        <div class="user-role">Member</div>
      </div>
      <a href="<?= BASE_URL ?>/logout.php" class="logout-btn" title="Logout">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
      </a>
    </div>
  </div>
</aside>

<main class="main-content">
  <div class="topbar">
    <div style="display:flex;align-items:center;gap:12px;">
      <button onclick="document.getElementById('sidebar').classList.toggle('open')" class="mob-toggle">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
      </button>
      <span class="page-title"><?= e($pageTitle ?? 'Dashboard') ?></span>
    </div>
    <span class="topbar-date"><?= date('d M Y') ?></span>
  </div>
  <div class="page-body">
  <?php if($announcement): ?>
  <div class="alert alert-info"><?= e($announcement) ?></div>
  <?php endif; ?>
  <?php if($flash): ?>
  <div class="alert alert-<?= $flash['type']==='success'?'success':'danger' ?>"><?= e($flash['msg']) ?></div>
  <?php endif; ?>
