<?php
require_once __DIR__ . '/includes/init.php';
require_login();

$user      = current_user();
$pageTitle = 'Profil & Keamanan';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $action = $_POST['action'] ?? '';

    if ($action === 'change_password') {
        $oldPass  = $_POST['old_password']  ?? '';
        $newPass  = $_POST['new_password']  ?? '';
        $confPass = $_POST['confirm_password'] ?? '';

        if (!password_verify($oldPass, $user['password'])) {
            flash('danger', 'Password lama tidak sesuai.');
            redirect('profile.php');
        }
        if (strlen($newPass) < 6) {
            flash('danger', 'Password baru minimal 6 karakter.');
            redirect('profile.php');
        }
        if ($newPass !== $confPass) {
            flash('danger', 'Konfirmasi password tidak cocok.');
            redirect('profile.php');
        }

        $hash = password_hash($newPass, PASSWORD_DEFAULT);
        db_query("UPDATE users SET password=? WHERE id=?", [$hash, $user['id']]);

        flash('success', '✅ Password berhasil diubah. Silakan login kembali.');
        redirect('logout.php');
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width:600px;margin:0 auto">

  <!-- Info Akun -->
  <div class="card" style="margin-bottom:20px">
    <div class="card-title" style="margin-bottom:16px">👤 Informasi Akun</div>
    <div style="display:flex;align-items:center;gap:18px;flex-wrap:wrap">
      <div class="user-avatar" style="width:56px;height:56px;border-radius:14px;font-size:20px;flex-shrink:0">
        <?= strtoupper(substr($user['name'] ?? 'U', 0, 2)) ?>
      </div>
      <div style="flex:1">
        <div style="font-family:'Syne',sans-serif;font-size:18px;font-weight:700;color:var(--txt)"><?= e($user['name']) ?></div>
        <div style="font-size:13px;color:var(--muted);margin-top:3px"><?= e($user['email']) ?></div>
        <div style="margin-top:6px">
          <span class="badge <?= ($user['role']??'') === 'admin' ? 'badge-cyan' : 'badge-green' ?>">
            <?= ($user['role']??'') === 'admin' ? '⚙️ Admin' : '👤 Member' ?>
          </span>
        </div>
      </div>
      <div style="text-align:right">
        <div style="font-family:'Space Mono',monospace;font-size:9px;color:var(--dim);letter-spacing:2px;text-transform:uppercase">Saldo</div>
        <div style="font-family:'Syne',sans-serif;font-size:20px;font-weight:800;color:var(--cyan);margin-top:2px"><?= rupiah((int)$user['balance']) ?></div>
      </div>
    </div>
  </div>

  <!-- Ubah Password -->
  <div class="card">
    <div class="card-title" style="margin-bottom:6px">🔒 Ubah Password</div>
    <div style="font-size:12px;color:var(--muted);margin-bottom:20px">Gunakan password yang kuat dan belum pernah dipakai di tempat lain.</div>

    <form method="POST" id="passForm">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="change_password">

      <div class="form-group">
        <label class="form-label">Password Lama</label>
        <div class="input-wrap">
          <svg class="input-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
          <input type="password" name="old_password" class="form-input" placeholder="Masukkan password lama" required autocomplete="current-password">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Password Baru</label>
        <div class="input-wrap">
          <svg class="input-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z"/></svg>
          <input type="password" name="new_password" id="newPass" class="form-input" placeholder="Min. 6 karakter" required minlength="6" autocomplete="new-password">
        </div>
        <!-- Strength indicator -->
        <div id="strengthBar" style="margin-top:6px;height:3px;border-radius:2px;background:var(--border);overflow:hidden">
          <div id="strengthFill" style="height:100%;width:0;transition:width .3s,background .3s"></div>
        </div>
        <div id="strengthText" style="font-size:11px;color:var(--dim);margin-top:3px"></div>
      </div>

      <div class="form-group">
        <label class="form-label">Konfirmasi Password Baru</label>
        <div class="input-wrap">
          <svg class="input-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
          <input type="password" name="confirm_password" id="confPass" class="form-input" placeholder="Ulangi password baru" required autocomplete="new-password">
        </div>
        <div id="matchText" style="font-size:11px;margin-top:4px"></div>
      </div>

      <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:12px">
        🔒 Simpan Password Baru
      </button>
    </form>
  </div>

</div>

<script>
const newPass  = document.getElementById('newPass');
const confPass = document.getElementById('confPass');
const fill     = document.getElementById('strengthFill');
const text     = document.getElementById('strengthText');
const matchTxt = document.getElementById('matchText');

newPass.addEventListener('input', () => {
  const v = newPass.value;
  let score = 0;
  if (v.length >= 6)  score++;
  if (v.length >= 10) score++;
  if (/[A-Z]/.test(v)) score++;
  if (/[0-9]/.test(v)) score++;
  if (/[^A-Za-z0-9]/.test(v)) score++;
  const pct  = (score / 5) * 100;
  const cols  = ['#ff4444','#ff8800','#ffd600','#00d4ff','#00e676'];
  const labels = ['Sangat Lemah','Lemah','Cukup','Kuat','Sangat Kuat'];
  fill.style.width  = pct + '%';
  fill.style.background = cols[score - 1] || '#ff4444';
  text.textContent  = score > 0 ? labels[score - 1] : '';
  text.style.color  = cols[score - 1] || 'var(--dim)';
  checkMatch();
});

confPass.addEventListener('input', checkMatch);

function checkMatch() {
  if (!confPass.value) { matchTxt.textContent = ''; return; }
  if (confPass.value === newPass.value) {
    matchTxt.textContent = '✅ Password cocok';
    matchTxt.style.color = 'var(--green)';
  } else {
    matchTxt.textContent = '❌ Password tidak cocok';
    matchTxt.style.color = 'var(--red)';
  }
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
