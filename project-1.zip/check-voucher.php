<?php
require_once __DIR__ . '/includes/init.php';
require_login();
header('Content-Type: application/json');

$code  = trim($_GET['code'] ?? '');
$price = (int)($_GET['price'] ?? 0);

if (!$code || !$price) {
    echo json_encode(['valid' => false, 'message' => 'Parameter tidak lengkap']);
    exit;
}

$v = db_row(
    "SELECT * FROM vouchers WHERE code=? AND is_active=1
     AND (uses_left IS NULL OR uses_left > 0)
     AND (expired_at IS NULL OR expired_at >= NOW())",
    [strtoupper($code)]
);

if (!$v) {
    echo json_encode(['valid' => false, 'message' => 'Voucher tidak ditemukan atau sudah tidak berlaku']);
    exit;
}

if ($v['type'] === 'percent') {
    $discount = (int)floor($price * $v['value'] / 100);
    $label    = "Diskon " . (int)$v['value'] . "%";
} else {
    $discount = min((int)$v['value'], $price);
    $label    = "Diskon flat " . number_format($v['value'], 0, ',', '.');
}

echo json_encode([
    'valid'    => true,
    'discount' => $discount,
    'label'    => $label,
    'expires'  => $v['expired_at'] ?? null,
]);
