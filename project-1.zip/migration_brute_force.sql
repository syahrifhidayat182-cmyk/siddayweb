-- Migration: Brute Force Protection
-- Jalankan query ini di database Anda SEKARANG

CREATE TABLE IF NOT EXISTS login_attempts (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    identifier  VARCHAR(255) NOT NULL COMMENT 'IP address or email',
    attempt_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_identifier (identifier),
    INDEX idx_attempt_at (attempt_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Set reCAPTCHA keys dan langsung aktifkan
INSERT INTO settings (key_name, value) VALUES ('recaptcha_site_key', '6LfPe3osAAAAAFXbIjKYV2hjO1dzqrfemOBpmU1L')
  ON DUPLICATE KEY UPDATE value = '6LfPe3osAAAAAFXbIjKYV2hjO1dzqrfemOBpmU1L';

INSERT INTO settings (key_name, value) VALUES ('recaptcha_secret_key', '6LfPe3osAAAAAOk4cAQBbuq29WZD-FcZlEkI-Cct')
  ON DUPLICATE KEY UPDATE value = '6LfPe3osAAAAAOk4cAQBbuq29WZD-FcZlEkI-Cct';

INSERT INTO settings (key_name, value) VALUES ('recaptcha_enabled', '1')
  ON DUPLICATE KEY UPDATE value = '1';

-- Brute force: kunci setelah 3x gagal selama 30 menit (lebih ketat)
INSERT INTO settings (key_name, value) VALUES ('login_max_attempts', '3')
  ON DUPLICATE KEY UPDATE value = '3';

INSERT INTO settings (key_name, value) VALUES ('login_lockout_minutes', '30')
  ON DUPLICATE KEY UPDATE value = '30';

-- Hapus semua attempt lama (bersihkan serangan yang sedang berlangsung)
DELETE FROM login_attempts WHERE attempt_at < NOW();
