-- Migration: Tambah tabel renewals untuk fitur perpanjang panel
-- Jalankan query ini di database Anda

CREATE TABLE IF NOT EXISTS `renewals` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id`     INT UNSIGNED NOT NULL,
  `user_id`      INT UNSIGNED NOT NULL,
  `amount`       INT UNSIGNED NOT NULL DEFAULT 0,
  `old_expired`  DATETIME     NULL,
  `new_expired`  DATETIME     NULL,
  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_user_id`  (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
