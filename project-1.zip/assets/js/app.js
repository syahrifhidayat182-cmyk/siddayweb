// app.js — minimal JS untuk mobile sidebar toggle
(function(){
  var overlay = document.querySelector('.mob-overlay');
  var sidebar = document.getElementById('sidebar');
  if (!overlay || !sidebar) return;
  sidebar.addEventListener('transitionend', function(){
    if (sidebar.classList.contains('open')) overlay.classList.add('show');
    else overlay.classList.remove('show');
  });
  overlay.addEventListener('click', function(){
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
  });
})();
