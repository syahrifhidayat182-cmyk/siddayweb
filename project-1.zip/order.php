<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/pterodactyl.php';
require_login();

$user      = current_user();
$pageTitle = 'Beli Panel';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $productId       = (int)($_POST['product_id'] ?? 0);
    $panelEmail      = trim($_POST['panel_email'] ?? '');
    $product         = db_row("SELECT * FROM products WHERE id=? AND is_active=1", [$productId]);

    if (!$product) { 
        flash('danger', 'Produk tidak ditemukan.'); 
        redirect('order.php'); 
    }

    if (!filter_var($panelEmail, FILTER_VALIDATE_EMAIL)) {
        flash('danger', 'Format email panel tidak valid.');
        redirect('order.php');
    }

    if (db_val("SELECT 1 FROM pterodactyl_accounts WHERE user_id=? AND email=?", 
               [$user['id'], $panelEmail])) {
        flash('danger', 'Email panel ini sudah digunakan untuk order lain Anda.');
        redirect('order.php');
    }

    try {
        $voucherCode = trim($_POST['voucher_code'] ?? '');
        $discount = 0;
        $voucherData = null;
        if ($voucherCode !== '') {
            $voucherData = db_row(
                "SELECT * FROM vouchers WHERE code=? AND is_active=1 AND (uses_left IS NULL OR uses_left > 0) AND (expired_at IS NULL OR expired_at >= NOW())",
                [$voucherCode]
            );
            if (!$voucherData) {
                flash('danger', 'Kode voucher tidak valid atau sudah habis.');
                redirect('order.php');
            }
            if ($voucherData['type'] === 'percent') {
                $discount = (int)floor($product['price'] * $voucherData['value'] / 100);
            } else {
                $discount = min((int)$voucherData['value'], (int)$product['price']);
            }
        }

        $finalPrice = max(0, (int)$product['price'] - $discount);

        if ($user['balance'] < $finalPrice) {
            $kekurangan = $finalPrice - $user['balance'];
            if ($discount > 0) {
                flash('danger', 'Saldo tidak cukup. Harga setelah diskon: ' . rupiah($finalPrice) . ' — saldo Anda: ' . rupiah((int)$user['balance']) . ' (kurang ' . rupiah($kekurangan) . '). Silahkan top up.');
            } else {
                flash('danger', 'Saldo tidak cukup. Harga: ' . rupiah($finalPrice) . ' — saldo Anda: ' . rupiah((int)$user['balance']) . ' (kurang ' . rupiah($kekurangan) . '). Silahkan top up.');
            }
            redirect('topup.php');
        }

        $orderCode    = gen_code('ORD');
        $purchaseDate = date('d/m/Y H:i');
        $expiryDate   = date('d/m/Y H:i', strtotime('+30 days'));
        $expiryDateDb = date('Y-m-d H:i:s', strtotime('+30 days'));

        $orderId = db_insert('orders', [
            'user_id'    => $user['id'],
            'product_id' => $product['id'],
            'order_code' => $orderCode,
            'amount'     => $finalPrice,
            'status'     => 'processing',
            'expired_at' => $expiryDateDb,
            'voucher_code'   => $voucherCode ?: null,
            'voucher_discount'=> $discount,
        ]);

        balance_debit($user['id'], $finalPrice, 'purchase', $orderCode,
                      "Pembelian: " . $product['name'] . ($discount > 0 ? " (Diskon voucher: ".rupiah($discount).")" : ""));

        try {
            $pteroApi = ptero();
            $accountResult = $pteroApi->getOrCreateAccount(
                $user['id'],
                $panelEmail,
                $user['name']
            );

            $result = $pteroApi->createServer(
                db_row("SELECT * FROM orders WHERE id=?", [$orderId]),
                $product,
                $accountResult['account_id']
            );

            $server = $result['server'];

            db_update('orders', [
                'status'                    => 'completed',
                'ptero_account_id'          => $accountResult['account_id'],
                'server_id'                 => $server['id'],
                'server_identifier'         => $server['identifier'],
                'server_name'               => $server['name'],
                'panel_url'                 => $result['panel_url'],
                'ptero_account_email'       => $result['ptero_account_email'],
                'panel_password'            => $result['ptero_account_password'] ?? '',
            ], 'id=?', [$orderId]);

            // Kurangi sisa pakai voucher
            if ($voucherData) {
                db_query("UPDATE vouchers SET uses_left = uses_left - 1 WHERE id=? AND uses_left IS NOT NULL", [$voucherData['id']]);
                db_query("UPDATE vouchers SET uses_count = uses_count + 1 WHERE id=?", [$voucherData['id']]);
            }

            flash('success', "✅ Server berhasil dibuat! Kode: {$orderCode}. Aktif hingga: {$expiryDate}. Cek detail order untuk kredensial.");

        } catch (Exception $e) {
            db_update('orders', [
                'status'        => 'failed',
                'failed_reason' => $e->getMessage(),
            ], 'id=?', [$orderId]);
            
            balance_credit($user['id'], $finalPrice, 'refund', $orderCode,
                           "Refund: gagal buat server — " . $e->getMessage());
            
            flash('danger', "Gagal buat server: " . $e->getMessage() . " — Saldo sudah di-refund.");
        }
    } catch (Exception $e) {
        flash('danger', $e->getMessage());
    }

    redirect('order-history.php');
}

$products = db_rows("SELECT * FROM products WHERE is_active=1 ORDER BY sort_order, price");
require_once __DIR__ . '/includes/header.php';
?>

<div style="margin-bottom:20px">
  <div style="font-size:14px;color:var(--muted)">Saldo Anda: <strong style="color:var(--cyan)"><?= rupiah((int)$user['balance']) ?></strong></div>
</div>

<?php if ($products): ?>
<div class="product-grid">
  <?php foreach ($products as $p): ?>
  <div class="product-card">
    <div class="product-name"><?= e($p['name']) ?></div>
    <?php if ($p['description']): ?>
    <div style="font-size:13px;color:var(--muted);margin-top:3px"><?= e($p['description']) ?></div>
    <?php endif; ?>
    <div class="product-price"><?= rupiah((int)$p['price']) ?></div>
    <div class="product-specs">
      <div class="spec-item"><strong><?= $p['ram'] == 0 ? '∞' : ($p['ram'] >= 1024 ? ($p['ram']/1024).'GB' : $p['ram'].'MB') ?></strong> RAM</div>
      <div class="spec-item"><strong><?= $p['cpu'] == 0 ? '∞' : $p['cpu'].'%' ?></strong> CPU</div>
      <div class="spec-item"><strong><?= $p['disk'] == 0 ? '∞' : ($p['disk'] >= 1024 ? ($p['disk']/1024).'GB' : $p['disk'].'MB') ?></strong> Disk</div>
      <div class="spec-item"><strong><?= $p['db_count'] ?></strong> Database</div>
    </div>
    <?php if ($p['ram'] == 0 && $p['cpu'] == 0 && $p['disk'] == 0): ?>
    <div style="text-align:center;background:linear-gradient(90deg,rgba(0,212,255,.12),rgba(255,215,0,.12));border:1px solid rgba(0,212,255,.3);border-radius:6px;padding:5px 8px;font-size:11px;font-weight:700;color:var(--cyan);margin-bottom:8px;letter-spacing:.5px">
      ♾️ UNLIMITED RAM · CPU · DISK
    </div>
    <?php endif; ?>
    <div style="font-size:11px;color:var(--muted);text-align:center;margin-bottom:4px">⏱ Masa aktif: 30 hari setelah pembelian</div>
    
    <?php if ($user['balance'] >= $p['price']): ?>
    <button type="button" class="btn btn-primary" style="width:100%;justify-content:center"
            onclick="openEmailModal(<?= $p['id'] ?>, '<?= e($p['name']) ?>', <?= (int)$p['price'] ?>)">
      Beli Sekarang
    </button>
    <?php elseif ($user['balance'] > 0): ?>
    <button type="button" class="btn btn-primary" style="width:100%;justify-content:center;background:linear-gradient(135deg,#7c3aed,#4f46e5)"
            onclick="openEmailModal(<?= $p['id'] ?>, '<?= e($p['name']) ?>', <?= (int)$p['price'] ?>)">
      🎟️ Beli dengan Voucher
    </button>
    <div style="font-size:11px;color:var(--muted);text-align:center;margin-top:5px">
      Saldo Anda <?= rupiah((int)$user['balance']) ?> — gunakan voucher diskon
    </div>
    <?php else: ?>
    <a href="topup.php" class="btn btn-outline" style="width:100%;justify-content:center">Top Up Saldo Dulu</a>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<!-- Modal Email Panel -->
<div id="emailModal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;
     background:rgba(0,0,0,.7);z-index:999;align-items:center;justify-content:center">
  <div style="background:#0c0d15;border:1px solid #1a1d2e;border-radius:10px;padding:30px;
              max-width:450px;width:90%">
    <h3 style="margin-bottom:8px;color:#dde2f0">Email Panel Pterodactyl</h3>
    <p style="font-size:13px;color:#6b7a99;margin-bottom:20px">
      Masukkan email yang akan digunakan untuk login ke panel. Password akan di-generate otomatis.
    </p>
    
    <form method="POST" onsubmit="return validateForm(event)">
      <?= csrf_field() ?>
      <input type="hidden" name="product_id" id="modalProductId" value="">
      
      <div class="form-group" style="margin-bottom:16px">
        <label class="form-label" style="color:#dde2f0">Email Panel</label>
        <input type="email" name="panel_email" id="panelEmail" class="form-input no-icon" 
               placeholder="server@yourdomain.com" required autofocus>
        <div style="font-size:11px;color:#6b7a99;margin-top:6px">
          Contoh: server1@yourdomain.com, server2@yourdomain.com, dsb.
        </div>
      </div>

      <!-- Voucher -->
      <div class="form-group" style="margin-bottom:16px">
        <label class="form-label" style="color:#dde2f0">Kode Voucher <span style="color:#6b7a99;font-weight:400">(opsional)</span></label>
        <div style="display:flex;gap:8px">
          <input type="text" name="voucher_code" id="voucherInput" class="form-input no-icon" 
                 placeholder="Masukkan kode voucher..." style="text-transform:uppercase;flex:1"
                 oninput="this.value=this.value.toUpperCase()" onblur="checkVoucher(this.value, <?php echo 'window.__currentPrice__'; ?>)">
          <button type="button" onclick="checkVoucher(document.getElementById('voucherInput').value, window.__currentPrice__)" 
                  class="btn btn-outline btn-sm" style="white-space:nowrap">Cek</button>
        </div>
        <div id="voucherResult" style="font-size:12px;margin-top:6px"></div>
      </div>

      <div id="pricePreview" style="background:rgba(0,212,255,.06);border:1px solid rgba(0,212,255,.2);border-radius:8px;padding:10px 14px;margin-bottom:16px;font-size:13px">
        <div style="display:flex;justify-content:space-between"><span style="color:#6b7a99">Harga produk</span><span id="ppBase">—</span></div>
        <div id="ppDiscountRow" style="display:none;display:flex;justify-content:space-between"><span style="color:#6b7a99">Diskon voucher</span><span id="ppDiscount" style="color:#4ade80">—</span></div>
        <div style="display:flex;justify-content:space-between;border-top:1px solid rgba(0,212,255,.2);padding-top:8px;margin-top:6px;font-weight:700"><span>Total bayar</span><span id="ppTotal" style="color:var(--cyan)">—</span></div>
        <div style="font-size:11px;color:#6b7a99;margin-top:5px">⏱ Masa aktif 30 hari sejak pembelian</div>
      </div>

      <div style="display:flex;gap:10px">
        <button type="button" class="btn btn-outline" style="flex:1;justify-content:center" 
                onclick="closeEmailModal()">Batal</button>
        <button type="submit" class="btn btn-primary" style="flex:1;justify-content:center">
          Lanjut Beli
        </button>
      </div>
    </form>
  </div>
</div>

<script>
function rupiah(n) {
  return 'Rp ' + Math.round(n).toLocaleString('id-ID');
}

function openEmailModal(productId, productName, price) {
    window.__currentPrice__ = price;
    document.getElementById('modalProductId').value = productId;
    document.getElementById('panelEmail').value = '';
    document.getElementById('voucherInput').value = '';
    document.getElementById('voucherResult').textContent = '';
    document.getElementById('ppDiscountRow').style.display = 'none';
    document.getElementById('ppBase').textContent    = rupiah(price);
    document.getElementById('ppTotal').textContent   = rupiah(price);
    document.getElementById('emailModal').style.display = 'flex';
    document.getElementById('panelEmail').focus();
}

function closeEmailModal() {
    document.getElementById('emailModal').style.display = 'none';
}

async function checkVoucher(code, price) {
    var el = document.getElementById('voucherResult');
    if (!code) { el.textContent = ''; return; }
    el.innerHTML = '<span style="color:#6b7a99">Memeriksa voucher...</span>';
    try {
        var r = await fetch('check-voucher.php?code=' + encodeURIComponent(code) + '&price=' + price);
        var d = await r.json();
        if (d.valid) {
            el.innerHTML = '<span style="color:#4ade80">✅ ' + d.label + ' — Hemat ' + rupiah(d.discount) + '</span>';
            document.getElementById('ppDiscountRow').style.display = 'flex';
            document.getElementById('ppDiscount').textContent = '- ' + rupiah(d.discount);
            document.getElementById('ppTotal').textContent   = rupiah(Math.max(0, price - d.discount));
        } else {
            el.innerHTML = '<span style="color:#f87171">❌ ' + (d.message || 'Voucher tidak valid') + '</span>';
            document.getElementById('ppDiscountRow').style.display = 'none';
            document.getElementById('ppTotal').textContent = rupiah(price);
        }
    } catch(e) {
        el.innerHTML = '<span style="color:#f87171">Gagal cek voucher</span>';
    }
}

function validateForm(event) {
    const email = document.getElementById('panelEmail').value.trim();
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    if (!emailPattern.test(email)) {
        alert('Format email tidak valid');
        event.preventDefault();
        return false;
    }
    
    const total = document.getElementById('ppTotal').textContent;
    return confirm('Email Panel: ' + email + '\nTotal bayar: ' + total + '\nMasa aktif: 30 hari\n\nPassword akan di-generate otomatis. Lanjutkan?');
}

document.getElementById('emailModal').addEventListener('click', function(e) {
    if (e.target === this) closeEmailModal();
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeEmailModal();
});
</script>

<?php else: ?>
<div class="card" style="text-align:center;padding:50px">
  <div style="font-size:40px;margin-bottom:12px">📦</div>
  <div style="color:var(--muted)">Belum ada produk tersedia. Hubungi admin.</div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>