<?php
require_once __DIR__ . '/includes/init.php';
require_login();

$user      = current_user();
$pageTitle = 'Riwayat Top Up';
$page      = max(1, (int)($_GET['page'] ?? 1));
$result    = paginate(
    "SELECT * FROM topups WHERE user_id=? ORDER BY created_at DESC",
    [$user['id']], $page
);

require_once __DIR__ . '/includes/header.php';
?>

<div class="card">
  <div class="card-header">
    <div class="card-title">Riwayat Top Up (<?= $result['total'] ?>)</div>
    <a href="topup.php" class="btn btn-primary btn-sm">+ Top Up</a>
  </div>
  <?php if ($result['rows']): ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Kode</th><th>Nominal</th><th>Status</th><th>Catatan Admin</th><th>Tanggal</th><th>Bukti</th></tr></thead>
      <tbody>
      <?php foreach ($result['rows'] as $t): ?>
        <tr>
          <td><span style="font-family:'Space Mono',monospace;font-size:11px;color:var(--muted)"><?= e($t['topup_code']) ?></span></td>
          <td style="color:var(--green);font-weight:600"><?= rupiah((int)$t['amount']) ?></td>
          <td><?= status_badge($t['status']) ?></td>
          <td style="color:var(--muted);font-size:13px"><?= $t['admin_note'] ? e($t['admin_note']) : '—' ?></td>
          <td style="color:var(--muted);font-size:12px"><?= date('d M Y H:i', strtotime($t['created_at'])) ?></td>
          <td>
            <?php if (!empty($t['proof_image'])): ?>
              <a href="<?= BASE_URL ?>/<?= e($t['proof_image']) ?>" target="_blank" class="btn btn-outline btn-sm">📷 Lihat</a>
            <?php elseif (($t['pay_mode'] ?? 'manual') === 'auto' && $t['status'] === 'pending'): ?>
              <a href="<?= BASE_URL ?>/topup-pay.php?code=<?= urlencode($t['topup_code']) ?>" class="btn btn-primary btn-sm">⚡ Bayar</a>
            <?php elseif (($t['pay_mode'] ?? 'manual') === 'auto'): ?>
              <span style="font-size:12px;color:var(--muted)">Otomatis</span>
            <?php else: ?>
              <span style="font-size:12px;color:var(--muted)">—</span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php if ($result['pages'] > 1): ?>
  <div class="pagination">
    <?php for ($i = 1; $i <= $result['pages']; $i++): ?>
      <a href="?page=<?= $i ?>" class="<?= $i === $result['page'] ? 'pg-active' : '' ?>"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
  <?php else: ?>
  <div style="text-align:center;padding:40px;color:var(--muted)">
    <div style="font-size:36px;margin-bottom:10px">💳</div>
    Belum ada top up. <a href="topup.php" style="color:var(--cyan)">Top up sekarang!</a>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
