-- ============================================================
--  Migration: Tambah kolom PaKasir ke tabel topups & settings
--  Jalankan 1x di phpMyAdmin atau mysql CLI
-- ============================================================

-- Tambah kolom baru ke tabel topups
ALTER TABLE `topups`
  ADD COLUMN `pay_method`     VARCHAR(30)  NOT NULL DEFAULT 'manual'  COMMENT 'qris, bni_va, bri_va, dll' AFTER `proof_image`,
  ADD COLUMN `pay_mode`       ENUM('manual','auto') NOT NULL DEFAULT 'manual' AFTER `pay_method`,
  ADD COLUMN `payment_number` TEXT         DEFAULT NULL                COMMENT 'No VA atau string QRIS' AFTER `pay_mode`,
  ADD COLUMN `payment_url`    VARCHAR(500) DEFAULT NULL                COMMENT 'URL pembayaran PaKasir' AFTER `payment_number`,
  ADD COLUMN `fee`            INT UNSIGNED NOT NULL DEFAULT 0          COMMENT 'Biaya layanan PaKasir' AFTER `payment_url`,
  ADD COLUMN `total_payment`  INT UNSIGNED NOT NULL DEFAULT 0          COMMENT 'Total yang dibayarkan (termasuk fee)' AFTER `fee`;

-- Tambah setting PaKasir
INSERT INTO `settings` (`key_name`, `value`) VALUES
  ('pakasir_api_key', ''),
  ('pakasir_project', ''),
  ('pakasir_enabled', '0')
ON DUPLICATE KEY UPDATE `value` = `value`;

-- ============================================================
--  Verifikasi:
--  SHOW COLUMNS FROM topups;
--  SELECT key_name, value FROM settings WHERE key_name LIKE 'pakasir%';
-- ============================================================
