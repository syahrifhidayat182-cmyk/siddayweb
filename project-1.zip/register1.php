<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/brute_force.php';
require_guest();

bf_cleanup();

$errors     = [];
$lockoutSec = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $nameRaw = trim($_POST['name'] ?? '');
    $emailRaw= trim($_POST['email'] ?? '');
    $pass    = $_POST['password'] ?? '';
    $confirm = $_POST['password_confirmation'] ?? '';

    // ── Proteksi SQL Injection & Input Sanitization ──
    block_if_suspicious($nameRaw, $emailRaw, $pass);
    $name  = sanitize_input($nameRaw, 100);
    $email = sanitize_email($emailRaw) ?: '';

    $ident = 'reg|' . bf_identifier($emailRaw);

    // 1. Cek lockout (anti spam registrasi)
    $lockoutSec = bf_check($ident);
    if ($lockoutSec > 0) {
        $errors[] = '🔒 Terlalu banyak percobaan. Coba lagi dalam <strong>' . bf_format_time($lockoutSec) . '</strong>.';
    }
    // 2. reCAPTCHA
    elseif (recaptcha_enabled()) {
        $token = trim($_POST['g-recaptcha-response'] ?? '');
        if (!$token || !recaptcha_verify($token)) {
            $errors[] = '⚠️ Verifikasi reCAPTCHA gagal. Silakan coba lagi.';
            bf_record($ident);
        }
    }

    // 3. Validasi input
    if (!$errors) {
        // Nama
        if (!$name) {
            $errors[] = 'Nama wajib diisi.';
        } elseif (is_spam_username($name)) {
            record_register_attempt();
            $errors[] = 'Nama tidak diizinkan. Gunakan nama asli Anda.';
        }

        // Email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Format email tidak valid.';
        } elseif (is_blocked_email_domain($email)) {
            record_register_attempt();
            $errors[] = 'Domain email tidak diizinkan. Gunakan email aktif (Gmail, Yahoo, dll).';
        } elseif (db_val("SELECT 1 FROM users WHERE email=?", [$email])) {
            $errors[] = 'Email sudah terdaftar.';
        }

        // Password
        if (strlen($pass) < 8)   $errors[] = 'Password minimal 8 karakter.';
        if ($pass !== $confirm)  $errors[] = 'Konfirmasi password tidak cocok.';

        // Rate limit registrasi per IP
        if (!$errors && is_ip_over_register_limit()) {
            $errors[] = '🔒 Terlalu banyak percobaan registrasi. Coba lagi besok.';
        }
    }

    if (!$errors) {
        $id = db_insert('users', [
            'name'     => $name,
            'email'    => $email,
            'password' => password_hash($pass, PASSWORD_DEFAULT),
            'role'     => 'user',
            'status'   => 'active',
            'balance'  => 0,
        ]);
        bf_reset($ident);
        session_regenerate_id(true);
        $_SESSION['user_id']   = $id;
        $_SESSION['user_role'] = 'user';
        flash('success', "Selamat datang, {$name}! Akun berhasil dibuat.");
        redirect('dashboard.php');
    } else {
        // Catat percobaan gagal jika email sudah diisi tapi gagal validasi berulang
        if ($email && count($errors) === 1 && str_contains($errors[0], 'sudah terdaftar')) {
            bf_record($ident);
        }
    }
}

// Tampilkan reCAPTCHA jika enabled via DB atau hardcoded fallback tersedia
$rcSiteKey = recaptcha_enabled() ? recaptcha_site_key() : '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Daftar — <?= e(setting('site_name',APP_NAME)) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@600;700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/auth.css">
<?php if ($rcSiteKey): ?>
<script src="https://www.google.com/recaptcha/api.js?render=<?= e($rcSiteKey) ?>"></script>
<?php endif; ?>
<style>
.bf-lockout{background:rgba(255,68,68,.08);border:1px solid rgba(255,68,68,.3);border-radius:10px;padding:14px 16px;font-size:13.5px;color:#ff6b6b;margin-bottom:16px;text-align:center}
.auth-error strong{color:#ff9800}
</style>
</head>
<body class="auth-body">

<div class="auth-card-wrap">
  <div class="auth-card">
    <div class="auth-card-left">
      <a href="<?= BASE_URL ?>/login.php" class="back-link">← Kembali login</a>
      <div class="brand-name" style="font-size:24px;margin-bottom:4px"><?= e(setting('site_name',APP_NAME)) ?></div>
      <div class="brand-sub" style="margin-bottom:28px">Panel Marketplace</div>
      <div class="auth-steps-title">Mulai dalam 3 langkah</div>
      <p class="auth-desc" style="margin-bottom:20px">Buat akun gratis dan dapatkan server dalam hitungan menit.</p>
      <div class="steps">
        <div class="step"><div class="step-n">1</div><div>Daftar akun gratis</div></div>
        <div class="step"><div class="step-n">2</div><div>Top up saldo via QRIS</div></div>
        <div class="step"><div class="step-n">3</div><div>Server aktif otomatis!</div></div>
      </div>
    </div>
    <div class="auth-card-right">
      <div class="auth-form-header">
        <h2>Buat akun baru</h2>
        <p>Isi data di bawah untuk memulai</p>
      </div>

      <?php if ($errors): ?>
      <div class="auth-error"><?php foreach($errors as $e) echo '<div>'.e($e).'</div>'; ?></div>
      <?php endif; ?>

      <?php if ($lockoutSec > 0): ?>
      <div class="bf-lockout">
        <span style="font-size:22px;display:block;margin-bottom:6px">🔒</span>
        Coba lagi dalam: <strong id="bfCountdown"><?= bf_format_time($lockoutSec) ?></strong>
      </div>
      <script>
      var bfSeconds=<?= (int)$lockoutSec ?>;
      function bfTick(){
        if(bfSeconds<=0){location.reload();return;}
        var m=Math.floor(bfSeconds/60),s=bfSeconds%60;
        document.getElementById('bfCountdown').textContent=(m>0?m+'m ':'')+s+'d';
        bfSeconds--;setTimeout(bfTick,1000);
      }
      bfTick();
      </script>
      <?php endif; ?>

      <form method="POST" action="" id="regForm">
        <?= csrf_field() ?>
        <?php if ($rcSiteKey): ?>
        <input type="hidden" name="g-recaptcha-response" id="gRecaptchaToken">
        <?php endif; ?>

        <div class="form-group">
          <label class="form-label">Nama Lengkap</label>
          <div class="input-wrap">
            <svg class="input-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
            <input type="text" name="name" class="form-input" placeholder="Nama kamu"
                   value="<?= e($_POST['name']??'') ?>" required autofocus
                   <?= $lockoutSec > 0 ? 'disabled' : '' ?>>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Email</label>
          <div class="input-wrap">
            <svg class="input-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
            <input type="email" name="email" class="form-input" placeholder="email@aktif.com"
                   value="<?= e($_POST['email']??'') ?>" required
                   <?= $lockoutSec > 0 ? 'disabled' : '' ?>>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Password</label>
            <div class="input-wrap">
              <svg class="input-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
              <input type="password" name="password" id="pw" class="form-input" placeholder="Min. 8 karakter" required
                     <?= $lockoutSec > 0 ? 'disabled' : '' ?>>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Konfirmasi</label>
            <div class="input-wrap">
              <svg class="input-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
              <input type="password" name="password_confirmation" class="form-input" placeholder="Ulangi" required
                     <?= $lockoutSec > 0 ? 'disabled' : '' ?>>
            </div>
          </div>
        </div>
        <div class="pw-bar"><div class="pw-bar-fill" id="pwBar"></div></div>

        <?php if ($rcSiteKey): ?>
        <div style="font-size:11px;color:var(--muted);margin:10px 0 6px;text-align:center">
          🛡️ Dilindungi Google reCAPTCHA v3
        </div>
        <?php endif; ?>

        <button type="submit" class="btn-auth" id="regBtn" style="margin-top:14px"
                <?= $lockoutSec > 0 ? 'disabled style="opacity:.5;cursor:not-allowed"' : '' ?>>
          BUAT AKUN →
        </button>
      </form>
      <div class="auth-switch">Sudah punya akun? <a href="<?= BASE_URL ?>/login.php">Masuk di sini</a></div>
    </div>
  </div>
</div>

<script>
document.getElementById('pw').addEventListener('input', function() {
  var v=this.value, s=0;
  if(v.length>=8)s++;
  if(/[A-Z]/.test(v))s++;
  if(/[0-9]/.test(v))s++;
  if(/[^A-Za-z0-9]/.test(v))s++;
  var colors=['','#ff4444','#ff9800','#ffd600','#00e676'];
  var bar=document.getElementById('pwBar');
  bar.style.width=(s/4*100)+'%';
  bar.style.background=colors[s]||'';
});
</script>

<?php if ($rcSiteKey): ?>
<script>
document.getElementById('regForm').addEventListener('submit', function(e) {
  e.preventDefault();
  var form=this, btn=document.getElementById('regBtn');
  btn.textContent='Memverifikasi...';
  btn.disabled=true;
  grecaptcha.ready(function() {
    grecaptcha.execute('<?= e($rcSiteKey) ?>', {action:'register'}).then(function(token) {
      document.getElementById('gRecaptchaToken').value=token;
      form.submit();
    }).catch(function(){ form.submit(); });
  });
});
</script>
<?php endif; ?>
</body>
</html>