<?php
// topup-status.php — AJAX polling status topup
// Selain cek DB, juga aktif polling ke API PaKasir jika status masih pending
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/pakasir.php';
require_login();

header('Content-Type: application/json');

$user = current_user();
$code = trim($_GET['code'] ?? '');

if (!$code) { echo json_encode(['error' => 'invalid']); exit; }

$topup = db_row(
    "SELECT * FROM topups WHERE topup_code=? AND user_id=?",
    [$code, $user['id']]
);

if (!$topup) { echo json_encode(['error' => 'not found']); exit; }

// ── Handle cancel via POST ──
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body   = json_decode(file_get_contents('php://input'), true) ?? [];
    $action = $body['action'] ?? '';

    if ($action === 'cancel' && $topup['status'] === 'pending') {
        db_update('topups', [
            'status'     => 'canceled',
            'admin_note' => 'Dibatalkan oleh user pada ' . date('Y-m-d H:i:s'),
        ], 'id=?', [(int)$topup['id']]);
        echo json_encode(['status' => 'canceled', 'message' => 'Transaksi berhasil dibatalkan.']);
    } else {
        echo json_encode(['error' => 'Tidak bisa dibatalkan.']);
    }
    exit;
}

// Jika sudah confirmed di DB, langsung return
if ($topup['status'] === 'confirmed') {
    echo json_encode(['status' => 'confirmed', 'amount' => (int)$topup['amount']]);
    exit;
}

// Jika masih pending DAN mode auto → polling aktif ke API PaKasir
// Ini sebagai fallback kalau webhook terlambat / gagal kirim
if ($topup['status'] === 'pending' && ($topup['pay_mode'] ?? 'manual') === 'auto') {
    try {
        $pakasir = pakasir();
        $detail  = $pakasir->getDetail($topup['topup_code'], (int)$topup['amount']);

        // Ambil status dari response API PaKasir
        $apiStatus = $detail['transaction']['status']
                  ?? $detail['status']
                  ?? $detail['payment']['status']
                  ?? '';

        $logFile = __DIR__ . '/logs/pakasir_webhook.log';
        if (!is_dir(dirname($logFile))) mkdir(dirname($logFile), 0755, true);

        $completedStatuses = ['completed', 'paid', 'success', 'settlement', 'capture'];
        if (in_array(strtolower($apiStatus), $completedStatuses)) {
            // Bayar sudah berhasil tapi webhook belum masuk — proses manual dari sini
            file_put_contents($logFile,
                "[" . date('Y-m-d H:i:s') . "] POLLING-CONFIRM: order={$code} api_status={$apiStatus}\n",
                FILE_APPEND
            );

            db_update('topups', [
                'status'       => 'confirmed',
                'confirmed_at' => date('Y-m-d H:i:s'),
                'admin_note'   => 'Auto-confirmed via polling API PaKasir (api_status=' . $apiStatus . ')',
            ], 'id=?', [(int)$topup['id']]);

            balance_credit(
                (int)$topup['user_id'],
                (int)$topup['amount'],
                'topup',
                $topup['topup_code'],
                'Top up via PaKasir (polling fallback)',
                0
            );

            echo json_encode(['status' => 'confirmed', 'amount' => (int)$topup['amount']]);
            exit;
        }
    } catch (Throwable $e) {
        // Gagal polling API — tidak apa-apa, return status DB saja
    }
}

echo json_encode([
    'status' => $topup['status'],
    'amount' => (int)$topup['amount'],
]);
