<?php
// topup-pay.php — Halaman instruksi pembayaran PaKasir
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/pakasir.php';
require_login();

$user  = current_user();
$code  = trim($_GET['code'] ?? '');
if (!$code) redirect('topup.php');

$topup = db_row(
    "SELECT * FROM topups WHERE topup_code=? AND user_id=?",
    [$code, $user['id']]
);
if (!$topup) { flash('error', 'Transaksi tidak ditemukan.'); redirect('topup-history.php'); }

// Jika sudah selesai, langsung redirect
if ($topup['status'] === 'confirmed') {
    flash('success', 'Top up ' . rupiah((int)$topup['amount']) . ' berhasil! Saldo sudah ditambahkan.');
    redirect('topup-history.php');
}
if ($topup['status'] === 'rejected') {
    flash('error', 'Transaksi dibatalkan/ditolak.');
    redirect('topup-history.php');
}

$pageTitle  = 'Instruksi Pembayaran';
$isExpired  = strtotime($topup['expired_at']) < time();
$isQris     = ($topup['pay_method'] ?? 'qris') === 'qris';
$isManual   = ($topup['pay_mode'] ?? 'manual') === 'manual';
$payNumber  = $topup['payment_number'] ?? '';
$payUrl     = $topup['payment_url'] ?? '';

require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width:520px;margin:0 auto">
  <div class="card">
    <div style="text-align:center;margin-bottom:20px">
      <div style="font-size:32px;margin-bottom:8px">
        <?= $isExpired ? '⏰' : ($isQris ? '📱' : '🏦') ?>
      </div>
      <div style="font-size:18px;font-weight:700;font-family:'Syne',sans-serif">
        <?= $isExpired ? 'Transaksi Kedaluwarsa' : 'Selesaikan Pembayaran' ?>
      </div>
      <div style="font-size:12px;color:var(--muted);margin-top:4px;font-family:'Space Mono',monospace">
        <?= e($topup['topup_code']) ?>
      </div>
    </div>

    <?php if ($isExpired): ?>
    <div class="alert alert-danger" style="text-align:center">
      Transaksi ini sudah kedaluwarsa. Silakan buat top up baru.
    </div>
    <a href="topup.php" class="btn btn-primary" style="width:100%;justify-content:center;margin-top:10px">+ Top Up Baru</a>

    <?php elseif ($isManual): ?>
    <!-- Manual mode: hanya info pending -->
    <div class="alert alert-yellow" style="text-align:center">
      ⏳ Menunggu konfirmasi admin.<br>
      <small>Bukti transfer Anda sudah dikirim.</small>
    </div>
    <a href="topup-history.php" class="btn btn-outline" style="width:100%;justify-content:center;margin-top:10px">Lihat Riwayat</a>

    <?php else: ?>
    <!-- Otomatis via PaKasir -->

    <!-- Countdown timer -->
    <div style="text-align:center;margin-bottom:18px">
      <div style="font-size:12px;color:var(--muted);margin-bottom:4px">Bayar sebelum</div>
      <div id="countdown" style="font-size:22px;font-weight:700;font-family:'Space Mono',monospace;color:var(--cyan)">
        --:--:--
      </div>
    </div>

    <!-- Nominal -->
    <div style="background:rgba(0,212,255,.06);border:1px solid rgba(0,212,255,.2);border-radius:10px;padding:14px;margin-bottom:16px">
      <div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:13px">
        <span style="color:var(--muted)">Nominal Top Up</span>
        <span style="color:var(--txt)"><?= rupiah((int)$topup['amount']) ?></span>
      </div>
      <?php if (!empty($topup['fee'])): ?>
      <div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:13px">
        <span style="color:var(--muted)">Biaya Layanan</span>
        <span style="color:var(--yellow)"><?= rupiah((int)$topup['fee']) ?></span>
      </div>
      <?php endif; ?>
      <div style="display:flex;justify-content:space-between;border-top:1px solid rgba(0,212,255,.2);padding-top:8px;margin-top:4px">
        <span style="font-weight:700;color:var(--txt)">Total Bayar</span>
        <span style="font-weight:700;font-size:18px;color:var(--cyan)"><?= rupiah((int)($topup['total_payment'] ?: $topup['amount'])) ?></span>
      </div>
    </div>

    <!-- Instruksi bayar -->
    <?php if ($isQris && $payNumber): ?>
    <!-- Generate QR dari payment_number (string QRIS) -->
    <div style="text-align:center;margin-bottom:16px">
      <div style="font-size:13px;color:var(--muted);margin-bottom:10px">Scan QR Code di bawah ini</div>
      <div style="display:inline-flex;justify-content:center;align-items:center;padding:14px;background:#fff;border-radius:14px;box-shadow:0 4px 24px rgba(0,0,0,.25)">
        <div id="qrBox"></div>
      </div>
      <div style="font-size:11px;color:var(--muted);margin-top:10px">
        Gunakan GoPay, OVO, Dana, ShopeePay, atau m-banking apapun
      </div>
    </div>
    <script>
    window.qrisString = <?= json_encode($payNumber) ?>;
    </script>
    <?php elseif (!$isQris && $payNumber): ?>
    <!-- Virtual Account -->
    <div style="margin-bottom:16px">
      <div style="font-size:13px;color:var(--muted);margin-bottom:8px">Nomor Virtual Account</div>
      <div style="display:flex;align-items:center;gap:8px;background:rgba(0,212,255,.06);border:1px solid rgba(0,212,255,.2);border-radius:10px;padding:12px 14px">
        <span id="vaNumber" style="font-family:'Space Mono',monospace;font-size:18px;font-weight:700;color:var(--cyan);flex:1;letter-spacing:2px"><?= e($payNumber) ?></span>
        <button onclick="copyVA()" class="btn btn-outline btn-sm" id="copyBtn">📋 Salin</button>
      </div>
      <div style="font-size:12px;color:var(--muted);margin-top:6px">
        Transfer tepat sesuai nominal di atas (termasuk biaya layanan)
      </div>
    </div>
    <script>
    function copyVA() {
      navigator.clipboard.writeText('<?= e($payNumber) ?>');
      document.getElementById('copyBtn').textContent = '✅ Disalin!';
      setTimeout(() => document.getElementById('copyBtn').textContent = '📋 Salin', 2000);
    }
    </script>
    <?php elseif ($payUrl): ?>
    <div style="text-align:center;margin-bottom:16px">
      <a href="<?= e($payUrl) ?>" target="_blank" class="btn btn-primary" style="width:100%;justify-content:center;padding:14px;font-size:15px">
        💳 Buka Halaman Pembayaran
      </a>
    </div>
    <?php endif; ?>

    <!-- Status auto-refresh -->
    <div id="statusBox" style="text-align:center;padding:14px;border-radius:10px;background:rgba(255,214,0,.06);border:1px solid rgba(255,214,0,.2);margin-bottom:14px">
      <div id="statusIcon" style="font-size:20px;margin-bottom:4px">⏳</div>
      <div id="statusText" style="font-size:13px;color:var(--muted)">Menunggu pembayaran...</div>
      <div style="font-size:11px;color:var(--dim);margin-top:4px">Halaman ini akan otomatis update setiap 5 detik</div>
    </div>

    <a href="topup-history.php" class="btn btn-outline" style="width:100%;justify-content:center">
      ← Lihat Riwayat
    </a>

    <?php if (!$isExpired): ?>
    <form method="POST" action="topup.php" style="margin-top:10px"
          onsubmit="return confirm('Yakin ingin membatalkan top up ini? Anda bisa membuat top up baru setelah dibatalkan.')">
      <?= csrf_field() ?>
      <input type="hidden" name="cancel_topup" value="<?= e($topup['topup_code']) ?>">
      <button type="submit" class="btn" style="width:100%;justify-content:center;background:rgba(255,80,80,.1);color:#ff5050;border:1px solid rgba(255,80,80,.25)">
        ✕ Batalkan Transaksi Ini
      </button>
    </form>
    <?php endif; ?>
    <?php endif; ?>

  </div>
</div>

<script>
// ── Countdown timer ──
var expiredAt = <?= json_encode($topup['expired_at']) ?>;
function updateCountdown() {
  var now  = new Date().getTime();
  var end  = new Date(expiredAt.replace(' ', 'T') + '+07:00').getTime();
  var diff = end - now;
  if (diff <= 0) {
    document.getElementById('countdown').textContent = 'KEDALUWARSA';
    document.getElementById('countdown').style.color = 'var(--red)';
    return;
  }
  var h = Math.floor(diff / 3600000);
  var m = Math.floor((diff % 3600000) / 60000);
  var s = Math.floor((diff % 60000) / 1000);
  document.getElementById('countdown').textContent =
    String(h).padStart(2,'0') + ':' + String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
}
setInterval(updateCountdown, 1000);
updateCountdown();

// ── Generate QR Code ──
if (window.qrisString) {
  var script = document.createElement('script');
  script.src = 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';
  script.onload = function() {
    try {
      new QRCode(document.getElementById('qrBox'), {
        text: window.qrisString,
        width: 220,
        height: 220,
        colorDark: '#000000',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.M
      });
    } catch(e) {
      // Fallback: tampilkan via Google Charts jika qrcodejs gagal
      var img = document.createElement('img');
      img.src = 'https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=' + encodeURIComponent(window.qrisString);
      img.width = 220; img.height = 220;
      document.getElementById('qrBox').appendChild(img);
    }
  };
  script.onerror = function() {
    // Fallback jika CDN tidak bisa diakses
    var img = document.createElement('img');
    img.src = 'https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=' + encodeURIComponent(window.qrisString);
    img.width = 220; img.height = 220;
    document.getElementById('qrBox').appendChild(img);
  };
  document.head.appendChild(script);
}

// ── Poll status setiap 5 detik ──
<?php if (!$isExpired && !$isManual): ?>
var pollInterval = setInterval(function() {
  fetch('<?= BASE_URL ?>/topup-status.php?code=<?= urlencode($code) ?>')
    .then(r => r.json())
    .then(data => {
      if (data.status === 'confirmed') {
        document.getElementById('statusIcon').textContent = '✅';
        document.getElementById('statusText').textContent = 'Pembayaran berhasil! Saldo sudah ditambahkan.';
        document.getElementById('statusBox').style.background = 'rgba(0,230,118,.08)';
        document.getElementById('statusBox').style.borderColor = 'rgba(0,230,118,.3)';
        clearInterval(pollInterval);
        setTimeout(() => window.location = '<?= BASE_URL ?>/topup-history.php', 2500);
      } else if (data.status === 'rejected' || data.status === 'canceled') {
        document.getElementById('statusIcon').textContent = '❌';
        document.getElementById('statusText').textContent = 'Transaksi dibatalkan/ditolak.';
        clearInterval(pollInterval);
      }
    })
    .catch(() => {});
}, 5000);
<?php endif; ?>
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
