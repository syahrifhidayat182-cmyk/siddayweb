-- ============================================================
--  PteroShop — Database Schema
--  Jalankan file ini di phpMyAdmin atau mysql CLI
--  CREATE DATABASE pteroshop CHARACTER SET utf8mb4;
-- ============================================================

SET NAMES utf8mb4;
SET time_zone = '+07:00';

-- ── Users ──────────────────────────────────────────────────
CREATE TABLE users (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    email         VARCHAR(150) NOT NULL UNIQUE,
    password      VARCHAR(255) NOT NULL,
    role          ENUM('user','admin') NOT NULL DEFAULT 'user',
    status        ENUM('active','suspended','banned') NOT NULL DEFAULT 'active',
    balance       BIGINT UNSIGNED NOT NULL DEFAULT 0,
    pterodactyl_id VARCHAR(50) DEFAULT NULL,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Admin default: password = admin123 (ganti setelah login pertama!)
INSERT INTO users (name, email, password, role, status) VALUES
('Administrator', 'admin@pteroshop.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active');

-- ── Products ───────────────────────────────────────────────
CREATE TABLE products (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name           VARCHAR(100) NOT NULL,
    description    TEXT DEFAULT NULL,
    price          BIGINT UNSIGNED NOT NULL,
    ram            INT UNSIGNED NOT NULL COMMENT 'MB',
    cpu            INT UNSIGNED NOT NULL COMMENT 'percent (100=1core)',
    disk           INT UNSIGNED NOT NULL COMMENT 'MB',
    db_count       TINYINT UNSIGNED NOT NULL DEFAULT 1,
    backup_count   TINYINT UNSIGNED NOT NULL DEFAULT 1,
    node_id        VARCHAR(20) NOT NULL,
    nest_id        VARCHAR(20) NOT NULL DEFAULT '',
    egg_id         VARCHAR(20) NOT NULL,
    docker_image   VARCHAR(255) NOT NULL,
    startup        TEXT NOT NULL,
    environment    JSON DEFAULT NULL,
    is_active      TINYINT(1) NOT NULL DEFAULT 1,
    sort_order     SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Topups ─────────────────────────────────────────────────
CREATE TABLE topups (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id        INT UNSIGNED NOT NULL,
    topup_code     VARCHAR(30) NOT NULL UNIQUE,
    amount         BIGINT UNSIGNED NOT NULL,
    proof_image    VARCHAR(255) NOT NULL,
    status         ENUM('pending','confirmed','rejected') NOT NULL DEFAULT 'pending',
    admin_note     TEXT DEFAULT NULL,
    confirmed_by   INT UNSIGNED DEFAULT NULL,
    confirmed_at   DATETIME DEFAULT NULL,
    expired_at     DATETIME NOT NULL,
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (confirmed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Orders ─────────────────────────────────────────────────
CREATE TABLE orders (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id             INT UNSIGNED NOT NULL,
    product_id          INT UNSIGNED NOT NULL,
    order_code          VARCHAR(30) NOT NULL UNIQUE,
    amount              BIGINT UNSIGNED NOT NULL,
    status              ENUM('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
    server_id           VARCHAR(20) DEFAULT NULL,
    server_identifier   VARCHAR(20) DEFAULT NULL,
    server_name         VARCHAR(100) DEFAULT NULL,
    panel_url           VARCHAR(255) DEFAULT NULL,
    panel_username      VARCHAR(150) DEFAULT NULL,
    panel_password      VARCHAR(255) DEFAULT NULL,
    failed_reason       TEXT DEFAULT NULL,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Transactions (audit trail saldo) ───────────────────────
CREATE TABLE transactions (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id        INT UNSIGNED NOT NULL,
    type           ENUM('topup','purchase','adjustment_add','adjustment_deduct','refund') NOT NULL,
    amount         BIGINT UNSIGNED NOT NULL,
    balance_before BIGINT UNSIGNED NOT NULL,
    balance_after  BIGINT UNSIGNED NOT NULL,
    reference      VARCHAR(50) DEFAULT NULL,
    note           TEXT DEFAULT NULL,
    performed_by   INT UNSIGNED DEFAULT NULL,
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Settings ───────────────────────────────────────────────
CREATE TABLE settings (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    key_name   VARCHAR(100) NOT NULL UNIQUE,
    value      TEXT DEFAULT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO settings (key_name, value) VALUES
('site_name',          'PteroShop'),
('site_desc',          'Jual Panel Pterodactyl Murah & Otomatis'),
('qris_image',         'uploads/qris/qris.jpg'),
('min_topup',          '10000'),
('topup_expiry_hours', '24'),
('announcement',       ''),
('maintenance',        '0'),
('ptero_url',          ''),
('ptero_api_key',      '');
