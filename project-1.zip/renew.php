<?php
require_once __DIR__ . '/includes/init.php';
require_login();

$user      = current_user();
$pageTitle = 'Perpanjang Panel';

// Ambil semua order completed milik user
$servers = db_rows(
    "SELECT o.*, p.name as product_name, p.price as product_price
     FROM orders o
     JOIN products p ON o.product_id = p.id
     WHERE o.user_id = ? AND o.status = 'completed'
     ORDER BY o.expired_at ASC",
    [$user['id']]
);

$msg = '';
$msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $orderId = (int)($_POST['order_id'] ?? 0);

    // Validasi order milik user
    $order = db_row(
        "SELECT o.*, p.name as product_name, p.price as product_price
         FROM orders o JOIN products p ON o.product_id=p.id
         WHERE o.id=? AND o.user_id=? AND o.status='completed'",
        [$orderId, $user['id']]
    );

    if (!$order) {
        flash('danger', 'Order tidak ditemukan.');
        redirect('renew.php');
    }

    $hargaRenew = (int)$order['product_price'];
    $durasiHari = 30; // default 30 hari per perpanjangan

    // Cek saldo
    if ((int)$user['balance'] < $hargaRenew) {
        flash('danger', 'Saldo tidak cukup. Saldo Anda: ' . rupiah((int)$user['balance']) . ', dibutuhkan: ' . rupiah($hargaRenew) . '.');
        redirect('renew.php');
    }

    // Hitung expired baru
    $baseDate = (!empty($order['expired_at']) && strtotime($order['expired_at']) > time())
        ? $order['expired_at']
        : date('Y-m-d H:i:s');
    $newExpired = date('Y-m-d H:i:s', strtotime($baseDate) + ($durasiHari * 86400));

    // Deduct saldo (atomic, tercatat di transactions)
    try {
        balance_debit($user['id'], $hargaRenew, 'purchase', $order['order_code'], 'Perpanjang panel: ' . $order['product_name']);
    } catch (\Throwable $e) {
        flash('danger', 'Saldo tidak cukup atau terjadi kesalahan: ' . $e->getMessage());
        redirect('renew.php');
    }

    // Update expired_at
    db_query("UPDATE orders SET expired_at = ? WHERE id=?", [$newExpired, $order['id']]);

    // Catat log renewal (opsional - butuh migration_renewals.sql dijalankan dulu)
    try {
        db_query(
            "INSERT INTO renewals (order_id, user_id, amount, old_expired, new_expired, created_at)
             VALUES (?, ?, ?, ?, ?, NOW())",
            [$order['id'], $user['id'], $hargaRenew, $order['expired_at'], $newExpired]
        );
    } catch (\Throwable $e) {
        // Tabel renewals belum dibuat, skip saja
    }

    flash('success', '✅ Panel "' . $order['product_name'] . '" berhasil diperpanjang hingga ' . date('d M Y H:i', strtotime($newExpired)) . '.');
    redirect('renew.php');
}

require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width:860px;margin:0 auto">

  <!-- Info saldo -->
  <div class="card" style="margin-bottom:22px;background:linear-gradient(135deg,rgba(0,212,255,.08),rgba(0,212,255,.03));border-color:rgba(0,212,255,.25)">
    <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
      <div style="flex:1;min-width:160px">
        <div style="font-family:'Space Mono',monospace;font-size:10px;color:var(--dim);letter-spacing:2px;text-transform:uppercase">Saldo Anda</div>
        <div style="font-family:'Syne',sans-serif;font-size:28px;font-weight:800;color:var(--cyan);margin-top:4px"><?= rupiah((int)$user['balance']) ?></div>
      </div>
      <a href="topup.php" class="btn btn-primary">💳 Top Up Saldo</a>
    </div>
  </div>

  <?php if (!$servers): ?>
  <div class="card" style="text-align:center;padding:50px">
    <div style="font-size:44px;margin-bottom:12px">🖥️</div>
    <div style="color:var(--muted);font-size:14px">Anda belum memiliki server aktif.</div>
    <a href="order.php" class="btn btn-primary" style="margin-top:16px">Beli Panel Sekarang</a>
  </div>
  <?php else: ?>

  <div style="font-family:'Space Mono',monospace;font-size:10px;color:var(--dim);letter-spacing:2px;text-transform:uppercase;margin-bottom:12px">
    PILIH SERVER UNTUK DIPERPANJANG
  </div>

  <div style="display:grid;gap:14px">
  <?php foreach ($servers as $s):
    $isExpired   = !empty($s['expired_at']) && strtotime($s['expired_at']) < time();
    $isExpireSoon = !empty($s['expired_at']) && !$isExpired && (strtotime($s['expired_at']) - time()) < (7 * 86400);
    $sisaHari    = !empty($s['expired_at']) ? ceil((strtotime($s['expired_at']) - time()) / 86400) : null;
    $durasiHari  = 30; // default 30 hari
    $harga       = (int)$s['product_price'];
    $cukup       = (int)$user['balance'] >= $harga;
  ?>
  <div class="card renew-card <?= $isExpired ? 'expired' : ($isExpireSoon ? 'expire-soon' : '') ?>">
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap">
      <div style="flex:1;min-width:200px">
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px">
          <span style="font-family:'Syne',sans-serif;font-size:15px;font-weight:700;color:var(--txt)"><?= e($s['product_name']) ?></span>
          <?php if ($isExpired): ?>
            <span class="badge badge-red">⚠️ Expired</span>
          <?php elseif ($isExpireSoon): ?>
            <span class="badge badge-yellow">⏳ Hampir Expired</span>
          <?php else: ?>
            <span class="badge badge-green">✅ Aktif</span>
          <?php endif; ?>
        </div>
        <div style="font-family:'Space Mono',monospace;font-size:11px;color:var(--cyan);margin-bottom:8px"><?= e($s['order_code']) ?></div>

        <?php if (!empty($s['expired_at'])): ?>
        <div style="font-size:12px;color:<?= $isExpired ? 'var(--red)' : 'var(--muted)' ?>">
          <?= $isExpired ? '⛔ Expired: ' : '📅 Expired: ' ?>
          <strong style="color:<?= $isExpired ? 'var(--red)' : 'var(--txt)' ?>"><?= date('d M Y H:i', strtotime($s['expired_at'])) ?></strong>
          <?php if (!$isExpired && $sisaHari !== null): ?>
            <span style="color:<?= $isExpireSoon ? 'var(--yellow)' : 'var(--muted)' ?>"> (<?= $sisaHari ?> hari lagi)</span>
          <?php endif; ?>
        </div>
        <?php endif; ?>

        <div style="font-size:12px;color:var(--muted);margin-top:4px">
          🔁 Perpanjang: +<?= $durasiHari ?> hari
          &nbsp;|&nbsp;
          💰 Biaya: <strong style="color:var(--cyan)"><?= rupiah($harga) ?></strong>
        </div>
      </div>

      <div style="display:flex;align-items:center">
        <?php if ($cukup): ?>
        <form method="POST" onsubmit="return confirm('Perpanjang panel <?= e($s['product_name']) ?> seharga <?= rupiah($harga) ?>?')">
          <?= csrf_field() ?>
          <input type="hidden" name="order_id" value="<?= $s['id'] ?>">
          <button type="submit" class="btn btn-primary">
            🔄 Perpanjang
          </button>
        </form>
        <?php else: ?>
        <div style="text-align:right">
          <div style="font-size:11px;color:var(--red);margin-bottom:6px">Saldo kurang <?= rupiah($harga - (int)$user['balance']) ?></div>
          <a href="topup.php" class="btn btn-outline btn-sm">Top Up Dulu</a>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php endforeach; ?>
  </div>

  <?php endif; ?>
</div>

<style>
.renew-card { transition: border-color .2s; }
.renew-card.expired { border-color: rgba(255,68,68,.4); background: rgba(255,68,68,.04); }
.renew-card.expire-soon { border-color: rgba(255,214,0,.4); background: rgba(255,214,0,.03); }
</style>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
