<?php
require_once __DIR__ . '/includes/init.php';
require_login();
require_once __DIR__ . '/includes/pterodactyl.php';

$user     = current_user();
$pageTitle = 'Dashboard';

// Stats
$totalOrders    = (int)db_val("SELECT COUNT(*) FROM orders WHERE user_id=?", [$user['id']]);
$activeServers  = (int)db_val("SELECT COUNT(*) FROM orders WHERE user_id=? AND status='completed'", [$user['id']]);
$totalTopup     = (int)db_val("SELECT COALESCE(SUM(amount),0) FROM topups WHERE user_id=? AND status='confirmed'", [$user['id']]);
$recentOrders   = db_rows("SELECT o.*,p.name as product_name FROM orders o JOIN products p ON o.product_id=p.id WHERE o.user_id=? ORDER BY o.created_at DESC LIMIT 5", [$user['id']]);
$recentTopups   = db_rows("SELECT * FROM topups WHERE user_id=? ORDER BY created_at DESC LIMIT 5", [$user['id']]);

require_once __DIR__ . '/includes/header.php';
?>

<!-- Quick Actions -->
<div class="quick-actions">
  <a href="order.php" class="quick-btn">
    <span class="quick-icon">🛒</span>
    <span>Beli Panel</span>
  </a>
  <a href="renew.php" class="quick-btn">
    <span class="quick-icon">🔄</span>
    <span>Perpanjang</span>
  </a>
  <a href="topup.php" class="quick-btn">
    <span class="quick-icon">💳</span>
    <span>Top Up</span>
  </a>
  <a href="profile.php" class="quick-btn">
    <span class="quick-icon">⚙️</span>
    <span>Profil</span>
  </a>
</div>

<div class="grid-4 stat-grid" style="margin-bottom:22px">
  <div class="stat-card c-cyan">
    <div class="stat-label">Saldo</div>
    <div class="stat-val"><?= rupiah((int)$user['balance']) ?></div>
    <div class="stat-sub"><a href="topup.php" style="color:var(--cyan);text-decoration:none">+ Top Up →</a></div>
  </div>
  <div class="stat-card c-green">
    <div class="stat-label">Server Aktif</div>
    <div class="stat-val"><?= $activeServers ?></div>
    <div class="stat-sub">dari <?= $totalOrders ?> order</div>
  </div>
  <div class="stat-card c-yellow">
    <div class="stat-label">Total Top Up</div>
    <div class="stat-val"><?= rupiah($totalTopup) ?></div>
    <div class="stat-sub">sepanjang waktu</div>
  </div>
  <div class="stat-card c-red">
    <div class="stat-label">Total Order</div>
    <div class="stat-val"><?= $totalOrders ?></div>
    <div class="stat-sub"><a href="order.php" style="color:var(--cyan);text-decoration:none">Beli lagi →</a></div>
  </div>
</div>

<?php
// Cek server yang hampir / sudah expired
$expiringServers = db_rows(
    "SELECT o.*, p.name as product_name FROM orders o
     JOIN products p ON o.product_id=p.id
     WHERE o.user_id=? AND o.status='completed'
       AND o.expired_at IS NOT NULL
       AND o.expired_at <= DATE_ADD(NOW(), INTERVAL 7 DAY)
     ORDER BY o.expired_at ASC LIMIT 5",
    [$user['id']]
);
?>
<?php if ($expiringServers): ?>
<div class="alert alert-yellow" style="margin-bottom:18px;flex-direction:column;gap:8px">
  <div style="display:flex;align-items:center;gap:8px;font-weight:600">
    ⚠️ Panel Hampir / Sudah Expired
  </div>
  <?php foreach ($expiringServers as $ex):
    $isExp = strtotime($ex['expired_at']) < time();
    $sisa  = ceil((strtotime($ex['expired_at']) - time()) / 86400);
  ?>
  <div style="display:flex;justify-content:space-between;align-items:center;font-size:13px;flex-wrap:wrap;gap:6px">
    <span><?= e($ex['product_name']) ?> — <span style="font-family:monospace;font-size:11px"><?= e($ex['order_code']) ?></span></span>
    <span style="display:flex;align-items:center;gap:8px">
      <span style="color:<?= $isExp ? 'var(--red)' : 'var(--yellow)' ?>">
        <?= $isExp ? '⛔ Expired' : "⏳ {$sisa} hari lagi" ?>
      </span>
      <a href="renew.php" class="btn btn-yellow btn-sm">Perpanjang</a>
    </span>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="grid-2">
  <!-- Recent Orders -->
  <div class="card">
    <div class="card-header">
      <div class="card-title">Order Terbaru</div>
      <a href="order-history.php" class="btn btn-outline btn-sm">Lihat Semua</a>
    </div>
    <?php if ($recentOrders): ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Kode</th><th>Produk</th><th>Status</th><th>Tgl</th></tr></thead>
        <tbody>
        <?php foreach ($recentOrders as $o): ?>
          <tr>
            <td><span style="font-family:'Space Mono',monospace;font-size:11px;color:var(--cyan)"><?= e($o['order_code']) ?></span></td>
            <td><?= e($o['product_name']) ?></td>
            <td><?= status_badge($o['status']) ?></td>
            <td style="color:var(--muted);font-size:12px"><?= date('d/m/y', strtotime($o['created_at'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
      <div style="text-align:center;padding:30px;color:var(--muted)">
        <div style="font-size:30px;margin-bottom:8px">📦</div>
        Belum ada order. <a href="order.php" style="color:var(--cyan)">Beli sekarang!</a>
      </div>
    <?php endif; ?>
  </div>

  <!-- Recent Topups -->
  <div class="card">
    <div class="card-header">
      <div class="card-title">Top Up Terbaru</div>
      <a href="topup.php" class="btn btn-primary btn-sm">+ Top Up</a>
    </div>
    <?php if ($recentTopups): ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Kode</th><th>Nominal</th><th>Status</th><th>Tgl</th></tr></thead>
        <tbody>
        <?php foreach ($recentTopups as $t): ?>
          <tr>
            <td><span style="font-family:'Space Mono',monospace;font-size:11px;color:var(--muted)"><?= e($t['topup_code']) ?></span></td>
            <td style="color:var(--green);font-weight:600"><?= rupiah((int)$t['amount']) ?></td>
            <td><?= status_badge($t['status']) ?></td>
            <td style="color:var(--muted);font-size:12px"><?= date('d/m/y', strtotime($t['created_at'])) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
      <div style="text-align:center;padding:30px;color:var(--muted)">
        <div style="font-size:30px;margin-bottom:8px">💳</div>
        Belum ada top up. <a href="topup.php" style="color:var(--cyan)">Top up sekarang!</a>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
