<?php
require_once __DIR__ . '/includes/init.php';
require_login();

$user      = current_user();
$pageTitle = 'Riwayat Order';
$page      = max(1, (int)($_GET['page'] ?? 1));
$result    = paginate(
    "SELECT o.*,p.name as product_name FROM orders o JOIN products p ON o.product_id=p.id WHERE o.user_id=? ORDER BY o.created_at DESC",
    [$user['id']], $page
);

require_once __DIR__ . '/includes/header.php';
?>

<div class="card">
  <div class="card-header">
    <div class="card-title">Riwayat Order (<?= $result['total'] ?>)</div>
    <a href="order.php" class="btn btn-primary btn-sm">+ Beli Panel</a>
  </div>
  <?php if ($result['rows']): ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Kode Order</th><th>Produk</th><th>Harga</th><th>Status</th><th>Tanggal</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($result['rows'] as $o): ?>
        <tr>
          <td><span style="font-family:'Space Mono',monospace;font-size:11px;color:var(--cyan)"><?= e($o['order_code']) ?></span></td>
          <td><?= e($o['product_name']) ?></td>
          <td style="font-weight:600"><?= rupiah((int)$o['amount']) ?></td>
          <td><?= status_badge($o['status']) ?></td>
          <td style="color:var(--muted);font-size:12px"><?= date('d M Y H:i', strtotime($o['created_at'])) ?></td>
          <td>
            <a href="order-detail.php?id=<?= $o['id'] ?>" class="btn btn-outline btn-sm">
              <?= $o['status'] === 'completed' ? '🔑 Lihat Kredensial' : '📋 Detail' ?>
            </a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php if ($result['pages'] > 1): ?>
  <div class="pagination">
    <?php for ($i = 1; $i <= $result['pages']; $i++): ?>
      <a href="?page=<?= $i ?>" class="<?= $i === $result['page'] ? 'pg-active' : '' ?>"><?= $i ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
  <?php else: ?>
  <div style="text-align:center;padding:40px;color:var(--muted)">
    <div style="font-size:36px;margin-bottom:10px">📋</div>
    Belum ada order. <a href="order.php" style="color:var(--cyan)">Beli panel sekarang!</a>
  </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
