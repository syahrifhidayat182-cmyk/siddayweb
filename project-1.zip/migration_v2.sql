-- ============================================================
--  MIGRATION: Fitur Voucher + Masa Aktif Order
--  Jalankan di phpMyAdmin atau mysql CLI
-- ============================================================

SET NAMES utf8mb4;

-- ── Tabel Vouchers ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS vouchers (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code        VARCHAR(30) NOT NULL UNIQUE,
    description VARCHAR(255) DEFAULT NULL,
    type        ENUM('percent','flat') NOT NULL DEFAULT 'percent',
    value       DECIMAL(10,2) NOT NULL DEFAULT 0,
    uses_count  INT UNSIGNED NOT NULL DEFAULT 0,
    uses_left   INT UNSIGNED DEFAULT NULL COMMENT 'NULL = unlimited',
    is_active   TINYINT(1) NOT NULL DEFAULT 1,
    expired_at  DATETIME DEFAULT NULL COMMENT 'NULL = no expiry',
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Tambah kolom ke tabel orders ────────────────────────────

-- Masa aktif panel (30 hari dari pembelian)
ALTER TABLE orders
    ADD COLUMN IF NOT EXISTS expired_at DATETIME DEFAULT NULL COMMENT '30 hari dari tanggal beli';

-- Voucher yang digunakan
ALTER TABLE orders
    ADD COLUMN IF NOT EXISTS voucher_code VARCHAR(30) DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS voucher_discount BIGINT UNSIGNED NOT NULL DEFAULT 0;

-- ptero_account_id & email (kalau belum ada)
ALTER TABLE orders
    ADD COLUMN IF NOT EXISTS ptero_account_id VARCHAR(50) DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS ptero_account_email VARCHAR(150) DEFAULT NULL;

-- ── Tambah kolom topups untuk pay_mode, payment_url, dll ────
-- (jika belum ada dari migrasi sebelumnya)
ALTER TABLE topups
    ADD COLUMN IF NOT EXISTS pay_method VARCHAR(30) DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS pay_mode   ENUM('manual','auto') NOT NULL DEFAULT 'manual',
    ADD COLUMN IF NOT EXISTS payment_number VARCHAR(100) DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS payment_url    VARCHAR(500) DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS fee            BIGINT UNSIGNED NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS total_payment  BIGINT UNSIGNED NOT NULL DEFAULT 0;

-- ── Contoh voucher untuk testing ────────────────────────────
INSERT IGNORE INTO vouchers (code, description, type, value, uses_left, is_active) VALUES
('HEMAT10',   'Diskon 10% untuk semua produk', 'percent', 10.00, NULL, 1),
('DISKON5K',  'Potongan Rp5.000',              'flat',    5000,  100,  1),
('VIP50',     'Diskon 50% khusus VIP',         'percent', 50.00, 10,   0);
